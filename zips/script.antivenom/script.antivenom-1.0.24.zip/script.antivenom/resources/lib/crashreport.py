# -*- coding: utf-8 -*-
"""
AntiVenom problem reporter.

Watches kodi.log for Python exceptions and skin load failures, detects unclean
shutdowns, and sends a sanitized log to the developer:
  - full log  -> paste.kodi.tv (Kodi's official log pastebin)
  - alert     -> ntfy.sh push notification with the log link
"""
import os
import re
import json
import time
import threading
import urllib.request

import xbmc
import xbmcaddon
import xbmcvfs

NTFY_TOPIC = 'antivenom-jj-q7m4x9t2kf8w'
NTFY_URL = 'https://ntfy.sh/' + NTFY_TOPIC
PASTE_POST_URL = 'https://paste.kodi.tv/documents'
PASTE_VIEW_URL = 'https://paste.kodi.tv/'

MAX_LOG_CHARS = 350000
MAX_READ_BYTES = 2 * 1024 * 1024
MIN_GAP_SECONDS = 10 * 60
MAX_AUTO_PER_DAY = 8
SIGNATURE_COOLDOWN = 24 * 3600

STATE_DIR = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/')
STATE_FILE = os.path.join(STATE_DIR, 'crashreport_state.json')
RUNNING_FLAG = os.path.join(STATE_DIR, '.session_running')

SKIN_ERROR_RE = re.compile(
    r'Skin has invalid include|Unable to load skin file|Failed to load skin|'
    r'Error loading skin|CGUIIncludes.*(?:invalid|not found)|Unable to load window XML',
    re.I
)

NOISE_RE = re.compile(r'AddOnLog: pvr\.iptvsimple: .*debug|CMMNotificationClient|iptvsimple::Epg::')

SECRET_PATTERNS = [
    (re.compile(r'(RealDebridResolver_(?:token|refresh|client_secret)\W{1,8})[A-Za-z0-9]+'), r'\1***'),
    (re.compile(r'(Bearer\s+)[A-Za-z0-9._\-]+', re.I), r'\1***'),
    (re.compile(r'((?:api_?key|apikey|access_token|refresh_token|client_secret|password|passwd|token|secret)'
                r'["\']?\s*[:=]\s*["\']?)[^"\'&\s|<,]+', re.I), r'\1***'),
    (re.compile(r'(<password>)[^<]*'), r'\1***'),
    (re.compile(r'(download\.real-debrid\.com/d/)[A-Za-z0-9]+'), r'\1***'),
    (re.compile(r'\b[A-Z0-9]{40,}\b'), '***'),
    (re.compile(r'\b[a-f0-9]{40,}\b'), '***'),
    (re.compile(r'ghp_[A-Za-z0-9]{20,}'), 'ghp_***'),
]


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[AntiVenom Reporter] {msg}', level)


def log_paths():
    logdir = xbmcvfs.translatePath('special://logpath')
    return os.path.join(logdir, 'kodi.log'), os.path.join(logdir, 'kodi.old.log')


def _load_state():
    try:
        with open(STATE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {'sent': [], 'sigs': {}}


def _save_state(state):
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(STATE_FILE, 'w', encoding='utf-8') as f:
            json.dump(state, f)
    except Exception as e:
        _log(f'state save failed: {e}', xbmc.LOGWARNING)


def sanitize(text):
    for pattern, repl in SECRET_PATTERNS:
        text = pattern.sub(repl, text)
    return text


def _read_log_tail(path, max_chars=MAX_LOG_CHARS):
    try:
        size = os.path.getsize(path)
        with open(path, 'rb') as f:
            if size > MAX_READ_BYTES:
                f.seek(size - MAX_READ_BYTES)
            raw = f.read().decode('utf-8', 'replace')
    except Exception as e:
        return f'(could not read {path}: {e})'
    lines = [l for l in raw.splitlines() if not NOISE_RE.search(l)]
    text = '\n'.join(lines)
    if len(text) > max_chars:
        text = '...(truncated)...\n' + text[-max_chars:]
    return sanitize(text)


def _platform():
    for cond, name in (('System.Platform.Android', 'Android/FireTV'),
                       ('System.Platform.Windows', 'Windows'),
                       ('System.Platform.Linux', 'Linux'),
                       ('System.Platform.OSX', 'macOS'),
                       ('System.Platform.IOS', 'iOS'),
                       ('System.Platform.TVOS', 'tvOS')):
        if xbmc.getCondVisibility(cond):
            return name
    return 'Unknown'


def device_info():
    try:
        av_version = xbmcaddon.Addon('script.antivenom').getAddonInfo('version')
    except Exception:
        av_version = '?'
    try:
        skin_version = xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo('version')
    except Exception:
        skin_version = '?'
    try:
        import shutil
        free_mb = shutil.disk_usage(xbmcvfs.translatePath('special://home/')).free // (1024 * 1024)
        storage = f'{free_mb} MB free'
    except Exception:
        storage = '?'
    return {
        'Device': xbmc.getInfoLabel('System.FriendlyName') or 'Kodi',
        'Platform': _platform(),
        'Kodi': xbmc.getInfoLabel('System.BuildVersion'),
        'AntiVenom': av_version,
        'Skin': f'{xbmc.getSkinDir()} {skin_version}',
        'Storage': storage,
        'Resolution': xbmc.getInfoLabel('System.ScreenResolution'),
        'Window': f"{xbmc.getInfoLabel('System.CurrentWindow')} ({xbmc.getInfoLabel('System.CurrentControlId')})",
        'FreeMemory': xbmc.getInfoLabel('System.FreeMemory'),
        'Time': time.strftime('%Y-%m-%d %H:%M:%S'),
    }


def _http_post(url, data, headers, timeout=25):
    headers = dict(headers)
    headers.setdefault('User-Agent', 'AntiVenom-Reporter/1.0')
    req = urllib.request.Request(url, data=data, headers=headers, method='POST')
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode('utf-8', 'replace')


def send_report(reason, detail='', manual=False, use_old_log=False):
    """Upload the log and push an alert. Returns the log link, or None if throttled/failed."""
    state = _load_state()
    now = time.time()
    recent = [t for t in state.get('sent', []) if now - t < 86400]
    if not manual:
        if len(recent) >= MAX_AUTO_PER_DAY or (recent and now - max(recent) < MIN_GAP_SECONDS):
            _log('auto report skipped (rate limit)')
            return None

    info = device_info()
    current_log, old_log = log_paths()
    header = '\n'.join(f'{k}: {v}' for k, v in info.items())
    log_text = _read_log_tail(old_log if use_old_log else current_log)
    body = (
        f'=== AntiVenom problem report ===\n'
        f'Reason: {reason}\n'
        f'{sanitize(detail)}\n\n'
        f'{header}\n\n'
        f'=== {"kodi.old.log (previous session)" if use_old_log else "kodi.log"} ===\n'
        f'{log_text}\n'
    )

    link = None
    try:
        resp = _http_post(PASTE_POST_URL, body.encode('utf-8'),
                          {'Content-Type': 'text/plain; charset=utf-8'})
        key = json.loads(resp).get('key')
        if key:
            link = PASTE_VIEW_URL + key
    except Exception as e:
        _log(f'log upload failed: {e}', xbmc.LOGWARNING)

    summary = (
        f'{reason}\n{sanitize(detail)[:500]}\n'
        f"{info['Device']} | {info['Platform']} | AntiVenom {info['AntiVenom']} | Kodi {info['Kodi'].split(' ')[0]}\n"
        f"Window: {info['Window']}\n"
    )
    summary += f'Log: {link}' if link else 'Log upload failed. Last lines:\n' + log_text[-2500:]

    headers = {
        'Title': ('AntiVenom report: ' if manual else 'AntiVenom crash: ') + reason[:60],
        'Tags': 'memo' if manual else 'rotating_light',
        'Priority': 'default' if manual else 'high',
    }
    if link:
        headers['Click'] = link
    headers = {k: v.encode('ascii', 'ignore').decode('ascii') for k, v in headers.items()}

    try:
        _http_post(NTFY_URL, summary.encode('utf-8'), headers)
    except Exception as e:
        _log(f'alert push failed: {e}', xbmc.LOGWARNING)
        if not link:
            return None

    state['sent'] = recent + [now]
    _save_state(state)
    _log(f'report delivered: {reason} -> {link}')
    return link or 'sent'


def _send_async(reason, detail, signature=None, use_old_log=False):
    def worker():
        if signature:
            state = _load_state()
            state.setdefault('sigs', {})[signature] = time.time()
            _save_state(state)
        send_report(reason, detail, manual=False, use_old_log=use_old_log)
    threading.Thread(target=worker, daemon=True).start()


def find_problems(text):
    """Yield (signature, reason, detail) for each problem found in a chunk of log text."""
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if 'AntiVenom Reporter' in line:
            continue
        if 'Error Type:' in line:
            etype = line.split('Error Type:', 1)[1].strip()
            contents = ''
            if i + 1 < len(lines) and 'Error Contents:' in lines[i + 1]:
                contents = lines[i + 1].split('Error Contents:', 1)[1].strip()
            where = ''
            for follow in lines[i + 2:i + 60]:
                if 'File "' in follow:
                    where = follow.strip()
                if 'End of Python script error report' in follow:
                    break
            addon = re.search(r'addons[\\/]+([^\\/"]+)', where)
            addon_id = addon.group(1) if addon else 'unknown addon'
            yield (f'py|{etype}|{contents}|{where}',
                   f'Python error in {addon_id}',
                   f'{etype}: {contents}\n{where}')
        elif SKIN_ERROR_RE.search(line):
            msg = line.split('<general>:', 1)[-1].strip()
            yield (f'skin|{msg}', 'Skin error', msg)


class LogWatcher(object):
    def __init__(self):
        self.path, _ = log_paths()
        self.offset = 0

    def poll(self):
        try:
            size = os.path.getsize(self.path)
        except OSError:
            return
        if size < self.offset:
            self.offset = 0
        if size == self.offset:
            return
        start = max(self.offset, size - MAX_READ_BYTES)
        try:
            with open(self.path, 'rb') as f:
                f.seek(start)
                chunk = f.read(size - start)
        except Exception:
            return
        # Hold back a partial trailing traceback until the next poll.
        text = chunk.decode('utf-8', 'replace')
        cut = text.rfind('Error Type:')
        if cut != -1 and 'End of Python script error report' not in text[cut:]:
            text = text[:cut]
            self.offset = start + len(text.encode('utf-8', 'replace'))
        else:
            self.offset = size

        state = _load_state()
        sigs = state.get('sigs', {})
        now = time.time()
        for sig, reason, detail in find_problems(text):
            if now - sigs.get(sig, 0) < SIGNATURE_COOLDOWN:
                continue
            sigs[sig] = now
            _log(f'problem detected: {reason}')
            _send_async(reason, detail, signature=sig)
            break


def check_previous_session():
    """Report if the last Kodi session ended without a clean service shutdown and its log shows errors."""
    try:
        crashed = os.path.isfile(RUNNING_FLAG)
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(RUNNING_FLAG, 'w') as f:
            f.write(str(time.time()))
        if not crashed:
            return
        _, old_log = log_paths()
        if not os.path.isfile(old_log):
            return
        tail = _read_log_tail(old_log, max_chars=60000)
        last_lines = '\n'.join(tail.splitlines()[-400:])
        problems = list(find_problems(last_lines))
        error_lines = [l for l in last_lines.splitlines() if ' error <' in l or 'FATAL' in l]
        if problems or error_lines:
            detail = problems[0][2] if problems else '\n'.join(error_lines[-5:])
            _send_async('Kodi closed unexpectedly (possible crash)', detail, use_old_log=True)
    except Exception as e:
        _log(f'previous session check failed: {e}', xbmc.LOGWARNING)


def mark_clean_exit():
    try:
        if os.path.isfile(RUNNING_FLAG):
            os.remove(RUNNING_FLAG)
    except Exception:
        pass


def ensure_logging_enabled():
    """Undo loglevel -1 (logging disabled) from older AntiVenom builds. Applies after next Kodi restart."""
    changed = False
    for special in ('special://masterprofile/advancedsettings.xml', 'special://profile/advancedsettings.xml'):
        path = xbmcvfs.translatePath(special)
        try:
            if not os.path.isfile(path):
                continue
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            fixed = re.sub(r'<loglevel([^>]*)>\s*-1\s*</loglevel>', r'<loglevel\1>0</loglevel>', content)
            if fixed != content:
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(fixed)
                changed = True
                _log(f'enabled logging in {path}')
        except Exception as e:
            _log(f'could not update {path}: {e}', xbmc.LOGWARNING)
    return changed
