# -*- coding: utf-8 -*-
"""
Device capability profile.

Low-power Fire TV sticks (1 GB RAM, 32-bit ARM, Mali-450) cannot decode 4K or
10-bit HEVC and crash when The Crew hands them a UHD remux. They also thrash
with 25 scraper threads and a 100 MB read cache. Detect them and apply a
"Lite" profile once.
"""
import os
import re
import struct

import xbmc
import xbmcaddon
import xbmcvfs

LITE_STAMP = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/.lite_profile_v2')

# Kodi 21 filecache.memorysize is in MB; Kodi uses ~3x this in RAM.
CACHE_MB_LITE = 40
CACHE_MB_DEFAULT = 100


def _log(msg):
    xbmc.log(f'[AntiVenom Device] {msg}', xbmc.LOGINFO)


def total_ram_mb():
    label = xbmc.getInfoLabel('System.Memory(total)') or ''
    m = re.search(r'(\d+)', label.replace(',', ''))
    if m:
        val = int(m.group(1))
        return val // 1024 if 'KB' in label.upper() and val > 100000 else val
    try:
        with open('/proc/meminfo', 'r') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    return int(line.split()[1]) // 1024
    except Exception:
        pass
    return 0


def is_android():
    return xbmc.getCondVisibility('System.Platform.Android')


def is_32bit():
    return struct.calcsize('P') * 8 == 32


def is_low_power():
    """True for devices that cannot handle 4K/10-bit HEVC or heavy scraping."""
    if not is_android():
        return False
    ram = total_ram_mb()
    return is_32bit() or (0 < ram <= 1100)


def cache_size_mb():
    return CACHE_MB_LITE if is_low_power() else CACHE_MB_DEFAULT


def describe():
    return f'android={is_android()} 32bit={is_32bit()} ram={total_ram_mb()}MB low_power={is_low_power()}'


def _set_crew(addon, key, value):
    try:
        cur = addon.getSetting(key)
        if cur != value:
            addon.setSetting(key, value)
            return True
    except Exception as e:
        _log(f'could not set {key}: {e}')
    return False


def apply_crew_lite_profile(debrid_linked, force=False):
    """Cap The Crew to what the hardware can actually play. Runs once per profile version."""
    if not is_low_power():
        return False
    if os.path.isfile(LITE_STAMP) and not force:
        return False
    if not xbmc.getCondVisibility('System.HasAddon(plugin.video.thecrew)'):
        return False
    try:
        crew = xbmcaddon.Addon('plugin.video.thecrew')
    except Exception as e:
        _log(f'The Crew not loadable yet: {e}')
        return False

    changed = 0
    # hosts.quality enum: 0=4K 1=1440p 2=1080p 3=720p 4=480p
    changed += _set_crew(crew, 'hosts.quality', '2')
    changed += _set_crew(crew, 'max.threads', '10')
    changed += _set_crew(crew, 'max.limit.sources', '40')
    # Extra scraper packs double the search time on a weak CPU.
    changed += _set_crew(crew, 'gearsscrapers.enabled', 'false')
    changed += _set_crew(crew, 'cocoscrapers.enabled', 'false')
    if debrid_linked:
        # Skip dead free hosters entirely; only debrid sources are worth waiting for.
        changed += _set_crew(crew, 'debrid.only', 'true')

    try:
        os.makedirs(os.path.dirname(LITE_STAMP), exist_ok=True)
        with open(LITE_STAMP, 'w') as f:
            f.write(describe())
    except Exception:
        pass
    _log(f'Lite profile applied ({changed} settings changed): {describe()}')
    return changed > 0
