# -*- coding: utf-8 -*-
"""
AntiVenom GameDay Hub Engine
Pulls live scores, clocks, and matchup states from open sports scoreboard feeds.
Caches data locally with a 90-second TTL and sets dynamic Kodi window properties
for live badges and scoreboard overlays on the AntiVenom Sports canvas.
"""

import os
import json
import time
import urllib.request
import urllib.parse
from typing import Dict, List, Any, Optional

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
    KODI_ENV = True
except ImportError:
    KODI_ENV = False

LEAGUE_ENDPOINTS = {
    'NFL': 'https://site.web.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard',
    'CFB': 'https://site.web.api.espn.com/apis/site/v2/sports/football/college-football/scoreboard',
    'NBA': 'https://site.web.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard',
    'MLB': 'https://site.web.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard',
    'NHL': 'https://site.web.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard',
    'EPL': 'https://site.web.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard'
}

DEFAULT_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*'
}

def log(msg: str, level: int = 1) -> None:
    if KODI_ENV:
        xbmc.log(f"[AntiVenom GameDay] {msg}", level)
    else:
        print(f"[AntiVenom GameDay] {msg}")

def get_cache_path() -> str:
    if KODI_ENV:
        addon_dir = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom')
        if not os.path.exists(addon_dir):
            os.makedirs(addon_dir, exist_ok=True)
        return os.path.join(addon_dir, 'gameday_scores.json')
    return os.path.join(os.path.dirname(__file__), 'gameday_scores.json')

def fetch_league_scoreboard(league: str, url: str) -> List[Dict[str, Any]]:
    """Fetches and parses scoreboard events for a single sports league."""
    events_out = []
    try:
        req = urllib.request.Request(url, headers=DEFAULT_HEADERS)
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            raw_events = data.get('events', [])
            for ev in raw_events:
                status_type = ev.get('status', {}).get('type', {})
                state = status_type.get('state', 'pre').upper()  # PRE, IN, POST
                detail = status_type.get('detail', '')
                short_detail = status_type.get('shortDetail', detail)

                comps = ev.get('competitions', [{}])[0].get('competitors', [])
                if len(comps) < 2:
                    continue

                away = next((c for c in comps if c.get('homeAway') == 'away'), comps[0])
                home = next((c for c in comps if c.get('homeAway') == 'home'), comps[1])

                away_team = away.get('team', {})
                home_team = home.get('team', {})

                away_name = away_team.get('displayName', away_team.get('name', 'Away'))
                home_name = home_team.get('displayName', home_team.get('name', 'Home'))
                away_abbr = away_team.get('abbreviation', away_name[:3].upper())
                home_abbr = home_team.get('abbreviation', home_name[:3].upper())

                away_score = str(away.get('score', '0'))
                home_score = str(home.get('score', '0'))
                away_logo = away_team.get('logo', '')
                home_logo = home_team.get('logo', '')

                # Determine display score / matchup
                if state == 'PRE':
                    score_str = f"vs {home_abbr}"
                    clock_str = short_detail
                elif state == 'IN':
                    score_str = f"{away_score} - {home_score}"
                    clock_str = f"LIVE • {short_detail}"
                else:  # POST
                    score_str = f"{away_score} - {home_score}"
                    clock_str = "Final"

                events_out.append({
                    "id": ev.get('id', ''),
                    "league": league,
                    "name": ev.get('name', f"{away_name} at {home_name}"),
                    "short_name": ev.get('shortName', f"{away_abbr} @ {home_abbr}"),
                    "state": state,
                    "detail": detail,
                    "clock": clock_str,
                    "score": score_str,
                    "away_name": away_name,
                    "home_name": home_name,
                    "away_abbr": away_abbr,
                    "home_abbr": home_abbr,
                    "away_score": away_score,
                    "home_score": home_score,
                    "away_logo": away_logo,
                    "home_logo": home_logo,
                    "search_terms": f"{away_name} {home_name} {away_abbr} {home_abbr}".lower()
                })
    except Exception as e:
        log(f"Error fetching {league} scoreboard: {e}", 2 if KODI_ENV else 1)
    return events_out

def refresh_all_scores(force: bool = False) -> Dict[str, Any]:
    """Refreshes all sports scoreboards if cache is older than 90 seconds."""
    cache_file = get_cache_path()
    now = time.time()

    if not force and os.path.exists(cache_file):
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                cached = json.load(f)
            last_updated = cached.get('last_updated', 0)
            if now - last_updated < 90:
                return cached
        except Exception:
            pass

    log("Refreshing live sports scores from feeds...", 1)
    all_events: Dict[str, List[Dict[str, Any]]] = {}
    total_live = 0

    for league, url in LEAGUE_ENDPOINTS.items():
        events = fetch_league_scoreboard(league, url)
        all_events[league] = events
        total_live += sum(1 for e in events if e.get('state') == 'IN')

    payload = {
        "last_updated": now,
        "total_live": total_live,
        "leagues": all_events
    }

    try:
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2)
    except Exception as e:
        log(f"Failed to write cache: {e}", 2 if KODI_ENV else 1)

    return payload

def apply_gameday_to_skin(data: Optional[Dict[str, Any]] = None) -> None:
    """Sets Kodi window properties for Home.xml skin rendering."""
    if not KODI_ENV:
        return

    if not data:
        cache_file = get_cache_path()
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            except Exception:
                data = None

    if not data:
        data = refresh_all_scores()

    win = xbmcgui.Window(10000)  # Home Window
    total_live = data.get('total_live', 0)
    win.setProperty('AntiVenom.GameDay.TotalLive', str(total_live))

    leagues = data.get('leagues', {})
    for league, events in leagues.items():
        # Top 8 games per league
        for i, ev in enumerate(events[:8], start=1):
            prefix = f"AntiVenom.GameDay.{league}.{i}."
            win.setProperty(f"{prefix}Active", "true")
            win.setProperty(f"{prefix}Matchup", ev.get('name', ''))
            win.setProperty(f"{prefix}Short", ev.get('short_name', ''))
            win.setProperty(f"{prefix}Score", ev.get('score', ''))
            win.setProperty(f"{prefix}Clock", ev.get('clock', ''))
            win.setProperty(f"{prefix}State", ev.get('state', 'PRE'))
            win.setProperty(f"{prefix}AwayName", ev.get('away_name', ''))
            win.setProperty(f"{prefix}HomeName", ev.get('home_name', ''))
            win.setProperty(f"{prefix}AwayAbbr", ev.get('away_abbr', ''))
            win.setProperty(f"{prefix}HomeAbbr", ev.get('home_abbr', ''))
            win.setProperty(f"{prefix}AwayScore", ev.get('away_score', '0'))
            win.setProperty(f"{prefix}HomeScore", ev.get('home_score', '0'))
            win.setProperty(f"{prefix}AwayLogo", ev.get('away_logo', ''))
            win.setProperty(f"{prefix}HomeLogo", ev.get('home_logo', ''))
            win.setProperty(f"{prefix}SearchTerms", ev.get('search_terms', ''))

            # Quick status color for skin: Red for IN (live), Gray for POST, Gold for PRE
            state = ev.get('state')
            if state == 'IN':
                color = "crimson"
                badge = "[B][COLOR crimson]● LIVE[/COLOR][/B]"
            elif state == 'POST':
                color = "dimgray"
                badge = "[COLOR gray]FINAL[/COLOR]"
            else:
                color = "gold"
                badge = f"[COLOR gold]{ev.get('clock')}[/COLOR]"
            win.setProperty(f"{prefix}Badge", badge)
            win.setProperty(f"{prefix}Color", color)

        # Clear remaining unused slots up to 8
        for i in range(len(events) + 1, 9):
            prefix = f"AntiVenom.GameDay.{league}.{i}."
            win.clearProperty(f"{prefix}Active")

def find_best_game_match(query: str) -> Optional[Dict[str, Any]]:
    """Matches a scraper sports title or query against the latest live scores cache."""
    cache_file = get_cache_path()
    if not os.path.exists(cache_file):
        return None

    try:
        with open(cache_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        return None

    q_lower = query.lower()
    best_match = None
    max_score = 0

    leagues = data.get('leagues', {})
    for league, events in leagues.items():
        for ev in events:
            # Check team names in query
            terms = [
                ev.get('away_name', '').lower(),
                ev.get('home_name', '').lower(),
                ev.get('away_abbr', '').lower(),
                ev.get('home_abbr', '').lower()
            ]
            matches = sum(1 for t in terms if t and t in q_lower)
            if matches >= 2 and matches > max_score:
                max_score = matches
                best_match = ev

    return best_match
