import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import sys
import json
import time
import shutil
import traceback
import urllib.request
import zipfile
import re

ADDON       = xbmcaddon.Addon()
ADDON_ID    = ADDON.getAddonInfo('id')
ADDON_PATH  = ADDON.getAddonInfo('path')
ADDON_DATA  = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
HOME_DIR    = xbmcvfs.translatePath('special://home/')
ADDONS_DIR  = os.path.join(HOME_DIR, 'addons')
SKIN_ID     = 'skin.antivenom'
SKIN_SRC    = os.path.join(ADDON_PATH, SKIN_ID)          # bundled inside our zip
SKIN_DEST   = os.path.join(ADDONS_DIR, SKIN_ID)          # where Kodi loads skins from
DONE_FLAG   = os.path.join(ADDON_DATA, '.setup_complete')

# Remote repository / version checking URL
UPDATE_URL = 'https://raw.githubusercontent.com/jaymac4453/venmons/main/version.json'
GITHUB_RELEASE_API = 'https://api.github.com/repos/jaymac4453/venmons/releases/latest'

def log(msg):
    xbmc.log(f'[AntiVenom] {msg}', xbmc.LOGINFO)

# ─────────────────────────────────────────────
#  Step 0: Force The Crew Netflix Views
# ─────────────────────────────────────────────
def force_views():
    try:
        import sqlite3
        views_db = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.thecrew/views.db')
        os.makedirs(os.path.dirname(views_db), exist_ok=True)
        conn = sqlite3.connect(views_db)
        c = conn.cursor()
        c.execute('CREATE TABLE IF NOT EXISTS views (skin TEXT, view_type TEXT, view_id TEXT, UNIQUE(skin, view_type))')
        
        # 54 = InfoWall in our custom Estuary clone
        views = [
            ('skin.antivenom', 'movies', '500'),
            ('skin.antivenom', 'tvshows', '500'),
            ('skin.antivenom', 'seasons', '500'),
            ('skin.antivenom', 'episodes', '500'),
            ('skin.antivenom', 'files', '500'),
            ('skin.antivenom', 'addons', '500'),
            ('skin.antivenom', 'videos', '500')
        ]
        for record in views:
            c.execute('REPLACE INTO views (skin, view_type, view_id) VALUES (?, ?, ?)', record)
            
        conn.commit()
        conn.close()
        log('Forced Netflix Wall views (500) in The Crew DB!')

        # Also register visual InfoWall (131126 = 54) in Kodi's ViewModes6.db
        viewmodes_db = xbmcvfs.translatePath('special://profile/Database/ViewModes6.db')
        if os.path.isfile(viewmodes_db):
            vconn = sqlite3.connect(viewmodes_db)
            vc = vconn.cursor()
            paths = [
                'plugin://plugin.video.thecrew/?action=tvNetworks',
                'plugin://plugin.video.thecrew/?action=tvGenres',
                'plugin://plugin.video.thecrew/?action=movieGenres'
            ]
            for p in paths:
                vc.execute('INSERT OR REPLACE INTO view (window, path, viewMode, sortMethod, sortOrder, sortAttributes, skin) VALUES (?, ?, ?, ?, ?, ?, ?)',
                           (10025, p, 500, 0, 1, 0, 'skin.antivenom'))
            sports_paths = [
                'plugin://plugin.video.thecrew/?action=nfl',
                'plugin://plugin.video.thecrew/?action=ncaa',
                'plugin://plugin.video.thecrew/?action=cfb',
                'plugin://plugin.video.thecrew/?action=nba',
                'plugin://plugin.video.thecrew/?action=ncaab',
                'plugin://plugin.video.thecrew/?action=college_sports',
                'plugin://plugin.video.thecrew/?action=mlb',
                'plugin://plugin.video.thecrew/?action=ufc',
                'plugin://plugin.video.thecrew/?action=streamed_basketball',
                'plugin://plugin.video.thecrew/?action=streamed_basketball&content=addons&url=basketball',
                'plugin://plugin.video.thecrew/?action=streamed_basketball&content=videos&url=basketball',
                'plugin://plugin.video.thecrew/?action=streamed_baseball',
                'plugin://plugin.video.thecrew/?action=streamed_baseball&content=addons&url=baseball',
                'plugin://plugin.video.thecrew/?action=streamed_baseball&content=videos&url=baseball',
                'plugin://plugin.video.thecrew/?action=streamed_fight',
                'plugin://plugin.video.thecrew/?action=streamed_fight&content=addons&url=fight',
                'plugin://plugin.video.thecrew/?action=streamed_fight&content=videos&url=fight',
                'plugin://plugin.video.thecrew/?action=streamed_football',
                'plugin://plugin.video.thecrew/?action=streamed_football&content=addons&url=american-football',
                'plugin://plugin.video.thecrew/?action=streamed_football&content=videos&url=american-football',
                'plugin://plugin.video.thecrew/?action=bluehat',
                'plugin://plugin.video.thecrew/?action=fifa',
                'plugin://plugin.video.thecrew/?action=f1',
                'plugin://plugin.video.thecrew/?action=boxing',
                'plugin://plugin.video.thecrew/?action=nhl',
                'plugin://plugin.video.thecrew/?action=wwe',
                'plugin://plugin.video.thecrew/?action=nascar',
                'plugin://plugin.video.thecrew/?action=sports_channels',
                'plugin://plugin.video.thecrew/?action=sreplays'
            ]
            for sp in sports_paths:
                vc.execute('INSERT OR REPLACE INTO view (window, path, viewMode, sortMethod, sortOrder, sortAttributes, skin) VALUES (?, ?, ?, ?, ?, ?, ?)',
                           (10025, sp, 500, 0, 1, 0, 'skin.antivenom'))
            vconn.commit()
            vconn.close()
            log('Forced Netflix Wall view modes (500) in ViewModes6.db!')
        init_crew_search_db()
    except Exception as e:
        log(f'Failed to force views: {e}')

def init_crew_search_db():
    """Ensure The Crew search databases have 'movies', 'tvshow', and 'people' tables so searches never fail."""
    stamp = os.path.join(ADDON_DATA, '.crew_search_db_ok')
    if os.path.isfile(stamp):
        return
    try:
        import sqlite3
        targets = [
            xbmcvfs.translatePath('special://profile/addon_data/plugin.video.thecrew/search.1.db'),
            xbmcvfs.translatePath('special://profile/addon_data/plugin.video.thecrew/search.db'),
            xbmcvfs.translatePath('special://profile/addon_data/script.module.thecrew/search.1.db'),
            xbmcvfs.translatePath('special://profile/addon_data/script.module.thecrew/search.db'),
        ]
        for db_file in targets:
            try:
                os.makedirs(os.path.dirname(db_file), exist_ok=True)
                conn = sqlite3.connect(db_file)
                c = conn.cursor()
                c.execute('CREATE TABLE IF NOT EXISTS movies (id INTEGER PRIMARY KEY AUTOINCREMENT, term TEXT)')
                c.execute('CREATE TABLE IF NOT EXISTS tvshow (id INTEGER PRIMARY KEY AUTOINCREMENT, term TEXT)')
                c.execute('CREATE TABLE IF NOT EXISTS people (id INTEGER PRIMARY KEY AUTOINCREMENT, term TEXT)')
                conn.commit()
                conn.close()
            except Exception as inner_e:
                log(f'Error initializing db {db_file}: {inner_e}')
        log('The Crew search database tables verified.')
        os.makedirs(ADDON_DATA, exist_ok=True)
        with open(stamp, 'w') as f:
            f.write('1')
    except Exception as e:
        log(f'Failed to initialize Crew search DB: {e}')

# ─────────────────────────────────────────────
#  Step 1: Install skin.antivenom + switch to it
# ─────────────────────────────────────────────
def install_skin():
    """Copy the bundled skin.antivenom into Kodi's addons folder and activate it."""
    if not os.path.isdir(SKIN_SRC):
        log(f'Bundled skin not found at {SKIN_SRC}')
        return False

    try:
        # Never rmtree the live skin: Android FUSE fails with errno 39 (Directory not empty)
        # or errno 16 (Device busy) and leaves a half-deleted skin. Copy/sync only.
        _deploy_skin_files()
        return activate_skin()
    except Exception as e:
        log(f'Skin install error: {e}\n{traceback.format_exc()}')
        return False


def _deploy_skin_files():
    """Install or update SKIN_DEST without deleting the live tree.

    If the dest folder does not exist, copytree is used. If it exists (or copytree
    fails because Android already has the path open), only sync files in place.
    """
    if os.path.isdir(SKIN_DEST):
        repaired = sync_installed_skin()
        log(f'Skin already present; synced {repaired} file(s) from bundled copy')
        return repaired
    try:
        shutil.copytree(SKIN_SRC, SKIN_DEST)
        log(f'Installed skin to {SKIN_DEST}')
        return True
    except OSError as e:
        # isdir() can be false while the path is still busy on Android FUSE.
        log(f'Skin copytree failed ({e}); falling back to in-place sync')
        if os.path.exists(SKIN_DEST):
            return sync_installed_skin()
        raise


def critical_skin_missing():
    """True if addon.xml or any CRITICAL_SKIN_FILES entry is absent from SKIN_DEST."""
    if not os.path.isfile(os.path.join(SKIN_DEST, 'addon.xml')):
        return True
    for rel in CRITICAL_SKIN_FILES:
        if not os.path.isfile(os.path.join(SKIN_DEST, rel.replace('/', os.sep))):
            return True
    return False

def _skin_registered():
    try:
        resp = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Addons.GetAddonDetails',
            'params': {'addonid': SKIN_ID, 'properties': ['enabled', 'installed']}
        })))
        return 'result' in resp
    except Exception:
        return False

def activate_skin():
    """Register, enable and switch to skin.antivenom, verifying each step.

    Settings are changed only through JSON-RPC; Kodi persists guisettings.xml itself.
    Writing that file while Kodi runs corrupts it and resets every setting on next boot.
    """
    if xbmc.getSkinDir() == SKIN_ID:
        return True

    for attempt in range(6):
        if _skin_registered():
            break
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(1500)
    else:
        log('Skin activation failed: Kodi never registered skin.antivenom (check addon.xml / storage)')
        return False

    xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1,
        'method': 'Addons.SetAddonEnabled',
        'params': {'addonid': SKIN_ID, 'enabled': True}
    }))
    xbmc.sleep(500)
    xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1,
        'method': 'Settings.SetSettingValue',
        'params': {'setting': 'filelists.showparentdiritems', 'value': False}
    }))
    result = xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1,
        'method': 'Settings.SetSettingValue',
        'params': {'setting': 'lookandfeel.skin', 'value': SKIN_ID}
    }))
    log(f'Skin switch result: {result}')

    # Kodi shows "Keep this change?" (dialog 10100) for 10s; a slow stick takes a while to get there.
    for _ in range(40):
        xbmc.sleep(400)
        if xbmcgui.getCurrentWindowDialogId() == 10100:
            xbmc.executebuiltin('SendClick(11)')
            xbmc.sleep(800)
            break
        if xbmc.getSkinDir() == SKIN_ID and xbmcgui.getCurrentWindowDialogId() in (9999, 0):
            break

    active = xbmc.getSkinDir() == SKIN_ID
    log(f'Skin active after switch: {active}')
    return active

# ─────────────────────────────────────────────
#  Step 2: Install streaming addons
# ─────────────────────────────────────────────
def install_streaming_addons(progress, step, total):
    from resources.lib import crewinstall
    step += 1
    base = int(step / total * 100)
    span = max(int(100 / total), 1)

    def _cb(pct, msg):
        progress.update(min(99, base + int(span * pct / 100)), f'Installing The Crew: {msg}')

    if progress.iscanceled():
        return step
    try:
        ok, msg = crewinstall.install_addons(
            ('plugin.video.thecrew', 'script.module.thecrew', 'script.module.pycryptodome'),
            progress=_cb)
        log(f'Setup Crew install: ok={ok} {msg}')
    except Exception as e:
        log(f'Setup Crew install error: {e}\n{traceback.format_exc()}')

    if not progress.iscanceled():
        def _mt_cb(pct, msg):
            progress.update(min(99, base + int(span * pct / 100)), f'Installing Mad Titan Sports: {msg}')
        try:
            from resources.lib import madtitaninstall
            ok, msg = madtitaninstall.install_madtitan(progress=_mt_cb)
            log(f'Setup Mad Titan install: ok={ok} {msg}')
        except Exception as e:
            log(f'Setup Mad Titan install error: {e}\n{traceback.format_exc()}')

    step += 1
    progress.update(int(step/total*100), 'Checking Live TV add-on...')
    # pvr.iptvsimple is a binary add-on; Kodi ships it on Android, so only ask Kodi for it.
    if not _check_addon_installed('pvr.iptvsimple'):
        xbmc.executebuiltin('InstallAddon(pvr.iptvsimple)')
        xbmc.sleep(5000)

    return step

# ─────────────────────────────────────────────
#  Step 3: Configure US Live TV
# ─────────────────────────────────────────────
def configure_iptv(progress, step, total):
    step += 1
    progress.update(int(step/total*100), 'Configuring US Live TV...')
    pvr_data = xbmcvfs.translatePath('special://profile/addon_data/pvr.iptvsimple/')
    os.makedirs(pvr_data, exist_ok=True)
    m3u_path = xbmcvfs.translatePath('special://home/addons/script.antivenom/resources/custom_tv.m3u')
    epg_path = xbmcvfs.translatePath('special://home/addons/script.antivenom/resources/epg.xml')
    settings = (
        '<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n'
        '<settings version="2">\n'
        f'  <setting id="m3uPath">{m3u_path}</setting>\n'
        '  <setting id="m3uPathType">0</setting>\n'
        f'  <setting id="epgPath">{epg_path}</setting>\n'
        '  <setting id="epgPathType">0</setting>\n'
        '</settings>\n'
    )
    with open(os.path.join(pvr_data, 'settings.xml'), 'w', encoding='utf-8') as f:
        f.write(settings)
        
    # Kodi 20+ directly reads instance-settings-1.xml in pvr.iptvsimple/
    instance_settings = (
        '<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n'
        '<settings version="2">\n'
        '  <setting id="kodi_addon_instance_name">Migrated Add-on Config</setting>\n'
        '  <setting id="kodi_addon_instance_enabled">true</setting>\n'
        '  <setting id="m3uPathType">0</setting>\n'
        f'  <setting id="m3uPath">{m3u_path}</setting>\n'
        '  <setting id="m3uUrl"></setting>\n'
        '  <setting id="m3uCache">false</setting>\n'
        f'  <setting id="epgPath">{epg_path}</setting>\n'
        '  <setting id="epgPathType">0</setting>\n'
        '  <setting id="epgCache">false</setting>\n'
        '</settings>\n'
    )
    with open(os.path.join(pvr_data, 'instance-settings-1.xml'), 'w', encoding='utf-8') as f:
        f.write(instance_settings)

    # Clean up old m3u cache files and any stray subdirectories
    for f_name in os.listdir(pvr_data):
        if 'cache' in f_name:
            try:
                os.remove(os.path.join(pvr_data, f_name))
            except Exception:
                pass

    instances_dir = os.path.join(pvr_data, 'instances')
    if os.path.exists(instances_dir):
        import shutil
        try:
            shutil.rmtree(instances_dir)
        except Exception as e:
            log(f"Failed to delete PVR instances dir: {e}")

    return step

# ─────────────────────────────────────────────
#  Step 4: Firestick Zero-Buffering & Multi-Scraper Config
# ─────────────────────────────────────────────
def configure_advancedsettings(size_mb=None):
    """Deploy RAM cache settings. Default size comes from the device profile (40MB on 1GB sticks, 100MB otherwise)."""
    try:
        try:
            from resources.lib import deviceprofile
            cap = deviceprofile.cache_size_mb()
            low_power = deviceprofile.is_low_power()
        except Exception:
            cap = 100
            low_power = False
        if not size_mb:
            size_mb = cap
        size_mb = int(size_mb)
        if low_power and size_mb > cap:
            log(f'Capping video cache {size_mb}MB to {cap}MB on 1GB/low-power device')
            size_mb = cap
        mem_bytes = size_mb * 1024 * 1024
        master_profile = xbmcvfs.translatePath('special://masterprofile/')
        os.makedirs(master_profile, exist_ok=True)
        adv_dest = os.path.join(master_profile, 'advancedsettings.xml')
        adv_src = os.path.join(ADDON_PATH, 'resources', 'advancedsettings.xml')
        if os.path.isfile(adv_src):
            with open(adv_src, 'r', encoding='utf-8') as f:
                adv_content = f.read()
            adv_content = re.sub(r'<memorysize>\d+</memorysize>', f'<memorysize>{mem_bytes}</memorysize>', adv_content)
            with open(adv_dest, 'w', encoding='utf-8') as f:
                f.write(adv_content)
            log(f'Deployed advancedsettings.xml ({size_mb}MB cache) to {adv_dest}')
        else:
            content = f'''<advancedsettings version="1.0">
  <cache>
    <buffermode>1</buffermode>
    <memorysize>{mem_bytes}</memorysize>
    <readfactor>20</readfactor>
  </cache>
  <network>
    <curlclienttimeout>15</curlclienttimeout>
    <curllowspeedtime>10</curllowspeedtime>
    <curlretries>2</curlretries>
    <disableipv6>true</disableipv6>
    <curlkeepalive>true</curlkeepalive>
  </network>
  <video>
    <busydialogdelay>500</busydialogdelay>
    <enablehighqualityh264>true</enablehighqualityh264>
  </video>
  <gui>
    <algorithmdirtyregions>3</algorithmdirtyregions>
  </gui>
  <freelibrarycleaner>true</freelibrarycleaner>
  <loglevel hide="true">0</loglevel>
</advancedsettings>'''
            with open(adv_dest, 'w', encoding='utf-8') as f:
                f.write(content)
            log('Created fallback advancedsettings.xml')

        # Kodi 21.3 Omega native GUI cache settings (Settings -> Services -> Caching)
        kodi21_cache = {
            'filecache.buffermode': 1,
            'filecache.memorysize': size_mb,
            'filecache.readfactor': 10,
            'filecache.chunksize': 262144
        }
        for k, v in kodi21_cache.items():
            try:
                xbmc.executeJSONRPC(json.dumps({
                    'jsonrpc': '2.0', 'id': 1,
                    'method': 'Settings.SetSettingValue',
                    'params': {'setting': k, 'value': v}
                }))
            except Exception:
                pass

        # Kodi persists these to guisettings.xml itself on exit. Never write that file while Kodi runs.
        return True
    except Exception as e:
        log(f'Error configuring advancedsettings: {e}')
        return False

def configure_multiscraper():
    """Apply Fast or Full Crew profile — never blindly re-enable every scraper pack."""
    try:
        from resources.lib import deviceprofile
        return deviceprofile.sync_crew_profile(debrid_linked=is_debrid_linked())
    except Exception as e:
        log(f'Error configuring Crew profile: {e}')
        return False

def clean_system_cache(silent=False):
    """Purge temporary video fragments, package zips, and scraper cache to keep Firestick fast."""
    freed_bytes = 0
    cleaned_items = 0
    try:
        # 1. Clean packages folder
        pkg_dir = xbmcvfs.translatePath('special://home/addons/packages/')
        if os.path.isdir(pkg_dir):
            for f in os.listdir(pkg_dir):
                fp = os.path.join(pkg_dir, f)
                try:
                    freed_bytes += os.path.getsize(fp)
                    os.remove(fp)
                    cleaned_items += 1
                except Exception:
                    pass

        # 2. Clean temp folder
        temp_dir = xbmcvfs.translatePath('special://temp/')
        if os.path.isdir(temp_dir):
            for f in os.listdir(temp_dir):
                if f.endswith(('.log', '.fi', '.tmp', '.zip')):
                    fp = os.path.join(temp_dir, f)
                    try:
                        freed_bytes += os.path.getsize(fp)
                        os.remove(fp)
                        cleaned_items += 1
                    except Exception:
                        pass

        # 3. Clean The Crew caches via plugin action
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.thecrew/?action=clearAllCache)')
        try:
            from resources.lib import crewcache
            crewcache.clear()
        except Exception:
            pass

        freed_mb = freed_bytes / (1024 * 1024)
        log(f'Cleaned {cleaned_items} items, freed {freed_mb:.1f} MB')

        if not silent:
            xbmcgui.Dialog().notification(
                'AntiVenom Cleaner',
                f'✓ System Cleaned! Freed {freed_mb:.1f} MB — Firestick Optimized',
                xbmcgui.NOTIFICATION_INFO,
                4000
            )
        return True
    except Exception as e:
        log(f'Clean error: {e}')
        if not silent:
            xbmcgui.Dialog().notification('AntiVenom Cleaner', '✓ Cache Cleared', xbmcgui.NOTIFICATION_INFO, 2000)
        return False

# ─────────────────────────────────────────────
#  Full first-run setup
# ─────────────────────────────────────────────
def run_setup():
    if os.path.exists(DONE_FLAG):
        return True

    progress = xbmcgui.DialogProgress()
    progress.create('AntiVenom Hub', 'Setting up your hub — please wait...')
    try:
        total = 8
        step = 0

        step += 1
        progress.update(int(step/total*100), 'Forcing Netflix views...')
        force_views()

        step += 1
        progress.update(int(step/total*100), 'Installing AntiVenom skin...')
        install_skin()

        step = install_streaming_addons(progress, step, total)
        step = configure_iptv(progress, step, total)

        step += 1
        progress.update(int(step/total*100), 'Applying Zero-Buffering & Multi-Scraper Config...')
        configure_advancedsettings()
        configure_multiscraper()
        clean_system_cache(silent=True)

        step += 1
        progress.update(100, 'Setup complete!')
        xbmc.sleep(1000)
        progress.close()

        os.makedirs(ADDON_DATA, exist_ok=True)
        with open(DONE_FLAG, 'w') as f:
            f.write(str(time.time()))

        xbmcgui.Dialog().notification(
            'AntiVenom Hub', '✓ Setup complete! Restarting to apply your new skin...',
            xbmcgui.NOTIFICATION_INFO, 4000
        )
        xbmc.sleep(3000)

        # Restart Kodi to apply the new skin
        xbmc.executebuiltin('RestartApp')
        return True

    except Exception as e:
        progress.close()
        log(f'Setup error: {e}\n{traceback.format_exc()}')
        xbmcgui.Dialog().ok('AntiVenom Error', f'Setup failed:\n{e}')
        return False

# ─────────────────────────────────────────────
#  Auto System Check (pre-home integrity scan)
# ─────────────────────────────────────────────

# Missing skin files are restored from the skin bundle shipped inside this addon (SKIN_SRC).
# If that bundle is damaged too, the published addon zip is downloaded once and used as the source.
REPO_ZIPS_BASE = 'https://raw.githubusercontent.com/jaymac4453/venmons/main/zips/script.antivenom'

# Every critical skin file relative to the skin root (special://home/addons/skin.antivenom/)
CRITICAL_SKIN_FILES = [
    # Core primitives
    'media/white.png',
    'media/antivenom/black.png',
    # Navigation bar assets
    'media/antivenom/nav/bolt_icon.png',
    'media/antivenom/nav/icon_search_glow.png',
    'media/antivenom/nav/pill_search_glowing.png',
    'media/antivenom/nav/pill_search_glowing_focus.png',
    'media/antivenom/nav/pill_debrid_active.png',
    'media/antivenom/nav/pill_debrid_unlinked.png',
    'media/antivenom/nav/avatar.png',
    # Background/hero
    'media/antivenom/bg/home.jpg',
    'media/antivenom/bg/hero_card.png',
    'media/antivenom/bg/stitch_hero_panel.png',
    # Card frames
    'media/antivenom/cards/card_normal.png',
    'media/antivenom/cards/card_focus_ring.png',
    # Pills / buttons
    'media/antivenom/pills/btn_play.png',
    'media/antivenom/pills/btn_play_focus.png',
    'media/antivenom/pills/btn_glass.png',
    'media/antivenom/pills/btn_glass_focus.png',
    'media/antivenom/pills/btn_search_glow.png',
    'media/antivenom/pills/btn_search_glow_focus.png',
    'media/antivenom/pills/icon_play.png',
    'media/antivenom/pills/icon_info.png',
    'media/antivenom/pills/icon_star.png',
    'media/antivenom/pills/badge_resume.png',
    'media/antivenom/pills/badge_marvel.png',
    'media/antivenom/pills/badge_debrid_ultra.png',
    'media/antivenom/pills/badge_4k_uhd.png',
    'media/antivenom/pills/badge_hdr10.png',
    'media/antivenom/pills/badge_dolby.png',
    'media/antivenom/pills/badge_2024.png',
    'media/antivenom/pills/badge_imdb.png',
    'media/antivenom/pills/badge_pg13.png',
    # Skin XML
    'xml/Home.xml',
    'xml/MyVideoNav.xml',
    # Addon descriptor
    'addon.xml',
]

# Required Kodi addons — (display_name, addon_id)
REQUIRED_ADDONS = [
    ('The Crew',          'plugin.video.thecrew'),
    ('ResolveURL',        'script.module.resolveurl'),
    ('IPTV Simple',       'pvr.iptvsimple'),
    ('PyCryptodome',      'script.module.pycryptodome'),
]

# Installed by resources/lib/crewinstall.py (direct zip download), not Kodi's InstallAddon.
DIRECT_INSTALL_ADDONS = ('plugin.video.thecrew', 'script.module.resolveurl', 'script.module.pycryptodome')

def _check_addon_installed(addon_id):
    """True if the add-on is in the home addons folder or shipped with Kodi."""
    if os.path.isfile(os.path.join(ADDONS_DIR, addon_id, 'addon.xml')):
        return True
    return bool(xbmc.getCondVisibility(f'System.HasAddon({addon_id})'))

_REPAIR_ZIP = {'path': None, 'tried': False}

def _get_repair_zip():
    """Download the published addon zip once per run (fallback source for missing skin files)."""
    if _REPAIR_ZIP['tried']:
        return _REPAIR_ZIP['path']
    _REPAIR_ZIP['tried'] = True

    zip_url = None
    try:
        req = urllib.request.Request(UPDATE_URL, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=8) as resp:
            zip_url = json.loads(resp.read().decode('utf-8')).get('zip_url')
    except Exception as e:
        log(f'version.json unavailable for repair, using installed version: {e}')
    if not zip_url:
        zip_url = f'{REPO_ZIPS_BASE}/script.antivenom-{ADDON.getAddonInfo("version")}.zip'

    tmp = os.path.join(HOME_DIR, '_av_repair.zip')
    try:
        req = urllib.request.Request(zip_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=60) as resp, open(tmp, 'wb') as out_f:
            shutil.copyfileobj(resp, out_f)
        if zipfile.is_zipfile(tmp):
            _REPAIR_ZIP['path'] = tmp
            log(f'Downloaded repair source {zip_url}')
    except Exception as e:
        log(f'Could not download repair zip {zip_url}: {e}')
    return _REPAIR_ZIP['path']

def _cleanup_repair_zip():
    p = _REPAIR_ZIP['path']
    if p and os.path.exists(p):
        try:
            os.remove(p)
        except Exception:
            pass
    _REPAIR_ZIP['path'] = None
    _REPAIR_ZIP['tried'] = False

def _download_skin_file(relative_path):
    """
    Restore a missing skin file. relative_path is relative to the skin root, e.g. 'media/white.png'.
    Source order: 1) skin bundle inside this addon (offline), 2) published addon zip on GitHub.
    Returns True if the file is now present.
    """
    skin_root = os.path.join(ADDONS_DIR, SKIN_ID)
    rel_os = relative_path.replace('/', os.sep)
    dest = os.path.join(skin_root, rel_os)
    if os.path.isfile(dest):
        return True
    try:
        os.makedirs(os.path.dirname(dest), exist_ok=True)

        bundled = os.path.join(SKIN_SRC, rel_os)
        if os.path.isfile(bundled):
            shutil.copy2(bundled, dest)
            return True

        repair_zip = _get_repair_zip()
        if repair_zip:
            member = f'script.antivenom/{SKIN_ID}/{relative_path.replace(os.sep, "/")}'
            with zipfile.ZipFile(repair_zip, 'r') as z:
                if member in z.namelist():
                    with z.open(member) as src, open(dest, 'wb') as out_f:
                        shutil.copyfileobj(src, out_f)
                    return True
            log(f'{member} not found in repair zip')
    except Exception as e:
        log(f'Could not restore {relative_path}: {e}')
    return os.path.isfile(dest)

def sync_installed_skin():
    """Make the installed skin match the copy bundled in this addon.

    Repo skin updates only arrive when the skin version number changes, and an
    interrupted copy on a nearly-full device leaves a partial skin, so compare
    every file and restore anything missing or different. Returns files repaired.
    """
    if not os.path.isdir(SKIN_SRC) or not os.path.isdir(SKIN_DEST):
        return 0
    repaired = 0
    for root, _, files in os.walk(SKIN_SRC):
        for name in files:
            src = os.path.join(root, name)
            dest = os.path.join(SKIN_DEST, os.path.relpath(src, SKIN_SRC))
            try:
                if os.path.isfile(dest) and os.path.getsize(dest) == os.path.getsize(src):
                    if not name.lower().endswith('.xml'):
                        continue
                    with open(src, 'rb') as a, open(dest, 'rb') as b:
                        if a.read() == b.read():
                            continue
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                shutil.copy2(src, dest)
                repaired += 1
            except Exception as e:
                log(f'Skin sync could not update {dest}: {e}')
    if repaired:
        log(f'Skin sync: repaired {repaired} skin file(s) from bundled copy')
    return repaired

def run_system_check(silent=True, repair_addons=True):
    """
    Pre-home integrity scan. silent=False (manual run from Settings) also confirms a healthy result.

    PHASE 1 — Silent pre-scan: quickly checks every file/addon with zero UI.
    If everything is present, marks the session complete and returns immediately
    with no popup, no notification, nothing shown to the user.

    PHASE 2 — Only if something is missing: opens a progress dialog, downloads
    and installs each missing item, then closes the dialog automatically.
    After a successful repair, silence resumes — no further popups until the next
    Kodi session.

    repair_addons=False (service boot): restore missing skin files only. Do not
    walk the whole skin, ReloadSkin, or run InstallAddon loops on every start.
    """
    log('Starting system integrity check (pre-scan)...')
    skin_root = os.path.join(ADDONS_DIR, SKIN_ID)

    # ── PHASE 1: fast silent pre-scan (no full-tree copy, no ReloadSkin) ─
    missing_files  = []
    missing_addons = []

    for rel in CRITICAL_SKIN_FILES:
        full = os.path.join(skin_root, rel.replace('/', os.sep))
        if not os.path.isfile(full):
            missing_files.append(rel)

    # Also check skin deployment itself
    skin_missing = not os.path.isfile(os.path.join(skin_root, 'addon.xml'))

    if repair_addons:
        for display_name, addon_id in REQUIRED_ADDONS:
            if not _check_addon_installed(addon_id):
                missing_addons.append((display_name, addon_id))

    # Everything present — mark done, zero UI, return immediately
    if not missing_files and not missing_addons and not skin_missing:
        log('System check: all prerequisites present — skipping download phase.')
        xbmc.executebuiltin('Skin.SetString(AntiVenomSysCheckDone,1)')
        if not silent:
            xbmcgui.Dialog().notification(
                'AntiVenom System Check',
                '✓ All skin files and add-ons are present',
                xbmcgui.NOTIFICATION_INFO, 4000
            )
        return True

    # Only copy/sync when files are actually missing. Never ReloadSkin on the
    # silent service path — that unloads to Estuary on Fire TV while files copy.
    if missing_files or skin_missing:
        synced = 0
        if os.path.isdir(SKIN_DEST):
            synced = sync_installed_skin()
        elif os.path.isdir(SKIN_SRC):
            try:
                shutil.copytree(SKIN_SRC, SKIN_DEST)
                synced = 1
            except OSError as e:
                log(f'System check copytree failed ({e}); trying in-place sync')
                if os.path.exists(SKIN_DEST):
                    synced = sync_installed_skin()
        if synced and xbmc.getSkinDir() == SKIN_ID and not silent:
            xbmc.executebuiltin('ReloadSkin()')
        missing_files = [rel for rel in CRITICAL_SKIN_FILES
                         if not os.path.isfile(os.path.join(skin_root, rel.replace('/', os.sep)))]
        skin_missing = not os.path.isfile(os.path.join(skin_root, 'addon.xml'))
        if not missing_files and not missing_addons and not skin_missing:
            xbmc.executebuiltin('Skin.SetString(AntiVenomSysCheckDone,1)')
            return True

    if not repair_addons:
        log(f'System check (service): skipping addon InstallAddon loops '
            f'({len(missing_addons)} missing add-on(s) this boot)')
        xbmc.executebuiltin('Skin.SetString(AntiVenomSysCheckDone,1)')
        return not missing_files and not skin_missing

    # ── PHASE 2: something is missing — show progress and fix it ─────────
    total_steps = len(missing_files) + len(missing_addons) + (1 if skin_missing else 0)
    step = 0
    issues_fixed = 0
    issues_failed = 0

    progress = xbmcgui.DialogProgress()
    progress.create(
        'AntiVenom — Downloading Prerequisites',
        f'Found {total_steps} missing item(s) — downloading now...'
    )

    def _upd(msg):
        nonlocal step
        step += 1
        pct = int((step / total_steps) * 100)
        progress.update(pct, msg)
        # Allow user to cancel only from manual invocation (not auto-boot)
        return not progress.iscanceled()

    # Repair missing skin files
    for rel in missing_files:
        ok = _upd(f'Restoring {rel.split("/")[-1]}...')
        if not ok:
            break
        if _download_skin_file(rel):
            issues_fixed += 1
            log(f'System check: restored {rel}')
        else:
            issues_failed += 1
            log(f'System check: FAILED to restore {rel}')

    # Repair missing skin deployment
    if skin_missing:
        ok = _upd('Re-deploying AntiVenom skin...')
        if ok:
            install_skin()
            if os.path.isfile(os.path.join(skin_root, 'addon.xml')):
                issues_fixed += 1
            else:
                issues_failed += 1

    # Install missing addons
    for display_name, addon_id in missing_addons:
        ok = _upd(f'Installing {display_name}...')
        if not ok:
            break
        if _check_addon_installed(addon_id):
            fixed = True  # pulled in as a dependency of an earlier item
        elif addon_id in DIRECT_INSTALL_ADDONS:
            try:
                from resources.lib import crewinstall
                roots = crewinstall.CREW_TARGETS if addon_id == 'plugin.video.thecrew' else (addon_id,)
                fixed, detail = crewinstall.install_addons(
                    roots, progress=lambda p, m: progress.update(int(step / total_steps * 100), m))
                log(f'System check: {addon_id} direct install -> {fixed} {detail}')
            except Exception as e:
                log(f'System check: direct install of {addon_id} failed: {e}')
                fixed = False
        else:
            xbmc.executebuiltin(f'InstallAddon({addon_id})')
            for _ in range(15):
                xbmc.sleep(1000)
                if _check_addon_installed(addon_id):
                    break
            fixed = _check_addon_installed(addon_id)
        if fixed:
            issues_fixed += 1
            log(f'System check: installed {addon_id}')
        else:
            issues_failed += 1
            log(f'System check: could NOT install {addon_id}')

    # Close progress — always, even on cancel
    progress.update(100, 'Done!')
    xbmc.sleep(400)
    progress.close()
    _cleanup_repair_zip()

    # Mark session complete so this never fires again until next Kodi boot
    xbmc.executebuiltin('Skin.SetString(AntiVenomSysCheckDone,1)')

    log(f'System check complete: {issues_fixed} fixed, {issues_failed} failed.')

    # Only show a notification if something could NOT be repaired
    if issues_failed > 0:
        xbmcgui.Dialog().notification(
            'AntiVenom System Check',
            f'⚠ {issues_failed} item(s) could not be downloaded. Check your connection.',
            xbmcgui.NOTIFICATION_WARNING, 5000
        )
    # If everything was fixed successfully — silence. No popup.
    return issues_failed == 0

# ─────────────────────────────────────────────
#  Action Handlers (called from skin buttons)
# ─────────────────────────────────────────────
def is_debrid_linked():
    """Returns True if Real-Debrid is actively configured in skin state, vault, or ResolveURL."""
    try:
        if xbmc.getCondVisibility('Skin.HasSetting(RealDebridLinked)'):
            return True
        for vp in get_rd_vault_paths():
            if os.path.isfile(vp):
                try:
                    with open(vp, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    if data.get('RealDebridResolver_token') or data.get('RealDebridResolver_refresh'):
                        return True
                except Exception:
                    pass
        resolveurl_settings = xbmcvfs.translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml')
        if os.path.isfile(resolveurl_settings):
            import xml.etree.ElementTree as ET
            tree = ET.parse(resolveurl_settings)
            root = tree.getroot()
            elem = root.find(".//setting[@id='RealDebridResolver_token']")
            if elem is not None and elem.text and 'default' not in elem.attrib and elem.text.strip():
                return True
    except Exception:
        pass
    return False

def action_setup_wizard(first_run=False):
    dialog = xbmcgui.Dialog()

    # Rule: If Debrid is already set up, bypass wizard completely on first run
    if is_debrid_linked():
        if first_run:
            os.makedirs(ADDON_DATA, exist_ok=True)
            with open(DONE_FLAG, 'w') as f:
                f.write(str(time.time()))
            xbmc.executebuiltin('Skin.SetBool(AntiVenomSetupComplete)')
            log('[AntiVenom] One-time setup wizard bypassed: Real-Debrid is already configured.')
            return
        else:
            relink = dialog.yesno(
                'AntiVenom — Real-Debrid Active',
                '[COLOR #00F5A0][B]✓ Real-Debrid is already active and paired![/B][/COLOR]\n\n'
                'Your credentials are authenticated and saved in the persistent vault.\n\n'
                'Would you like to re-pair your account or tune device cache anyway?',
                yeslabel='Re-run Setup',
                nolabel='Keep Current'
            )
            if not relink:
                return

    welcome_text = (
        "[COLOR #00F5A0][B]Welcome to AntiVenom (Cyber-Luxe Edition)![/B][/COLOR]\n\n"
        "No Real-Debrid account is currently connected.\n\n"
        "Connecting your account unlocks [B]instant 4K HDR streams, Dolby Atmos, and zero-buffering playback[/B].\n\n"
        "Would you like to pair your Real-Debrid account now?"
    )

    if not dialog.yesno('AntiVenom — One-Time Debrid Setup', welcome_text, yeslabel='Pair Debrid Now', nolabel='Skip for Now'):
        os.makedirs(ADDON_DATA, exist_ok=True)
        with open(DONE_FLAG, 'w') as f:
            f.write(str(time.time()))
        xbmc.executebuiltin('Skin.SetBool(AntiVenomSetupComplete)')
        dialog.notification('Real-Debrid', 'You can connect anytime from Settings or Top Menu.', xbmcgui.NOTIFICATION_INFO, 4000)
        return

    # Step 1: Real-Debrid
    rd_choices = [
        '🔑  [COLOR #00F5A0][B]Pair My Real-Debrid Account[/B][/COLOR]  (Recommended for 4K)',
        '⚡  [COLOR #00D2FF]I Have AllDebrid / Premiumize[/COLOR]  (Universal Resolver)',
        '🌐  [COLOR lightgray]Skip / Use Free Multi-Scrapers[/COLOR]  (No Debrid Account)'
    ]
    rd_sel = dialog.select('AntiVenom — Step 1/2: Real-Debrid Account', rd_choices, preselect=0)

    if rd_sel == 0:
        dialog.ok(
            'Pairing Real-Debrid',
            "A pairing popup with your device code will appear next.\n\n"
            "1. On your phone or computer, open:\n"
            "   [COLOR #00D2FF][B]https://real-debrid.com/device[/B][/COLOR]\n\n"
            "2. Enter the code shown on your TV screen.\n\n"
            "3. Once approved, AntiVenom locks your credentials into your device vault permanently!"
        )
        launch_rd_authorization()

    elif rd_sel == 1:
        xbmc.executebuiltin('Addon.OpenSettings(script.module.resolveurl)')
    elif rd_sel == 2:
        dialog.ok(
            'Free Scrapers Configured',
            "Free multi-scraper engines are enabled!\n\n"
            "You can stream movies, TV shows, and live TV immediately.\n"
            "To unlock 4K remuxes anytime, visit Settings -> Real-Debrid Hub."
        )

    # Step 2: Device Performance Optimization
    cache_choices = [
        '🔥  [COLOR #00F5A0][B]Amazon FireStick / Fire TV[/B][/COLOR]  (150MB Zero-Stutter Cache)',
        '📺  [COLOR #00D2FF]Android TV / Shield / Google TV[/COLOR]  (300MB High-RAM Cache)',
        '💻  [COLOR lightgray]PC / Mac / Mini PC[/COLOR]  (500MB High-Speed Cache)',
        '⏭  [COLOR darkgray]Default Kodi Settings[/COLOR]'
    ]
    c_sel = dialog.select('AntiVenom — Step 2/2: Device Tuning', cache_choices, preselect=0)
    if c_sel == 0:
        configure_advancedsettings(size_mb=150)
    elif c_sel == 1:
        configure_advancedsettings(size_mb=300)
    elif c_sel == 2:
        configure_advancedsettings(size_mb=500)

    # Finalize
    force_views()
    configure_multiscraper()

    os.makedirs(ADDON_DATA, exist_ok=True)
    with open(DONE_FLAG, 'w') as f:
        f.write(str(time.time()))
    xbmc.executebuiltin('Skin.SetBool(AntiVenomSetupComplete)')

    dialog.ok(
        'Setup Complete!',
        "[COLOR #00F5A0][B]AntiVenom is ready for your living room![/B][/COLOR]\n\n"
        "• Autocomplete Search: [COLOR #00D2FF]Active[/COLOR]\n"
        "• Stream Scrapers: [COLOR #00D2FF]Ready[/COLOR]\n"
        "• 10-Foot Remote Navigation: [COLOR #00D2FF]Enabled[/COLOR]\n\n"
        "Enjoy your movies, shows, and live TV!"
    )
    xbmc.executebuiltin('ActivateWindow(Home)')

def action_revert_estuary():
    dialog = xbmcgui.Dialog()
    if dialog.yesno('Revert to Default Skin', 'Would you like to switch back to the default Kodi Estuary theme?', yeslabel='Switch to Estuary', nolabel='Cancel'):
        xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Settings.SetSettingValue',
            'params': {'setting': 'lookandfeel.skin', 'value': 'skin.estuary'}
        }))
        for _ in range(40):
            xbmc.sleep(400)
            if xbmcgui.getCurrentWindowDialogId() == 10100:
                xbmc.executebuiltin('SendClick(11)')
                break

def action_setup():
    dialog = xbmcgui.Dialog()
    try:
        from resources.lib import deviceprofile
        fast_label = deviceprofile.fast_mode_menu_label()
        crew_label = deviceprofile.crew_fallback_menu_label()
    except Exception:
        fast_label = '🚀  Fast Mode: ON (tap to turn OFF)'
        crew_label = '🛟  The Crew Backup Search: ON (tap to turn OFF)'
    choice = dialog.select('AntiVenom Settings', [
        '🔍  System Check (Verify & Auto-Repair All Files)',
        '🧙  Launch Setup Wizard (Pair Real-Debrid & Tune Cache)',
        '⚡  Install / Repair The Crew (Streaming Engine)',
        '⚙️  Open Kodi System Settings (Add-ons, Interface, System)',
        '🔄  Switch Back to Default Kodi Skin (Estuary)',
        '🔑  Manage Real-Debrid (Status, Re-auth, Vault)',
        '🎨  Activate AntiVenom Skin',
        '📺  Refresh Live TV Guide',
        '🧹  Clear System & Resolver Cache',
        '🔄  Check for Updates',
        fast_label,
        crew_label,
        '⚡  Optimize for Speed (re-apply Fast Mode now)',
        '⏻  Exit AntiVenom',
        '📨  Send Problem Report to Developer',
        '🎬  Ambient Trailers On/Off (off = faster browsing)',
        'Close'
    ])
    if choice == 0:
        run_system_check(silent=False)
    elif choice == 1:
        action_setup_wizard(first_run=False)
    elif choice == 2:
        ensure_crew_available(force=True)
    elif choice == 3:
        xbmc.executebuiltin('ActivateWindow(Settings)')
    elif choice == 4:
        action_revert_estuary()
    elif choice == 5:
        action_manage_debrid()
    elif choice == 6:
        install_skin()
        dialog.ok('AntiVenom Skin', 'AntiVenom custom theme has been activated!')
    elif choice == 7:
        xbmc.executebuiltin('RunPlugin(plugin://pvr.iptvsimple/?mode=update)')
    elif choice == 8:
        clean_system_cache(silent=False)
    elif choice == 9:
        action_check_update(manual=True)
    elif choice == 10:
        action_toggle_fast_mode()
    elif choice == 11:
        action_toggle_crew_fallback()
    elif choice == 12:
        action_optimize_speed()
    elif choice == 13:
        xbmc.executebuiltin('Quit')
    elif choice == 14:
        action_send_report()
    elif choice == 15:
        action_toggle_ambient()

def action_toggle_fast_mode():
    from resources.lib import deviceprofile
    dialog = xbmcgui.Dialog()
    was_on = deviceprofile.is_fast_mode_enabled()
    if was_on:
        if not dialog.yesno(
            'Turn Off Fast Mode?',
            'Fast Mode will turn OFF.\n\n'
            'AntiVenom will restore more scraper packs, longer timeouts, '
            'and The Crew source directory so you can pick links manually.\n\n'
            'Turn Fast Mode off?',
            yeslabel='Turn Off',
            nolabel='Keep On',
        ):
            return
        deviceprofile.set_fast_mode_enabled(False)
        deviceprofile.sync_crew_profile(debrid_linked=is_debrid_linked())
        dialog.ok(
            'Fast Mode Off',
            'Fast Mode is now OFF.\n\n'
            'All scraper packs are enabled again and source picking is restored.',
        )
    else:
        deviceprofile.set_fast_mode_enabled(True)
        deviceprofile.sync_crew_profile(debrid_linked=is_debrid_linked())
        dialog.ok(
            'Fast Mode On',
            'Fast Mode is ON again.\n\n'
            '• Crew + Classy scrapers only (~8s timeout)\n'
            '• Auto-play best stream with 3 automatic backups\n'
            '• Real-Debrid cached-first when linked',
        )

def action_toggle_crew_fallback():
    from resources.lib import deviceprofile
    dialog = xbmcgui.Dialog()
    if deviceprofile.is_crew_fallback_enabled():
        if not dialog.yesno(
            'Turn Off The Crew Backup?',
            'When no instant Real-Debrid copy is found, AntiVenom will NOT run '
            'The Crew search (it scrapes many sites and is slow on Fire Sticks).\n\n'
            'Instead it will offer to have Real-Debrid download it for you.\n\n'
            'Turn The Crew backup search off?',
            yeslabel='Turn Off',
            nolabel='Keep On',
        ):
            return
        deviceprofile.set_crew_fallback_enabled(False)
        dialog.ok('The Crew Backup Off', 'The Crew backup search is now OFF.\n\n'
                  'Play uses Real-Debrid instant copies only (Torrentio, then Comet).')
    else:
        deviceprofile.set_crew_fallback_enabled(True)
        dialog.ok('The Crew Backup On', 'The Crew backup search is ON again.\n\n'
                  'If no instant Real-Debrid copy is found, The Crew searches as a last resort.')

def action_optimize_speed():
    from resources.lib import deviceprofile
    msg = deviceprofile.optimize_for_speed_now(
        debrid_linked=is_debrid_linked(),
        configure_advancedsettings_fn=configure_advancedsettings,
        clean_cache_fn=clean_system_cache,
    )
    xbmcgui.Dialog().ok('Optimize for Speed', msg)

def action_toggle_ambient():
    on = xbmc.getCondVisibility('Skin.HasSetting(AmbientTrailers)')
    xbmc.executebuiltin('Skin.ToggleSetting(AmbientTrailers)')
    now_on = not on
    xbmcgui.Dialog().notification(
        'Ambient Trailers',
        'Enabled (browsing may be slower)' if now_on else 'Disabled (faster browsing)',
        xbmcgui.NOTIFICATION_INFO, 4000
    )

def action_send_report():
    dialog = xbmcgui.Dialog()
    note = dialog.input('What went wrong? (e.g. "Settings is a black screen")')
    from resources.lib import crashreport
    progress = xbmcgui.DialogProgress()
    progress.create('AntiVenom', 'Sending your problem report...')
    try:
        link = crashreport.send_report('Manual report', note.strip() or '(no description)', manual=True)
    finally:
        progress.close()
    if link:
        code = link.rstrip('/').rsplit('/', 1)[-1]
        dialog.ok('Report Sent', f'Thanks! Your report was delivered.\n\nReport code: [B]{code}[/B]')
    else:
        dialog.ok('Report Failed', 'Could not send the report. Check your internet connection and try again.')

# ─────────────────────────────────────────────
#  Real-Debrid Permanent Vault & Manager
# ─────────────────────────────────────────────
def get_rd_vault_paths():
    paths = [
        xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/rd_vault.json'),
        xbmcvfs.translatePath('special://masterprofile/rd_vault.json'),
        xbmcvfs.translatePath('special://home/rd_vault.json')
    ]
    for p in ['/sdcard/AntiVenom_rd_vault.json', '/storage/emulated/0/AntiVenom_rd_vault.json', '/sdcard/Android/data/org.xbmc.kodi/files/rd_vault.json']:
        try:
            if os.path.exists(os.path.dirname(p)):
                paths.append(p)
        except Exception:
            pass
    return paths

def _ensure_six():
    """ResolveURL's Real-Debrid plugin does `from six.moves import urllib_error`. A fresh stick often has no script.module.six."""
    try:
        import six.moves.urllib_error  # noqa: F401
        return
    except Exception:
        pass
    import types
    import urllib.error
    six = types.ModuleType('six')
    six.PY2 = False
    six.PY3 = True
    moves = types.ModuleType('six.moves')
    moves.urllib_error = urllib.error
    six.moves = moves
    sys.modules['six'] = six
    sys.modules['six.moves'] = moves
    sys.modules['six.moves.urllib_error'] = urllib.error


def launch_rd_authorization():
    """Launch Real-Debrid device pairing reliably from script dialogs.

    RunPlugin() fired immediately after yesno/ok dialogs often does nothing in Kodi.
    Calling ResolveURL directly (with a short delay) shows the pairing code popup.
    """
    resolveurl_lib = xbmcvfs.translatePath('special://home/addons/script.module.resolveurl/lib')
    if not os.path.isdir(resolveurl_lib):
        xbmcgui.Dialog().ok(
            'ResolveURL Required',
            'Real-Debrid pairing needs [B]script.module.resolveurl[/B].\n\n'
            'Install it from the AntiVenom repository, then try again.'
        )
        return False

    if resolveurl_lib not in sys.path:
        sys.path.insert(0, resolveurl_lib)
    _ensure_six()

    try:
        xbmc.sleep(500)
        from resolveurl.plugins.realdebrid import RealDebridResolver
        ok = RealDebridResolver().authorize_resolver()
        if ok:
            sync_realdebrid_vault()
            xbmcgui.Dialog().notification('Real-Debrid', 'Account linked successfully!', xbmcgui.ICON_INFO, 5000)
        return bool(ok)
    except Exception as e:
        log(f'RD direct authorization failed: {e}')
        xbmc.executebuiltin(
            'AlarmClock(AntiVenomRDAuth,RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd),00:00:01,silent)'
        )
        xbmcgui.Dialog().notification(
            'Real-Debrid',
            'Opening pairing screen... enter the code at real-debrid.com/device',
            xbmcgui.NOTIFICATION_INFO,
            6000
        )
        return None

def check_and_refresh_rd_token(creds):
    token = creds.get('RealDebridResolver_token')
    refresh = creds.get('RealDebridResolver_refresh')
    client_id = creds.get('RealDebridResolver_client_id', '763AE7OFYINMA')
    client_secret = creds.get('RealDebridResolver_client_secret', 'fbd4ae9583b0bca261644ef66534ebaa8ca481b7')

    if not token and not refresh:
        return creds, False

    need_refresh = False
    if token:
        try:
            import urllib.request, urllib.error
            req = urllib.request.Request(
                'https://api.real-debrid.com/rest/1.0/user',
                headers={'Authorization': f'Bearer {token}', 'User-Agent': 'AntiVenom/4.0'}
            )
            with urllib.request.urlopen(req, timeout=4) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode('utf-8'))
                    username = data.get('username', 'Active User')
                    xbmc.executebuiltin(f'Skin.SetString(RealDebridUser,{username})')
                    return creds, False
        except urllib.error.HTTPError as e:
            if e.code == 401:
                need_refresh = True
            else:
                return creds, False
        except Exception:
            return creds, False
    else:
        need_refresh = True

    if need_refresh and refresh:
        try:
            import urllib.request, urllib.parse
            post_data = urllib.parse.urlencode({
                'client_id': client_id,
                'client_secret': client_secret,
                'code': refresh,
                'grant_type': 'http://oauth.net/grant_type/device/1.0'
            }).encode('utf-8')
            req = urllib.request.Request(
                'https://api.real-debrid.com/oauth/v2/token',
                data=post_data,
                headers={'User-Agent': 'AntiVenom/4.0'}
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                new_token = res.get('access_token')
                new_refresh = res.get('refresh_token') or refresh
                if new_token:
                    creds['RealDebridResolver_token'] = new_token
                    creds['RealDebridResolver_refresh'] = new_refresh
                    creds['RealDebridResolver_client_id'] = client_id
                    creds['RealDebridResolver_client_secret'] = client_secret
                    creds['RealDebridResolver_enabled'] = 'true'
                    creds['RealDebridResolver_login'] = 'true'
                    creds['RealDebridResolver_torrents'] = 'true'
                    creds['RealDebridResolver_cached_only'] = 'false'
                    creds['RealDebridResolver_priority'] = '50'
                    return creds, True
        except Exception as e:
            log(f'RD OAuth refresh error: {e}')

    return creds, False

def sync_realdebrid_vault():
    """Sync ResolveURL credentials with multi-location permanent vault and auto-refresh."""
    try:
        resolveurl_settings = xbmcvfs.translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml')
        rd_keys = [
            'RealDebridResolver_token',
            'RealDebridResolver_refresh',
            'RealDebridResolver_client_id',
            'RealDebridResolver_client_secret',
            'RealDebridResolver_enabled',
            'RealDebridResolver_login',
            'RealDebridResolver_torrents',
            'RealDebridResolver_priority',
            'RealDebridResolver_cached_only'
        ]

        active_creds = None
        if os.path.isfile(resolveurl_settings):
            import xml.etree.ElementTree as ET
            tree = ET.parse(resolveurl_settings)
            root = tree.getroot()
            token_node = None
            for s in root.findall('setting'):
                if s.attrib.get('id') == 'RealDebridResolver_token':
                    token_node = s
                    break

            if token_node is not None and token_node.text and 'default' not in token_node.attrib and token_node.text.strip():
                saved = {}
                for s in root.findall('setting'):
                    sid = s.attrib.get('id')
                    if sid in rd_keys and s.text:
                        saved[sid] = s.text.strip()
                if saved.get('RealDebridResolver_token'):
                    active_creds = saved

        # If ResolveURL lacked credentials, read from any vault
        if not active_creds:
            for vp in get_rd_vault_paths():
                try:
                    if os.path.isfile(vp):
                        with open(vp, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                        if data.get('RealDebridResolver_token') or data.get('RealDebridResolver_refresh'):
                            active_creds = data
                            break
                except Exception:
                    pass

        if active_creds:
            # Check and auto-refresh token if expired
            active_creds, refreshed = check_and_refresh_rd_token(active_creds)

            # Save to all vault locations
            for vp in get_rd_vault_paths():
                try:
                    os.makedirs(os.path.dirname(vp), exist_ok=True)
                    with open(vp, 'w', encoding='utf-8') as f:
                        json.dump(active_creds, f, indent=4)
                except Exception:
                    pass

            # Write to ResolveURL settings
            os.makedirs(os.path.dirname(resolveurl_settings), exist_ok=True)
            import xml.etree.ElementTree as ET
            if os.path.isfile(resolveurl_settings):
                tree = ET.parse(resolveurl_settings)
                root = tree.getroot()
            else:
                root = ET.Element('settings')
                tree = ET.ElementTree(root)

            existing = {s.attrib.get('id'): s for s in root.findall('setting')}
            changed = False
            for k, v in active_creds.items():
                if k in existing:
                    if existing[k].text != str(v) or 'default' in existing[k].attrib:
                        existing[k].text = str(v)
                        if 'default' in existing[k].attrib:
                            del existing[k].attrib['default']
                        changed = True
                else:
                    el = ET.SubElement(root, 'setting', {'id': k})
                    el.text = str(v)
                    changed = True

            if changed or not os.path.isfile(resolveurl_settings):
                tree.write(resolveurl_settings, encoding='utf-8', xml_declaration=False)

            xbmc.executebuiltin('Skin.SetBool(RealDebridLinked)')
            xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Active)')
            return True

        xbmc.executebuiltin('Skin.Reset(RealDebridLinked)')
        xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Unlinked)')
        return False
    except Exception as e:
        log(f'RD Vault sync error: {e}')
        return False

def action_manage_debrid():
    dialog = xbmcgui.Dialog()
    is_linked = sync_realdebrid_vault()

    if is_linked:
        vault_file = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/rd_vault.json')
        options = [
            '✅  Status: Active & Remembered (Permanent)',
            '🔄  Re-Authorize Real-Debrid (Pair New Code / Device)',
            '💾  Save / Lock Current Credentials to Vault',
            '⚙  Open ResolveURL Debrid & Scraper Settings',
            '🗑  Clear / Disconnect Real-Debrid Account'
        ]
        sel = dialog.select('AntiVenom — Real-Debrid Hub', options)
        if sel == 0:
            dialog.ok('Real-Debrid Active', 'Your Real-Debrid account is active and permanently saved!\n\nAntiVenom automatically restores your authorization every time Kodi launches or updates, so you never have to sign in again.')
        elif sel == 1:
            launch_rd_authorization()
        elif sel == 2:
            sync_realdebrid_vault()
            dialog.ok('Credentials Saved', 'Your Real-Debrid token has been locked into the secure vault:\nrd_vault.json\n\nIt will persist forever across all updates.')
        elif sel == 3:
            xbmc.executebuiltin('Addon.OpenSettings(script.module.resolveurl)')
        elif sel == 4:
            if dialog.yesno('Disconnect Real-Debrid', 'Are you sure you want to disconnect and wipe saved Real-Debrid credentials?'):
                try:
                    if os.path.exists(vault_file):
                        os.remove(vault_file)
                    resolveurl_settings = xbmcvfs.translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml')
                    if os.path.isfile(resolveurl_settings):
                        import xml.etree.ElementTree as ET
                        tree = ET.parse(resolveurl_settings)
                        root = tree.getroot()
                        for s in list(root.findall('setting')):
                            if 'RealDebrid' in s.attrib.get('id', ''):
                                root.remove(s)
                        tree.write(resolveurl_settings, encoding='utf-8', xml_declaration=False)
                    xbmc.executebuiltin('Skin.Reset(RealDebridLinked)')
                    xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Unlinked)')
                    dialog.ok('Disconnected', 'Real-Debrid has been removed.')
                except Exception as e:
                    dialog.ok('Error', f'Failed to disconnect: {e}')
    else:
        if dialog.yesno('Authorize Real-Debrid', 
                        'Real-Debrid provides instant multi-gigabit 4K/1080p cached torrent streams with zero buffering.\n\nWould you like to authorize your Real-Debrid account now?\n(AntiVenom will permanently remember your login!)',
                        nolabel='Cancel', yeslabel='Authorize Now'):
            launch_rd_authorization()

# ─────────────────────────────────────────────
#  Search & Category Handlers
# ─────────────────────────────────────────────
def _get_search_db():
    for f in ['search.1.db', 'search.db']:
        p = xbmcvfs.translatePath(f'special://profile/addon_data/plugin.video.thecrew/{f}')
        if os.path.exists(p):
            return p
    return None

def action_search_movies(query=None):
    if not ensure_crew_available():
        return
    init_crew_search_db()
    if not query:
        kb = xbmc.Keyboard('', 'Search Movies & Blockbusters')
        kb.doModal()
        if not kb.isConfirmed():
            return
        query = kb.getText().strip()
    if query:
        import urllib.parse
        target = f'plugin://plugin.video.thecrew/?action=movieSearchterm&name={urllib.parse.quote_plus(query)}'
        open_crew_window(target)

def action_search_shows(query=None):
    if not ensure_crew_available():
        return
    init_crew_search_db()
    if not query:
        kb = xbmc.Keyboard('', 'Search TV Shows & Streaming Exclusives')
        kb.doModal()
        if not kb.isConfirmed():
            return
        query = kb.getText().strip()
    if query:
        import urllib.parse
        target = f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={urllib.parse.quote_plus(query)}'
        open_crew_window(target)

def action_universal_search():
    """Netflix-style context-aware instant search. Zero interrupting modal dialogs."""
    init_crew_search_db()
    active_tab = xbmc.getInfoLabel('Skin.String(ActiveTab)').lower().strip()
    if active_tab == 'tvshows':
        action_search_shows()
        return
    elif active_tab == 'movies':
        action_search_movies()
        return
    elif active_tab == 'sports':
        action_search_sports()
        return
    elif active_tab == 'livetv':
        action_search_livetv()
        return

    # From Home / Favorites tab: prompt keyboard once and auto-route seamlessly
    kb = xbmc.Keyboard('', 'Search Movies & TV Shows')
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return

    # Auto-detect media type via TMDB multi-search with zero dialog disruption
    media_type = 'movie'
    try:
        import urllib.request
        import urllib.parse
        import json
        tmdb_key = '0049795edb57568b95240bc9e61a9dfc'
        url = f'https://api.themoviedb.org/3/search/multi?api_key={tmdb_key}&query={urllib.parse.quote_plus(query)}&page=1'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=4.0) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            results = [r for r in data.get('results', []) if r.get('media_type') in ['movie', 'tv']]
            if results:
                top = results[0]
                if top.get('media_type') == 'tv':
                    media_type = 'shows'
                else:
                    media_type = 'movies'
    except Exception as e:
        xbmc.log(f'[AntiVenom] Smart search classification fallback: {e}', xbmc.LOGDEBUG)

    if media_type == 'shows':
        action_search_shows(query=query)
    else:
        action_search_movies(query=query)

def action_search_hub():
    dialog = xbmcgui.Dialog()
    options = [
        'Search Everything (Auto-Detect Movies & Shows)',
        'Search TV Shows & Streaming Exclusives',
        'Search Movies & Cinema Releases',
        'Explore Live Sports Streams (F1, UFC, NFL, NBA...)',
        'Browse Streaming Networks & Studios (Netflix, Max, Apple, Disney+)',
    ]
    sel = dialog.select('AntiVenom Search', options)
    if sel == 0:
        action_universal_search()
    elif sel == 1:
        action_search_shows()
    elif sel == 2:
        action_search_movies()
    elif sel == 3:
        action_search_sports()
    elif sel == 4:
        open_crew_window('plugin://plugin.video.thecrew/?action=tvNetworks')

def action_search_sports():
    """Prompt user with on-screen keyboard to search sports teams, fighters, or events."""
    kb = xbmc.Keyboard('', 'Search Live Sports, Teams & Events')
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return
    
    q_lower = query.lower()
    
    # Keyword map for common sports searches
    sport_keywords = [
        (['nfl', 'football', 'chiefs', 'eagles', 'cowboys', 'patriots', '49ers', 'packers', 'steelers', 'super bowl', 'redzone'], 'nfl'),
        (['nba', 'basketball', 'lakers', 'warriors', 'celtics', 'bulls', 'heat', 'knicks', 'curry', 'lebron'], 'nba'),
        (['ufc', 'mma', 'fight', 'mcgregor', 'jones', 'adesanya', 'pereira', 'makhachev', 'bellator', 'pfl'], 'ufc'),
        (['f1', 'formula', 'formula 1', 'grand prix', 'verstappen', 'hamilton', 'leclerc', 'norris', 'ferrari', 'red bull'], 'f1'),
        (['soccer', 'fifa', 'premier league', 'epl', 'champions league', 'laliga', 'madrid', 'barcelona', 'arsenal', 'liverpool', 'chelsea', 'manchester', 'messi', 'ronaldo'], 'fifa'),
        (['boxing', 'box', 'tyson', 'canelo', 'fury', 'joshua', 'usyk', 'crawford', 'inoue'], 'boxing'),
        (['wwe', 'wrestling', 'raw', 'smackdown', 'wrestlemania', 'roman reigns', 'cody rhodes', 'aew'], 'wwe'),
        (['nascar', 'daytona', 'talladega', 'racing', 'indy', 'motogp'], 'nascar'),
        (['mlb', 'baseball', 'yankees', 'dodgers', 'red sox', 'world series'], 'mlb'),
        (['nhl', 'hockey', 'stanley cup', 'bruins', 'rangers', 'maple leafs', 'oilers'], 'nhl'),
        (['ncaa', 'college', 'sec', 'big ten', 'march madness'], 'ncaa'),
        (['ncaab', 'college basketball'], 'ncaab'),
        (['tennis', 'wimbledon', 'us open', 'djokovic', 'alcaraz', 'sinner', 'nadal'], 'tennis'),
        (['espn', 'channel', 'channels', 'fox sports', 'sky sports', 'tnt sports', 'cbs sports'], 'sports_channels'),
        (['replay', 'replays', 'highlights'], 'sreplays'),
    ]
    
    matched_action = None
    for terms, act in sport_keywords:
        if any(term in q_lower for term in terms):
            matched_action = act
            break
            
    if matched_action == 'sports_channels':
        action_sports('sports_bucket', {'bucket': 'live'})
    elif matched_action == 'sreplays':
        action_sports('sports_bucket', {'bucket': 'replay'})
    elif matched_action:
        action_sports('sports_games', {'key': matched_action})
    else:
        action_sports('sports_league', {'key': 'all_live'})

def action_search_livetv():
    """Prompt user with on-screen keyboard to search live channels without modal dialogs."""
    kb = xbmc.Keyboard('', 'Search Live Cable TV Channels')
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return
    target = 'plugin://plugin.video.thecrew/?action=sports_channels'
    if xbmcgui.getCurrentWindowId() == 10025:
        xbmc.executebuiltin(f'Container.Update({target})')
    else:
        xbmc.executebuiltin(f'ActivateWindow(Videos,{target},return)')
        _force_wall_view()

def hold_crew_play(play_url, title):
    """Start Crew playback; Fast Mode adds up to three automatic backup streams.

    Returns True when playback started.
    """
    repair_crew_settings()
    try:
        from resources.lib import deviceprofile
        if deviceprofile.is_fast_mode_enabled():
            from resources.lib import playfallback
            log(f'fast play {title} {play_url}')
            return bool(playfallback.play_with_fallback(play_url, title))
        deviceprofile.ensure_crew_autoplay()
    except Exception as e:
        log(f'hold_crew_play profile error: {e}')
    log(f'play {title} {play_url}')
    safe_url = play_url.replace('\\', '\\\\').replace('"', '\\"')
    xbmc.executebuiltin('PlayMedia("%s")' % safe_url)
    quiet = 0
    held = 0
    while held < 80 and quiet < 24:
        if xbmc.Player().isPlaying():
            log(f'play {title} started')
            return True
        try:
            dialog = int(xbmcgui.getCurrentWindowDialogId())
        except Exception:
            dialog = 0
        if dialog in (10101, 10138, 12000, 12002, 10100):
            quiet = 0
            held += 1
            xbmc.sleep(500)
            continue
        quiet += 1
        xbmc.sleep(250)
    playing = xbmc.Player().isPlaying()
    log(f'play {title} released (playing={playing} held={held})')
    return playing


def play_via_debrid(label, imdb, crew_url_for, season='', episode='', lookup_name='', year='', tmdb=''):
    """Play button flow: Real-Debrid instant copy, then The Crew (if allowed), then offer an RD download.

    crew_url_for(imdb) builds The Crew play URL once the IMDb id is known.
    """
    from resources.lib import deviceprofile, imdblookup
    fast = deviceprofile.is_fast_mode_enabled()
    imdb = imdblookup.clean(imdb)
    thumb = xbmc.getInfoLabel('ListItem.Art(poster)') or xbmc.getInfoLabel('ListItem.Thumb') or ''
    result = None
    if fast:
        try:
            from resources.lib import debridengine
            result = debridengine.find_and_play(label, imdb, season or None, episode or None,
                                                lookup_title=lookup_name or label, year=year, thumb=thumb, tmdb=tmdb)
            if result.played:
                log(f'cached Real-Debrid play started for {label}')
                return
            if result.cancelled:
                log(f'cached Real-Debrid play cancelled by user for {label}')
                return
            imdb = result.imdb or imdb
            log(f'cached Real-Debrid miss for {label} ({result.reason})')
        except Exception as rd_err:
            log(f'cached Real-Debrid play error: {rd_err}')

    # If imdb is still missing before Crew fallback, perform resilient multi-tiered resolution
    if not imdb:
        try:
            kind = 'series' if season and episode else 'movie'
            imdb = imdblookup.resolve(lookup_name or label, year, kind, tmdb=tmdb)
        except Exception:
            pass

    crew_allowed = (not fast) or deviceprofile.is_crew_fallback_enabled()
    if crew_allowed:
        if ensure_crew_available():
            if hold_crew_play(crew_url_for(imdb or '0'), label):
                return
        elif not fast:
            return
    else:
        log(f'The Crew backup search is off; skipping it for {label}')

    if fast and result is not None and result.has_token and imdb:
        try:
            from resources.lib import debridengine
            debridengine.offer_download(label, imdb, season or None, episode or None,
                                        lookup_title=lookup_name or label, year=year, thumb=thumb, tmdb=tmdb)
        except Exception as dl_err:
            log(f'Real-Debrid download offer error: {dl_err}')
    elif not crew_allowed:
        xbmcgui.Dialog().notification('AntiVenom', f'No instant copy found for {label}',
                                      xbmcgui.NOTIFICATION_INFO, 4000)


def open_crew_window(crew_url, force_view=True):
    """Open a Crew directory. Catalog lists (Movies/TV) go through AntiVenom's disk cache."""
    if not crew_url:
        return
    repair_crew_settings()
    target = crew_url
    try:
        from resources.lib import crewcache
        target = crewcache.browse_target(crew_url)
    except Exception as e:
        log(f'crew cache wrap skipped: {e}')
        target = crew_url
    if xbmcgui.getCurrentWindowId() == 10025:
        xbmc.executebuiltin(f'Container.Update({target})')
    else:
        xbmc.executebuiltin(f'ActivateWindow(Videos,{target},return)')
        if force_view:
            _force_wall_view()


def repair_crew_settings():
    """Kodi 21 refuses to load a corrupt/empty Crew settings.xml — play then does nothing."""
    path = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.thecrew/settings.xml')
    if not os.path.isfile(path):
        return False
    try:
        if os.path.getsize(path) < 20:
            raise ValueError('empty settings.xml')
        import xml.etree.ElementTree as ET
        ET.parse(path)
        return False
    except Exception as e:
        bad = path + '.bad'
        try:
            if os.path.isfile(bad):
                os.remove(bad)
            os.replace(path, bad)
        except Exception:
            try:
                os.remove(path)
            except Exception:
                pass
        log(f'Repaired corrupt The Crew settings.xml ({e})')
        return True


def action_movie_categories():
    """Directly open The Crew Movie Genres in Netflix Wall View (zero dialogs)."""
    if not ensure_crew_available():
        return
    open_crew_window('plugin://plugin.video.thecrew/?action=movieGenres')

def action_tv_categories():
    """Directly open The Crew TV Networks in Netflix Wall View (zero dialogs)."""
    if not ensure_crew_available():
        return
    open_crew_window('plugin://plugin.video.thecrew/?action=tvNetworks')

def action_browse_networks():
    """Directly open The Crew TV Networks directory in Netflix Wall View."""
    action_tv_categories()

def action_open_studio(network='Netflix'):
    """Directly launch a streaming studio's TV shows in Netflix Wall View."""
    if not ensure_crew_available():
        return
    studios = {
        'Netflix': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=213',
        'Apple TV+': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=2552',
        'Apple': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=2552',
        'HBO Max': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=3186|49',
        'Max': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=3186|49',
        'HBO': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=49|3186',
        'Disney+': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=2739',
        'Disney': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=2739',
        'Prime Video': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=1024',
        'Amazon Prime': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=1024',
        'Amazon': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=1024',
        'Paramount+': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=4330|2076|67',
        'Paramount': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=4330|2076|67',
        'Hulu': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=453|88|1035',
        'FX': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=88|1035',
        'FX / Hulu': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=453|88|1035',
        'FX on Hulu': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=453|88|1035',
        'Starz': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=318',
        'Showtime': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=67',
        'Peacock': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=3353|6|30',
        'MGM+': 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=6219|922',
    }
    target = studios.get(network)
    if not target:
        import urllib.parse
        target = f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={urllib.parse.quote_plus(network)}'
    open_crew_window(target)


def _crew_ready():
    return bool(xbmc.getCondVisibility('System.HasAddon(plugin.video.thecrew)')
                and xbmc.getCondVisibility('System.HasAddon(script.module.thecrew)'))

CREW_MANUAL_STEPS = (
    '1. Settings > System > Add-ons: turn ON [B]Unknown sources[/B].\n'
    '2. Settings > File manager > Add source: [B]https://team-crew.github.io[/B] (name it crew).\n'
    '3. Add-ons > Install from zip file > crew > [B]repository.thecrew-0.3.8.zip[/B].\n'
    '4. Install from repository > The Crew Repo > Video add-ons > [B]The Crew[/B] > Install.'
)

def _crew_manual_fallback(reason):
    """Automatic install failed: offer Kodi's own installer (repo is already in place) or the manual steps."""
    dialog = xbmcgui.Dialog()
    if dialog.yesno('The Crew Install',
                    f'AntiVenom could not finish installing The Crew.\n{reason}\n\n'
                    'Try Kodi\'s installer now, or see the manual steps?',
                    yeslabel='Kodi installer', nolabel='Manual steps'):
        xbmc.executebuiltin('InstallAddon(plugin.video.thecrew)')
        return
    dialog.textviewer('Install The Crew manually', CREW_MANUAL_STEPS)

def run_crew_install():
    """Direct install of The Crew + script.module.thecrew + dependencies. Returns True when usable."""
    from resources.lib import crewinstall
    progress = xbmcgui.DialogProgress()
    progress.create('Installing The Crew', 'Connecting to The Crew repository...')
    try:
        ok, detail = crewinstall.install_crew(progress=lambda p, m: progress.update(p, m))
    except Exception as e:
        log(f'Crew install crashed: {e}\n{traceback.format_exc()}')
        ok, detail = False, str(e)
    finally:
        progress.close()
    log(f'Crew install result: ok={ok} {detail}')
    if ok and not _crew_ready():
        # Kodi can take a moment to flip System.HasAddon after enabling.
        for _ in range(10):
            xbmc.sleep(500)
            if _crew_ready():
                break
    if ok:
        repair_crew_settings()
        init_crew_search_db()
        force_views()
        xbmcgui.Dialog().notification('AntiVenom', 'The Crew is installed and ready',
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        return True
    _crew_manual_fallback(detail)
    return False

def ensure_crew_available(force=False):
    """Make sure The Crew is usable; installs it automatically when it is missing."""
    if not force and _crew_ready():
        repair_crew_settings()
        init_crew_search_db()
        return True

    if not force:
        ok = xbmcgui.Dialog().yesno(
            'AntiVenom Streaming Engine Required',
            '[COLOR #00F5A0][B]The Crew playback engine is required to stream movies, shows, sports and search.[/B][/COLOR]\n\n'
            'Install The Crew automatically now? (about 1 minute)',
            yeslabel='Install Now',
            nolabel='Cancel'
        )
        if not ok:
            return False
    return run_crew_install()

def _force_wall_view(delay_ms=800):
    """Force Netflix-style Wall view (500) after ActivateWindow navigation."""
    # Use AlarmClock - survives script exit unlike threading
    xbmc.executebuiltin('AlarmClock(AntiVenomWallView,Container.SetViewMode(500),00:02,silent)')

def action_sports_section(section=None):
    """Older skin links: Sports / Live Games / College / Pros / Replay Games."""
    bucket = {'live': 'live', 'college': 'college', 'pros': 'pros',
              'replays': 'replay', 'replay': 'replay'}.get((section or '').lower())
    if bucket:
        action_sports('sports_bucket', {'bucket': bucket})
    else:
        action_sports('sports_menu', {})


def run_madtitan_install():
    """Direct install of Mad Titan Sports + the Magnetic repo + dependencies. Returns True when usable."""
    from resources.lib import madtitaninstall
    progress = xbmcgui.DialogProgress()
    progress.create('Installing Mad Titan Sports', 'Connecting to the Magnetic repository...')
    try:
        ok, detail = madtitaninstall.install_madtitan(progress=lambda p, m: progress.update(p, m))
    except Exception as e:
        log(f'Mad Titan install crashed: {e}\n{traceback.format_exc()}')
        ok, detail = False, str(e)
    finally:
        progress.close()
    log(f'Mad Titan install result: ok={ok} {detail}')
    if ok and not madtitaninstall.is_installed():
        for _ in range(10):
            xbmc.sleep(500)
            if madtitaninstall.is_installed():
                break
    if ok:
        xbmcgui.Dialog().notification('AntiVenom', 'Mad Titan Sports is installed and ready',
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        return True
    xbmcgui.Dialog().ok('Mad Titan Sports',
                        f'AntiVenom could not finish installing Mad Titan Sports.\n{detail}\n\n'
                        'Check the internet connection and open Sports again.')
    return False

def ensure_madtitan_available():
    """Sports run on Mad Titan Sports; install it automatically when it is missing."""
    from resources.lib import madtitaninstall
    if madtitaninstall.is_installed():
        return True
    ok = xbmcgui.Dialog().yesno(
        'AntiVenom Sports',
        '[COLOR #00F5A0][B]Sports now stream through Mad Titan Sports.[/B][/COLOR]\n\n'
        'Install it automatically now? (about 1 minute)',
        yeslabel='Install Now',
        nolabel='Cancel'
    )
    if not ok:
        return False
    return run_madtitan_install()

def action_sports(action, args):
    """Sports: Live games / College / Pros / Replay games (resources/lib/sportshub.py)."""
    try:
        from resources.lib.gameday import refresh_all_scores
        refresh_all_scores()
    except Exception:
        pass
    from resources.lib import sportshub
    if action not in ('sports_open', 'sports_notice') and not ensure_crew_available():
        handle = sportshub.plugin_handle()
        if handle is not None:
            import xbmcplugin
            xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    sportshub.route(action, args)

def action_sports_live(sport=None):
    from resources.lib import sportshub
    key = sportshub.league_key(sport)
    if (sport or '').lower() == 'channels':
        action_sports('sports_bucket', {'bucket': 'live'})
    elif key:
        action_sports('sports_league', {'key': key})
    else:
        action_sports('sports_menu', {})

def action_sports_replays(args=None):
    args = args or {}
    if args.get('key') or args.get('sport'):
        action_sports('sports_replays', args)
    else:
        action_sports('sports_bucket', {'bucket': 'replay'})

def action_play_smart_sport(sport=None, query=None):
    """GameDay cards: open that league's streams in The Crew."""
    if (sport or '').lower() == 'nfl' and query:
        try:
            from resources.lib import sportshub
            sportshub.play_nfl(query)
            return
        except Exception:
            pass
    if query:
        xbmcgui.Dialog().notification('AntiVenom Sports', f'Opening The Crew streams for {query}...', xbmcgui.NOTIFICATION_INFO, 2500)
    action_sports_live(sport)

def action_gameday_live_games():
    """GameDay HUD: Display live and active games or today's slate with direct stream access."""
    try:
        from resources.lib.gameday import refresh_all_scores, _load_cache, _event_is_today
        data = refresh_all_scores() or _load_cache() or {}
    except Exception as e:
        xbmc.log(f'[AntiVenom] gameday_live_games error: {e}', xbmc.LOGWARNING)
        data = {}

    leagues = data.get('leagues', {})
    live_items = []
    today_items = []

    for league, events in leagues.items():
        for ev in (events or []):
            state = str(ev.get('state', '')).upper()
            matchup = ev.get('name') or ev.get('short_name') or 'Matchup'
            score = ev.get('score', '')
            clock = ev.get('clock', '')
            league_code = str(league).upper()

            if state == 'IN':
                score_str = f"{score} · " if score and score != '0 - 0' else ""
                label = f"[B][COLOR crimson][{league_code}][/COLOR][/B]  [COLOR white]{matchup}[/COLOR]  [COLOR gold]({score_str}{clock})[/COLOR]"
                live_items.append({
                    'label': label,
                    'league': league,
                    'matchup': matchup,
                    'state': state
                })
            elif _event_is_today(ev) and state != 'POST':
                label = f"[COLOR gold][{league_code}][/COLOR] [COLOR white]{matchup}[/COLOR] [COLOR gray]({clock or 'TODAY'})[/COLOR]"
                today_items.append({
                    'label': label,
                    'league': league,
                    'matchup': matchup,
                    'state': state
                })

    dialog = xbmcgui.Dialog()
    if live_items:
        options = [item['label'] for item in live_items]
        options.append("[B][COLOR #00F5A0]>> View All Live Sports & Channels[/COLOR][/B]")
        options.append("[B][COLOR #00F5A0]>> Open The Crew Sports Center[/COLOR][/B]")

        sel = dialog.select(f"GameDay Active Games ({len(live_items)} Live Now)", options)
        if sel < 0:
            return
        if sel < len(live_items):
            chosen = live_items[sel]
            action_play_smart_sport(sport=chosen['league'].lower(), query=chosen['matchup'])
        elif sel == len(live_items):
            action_sports('sports_bucket', {'bucket': 'live'})
        elif sel == len(live_items) + 1:
            action_sports('sports_league', {'key': 'all_live'})
    elif today_items:
        options = [item['label'] for item in today_items]
        options.append("[B][COLOR #00F5A0]>> View All Live Sports & Channels[/COLOR][/B]")

        sel = dialog.select(f"GameDay Slate ({len(today_items)} Games Today)", options)
        if sel < 0:
            return
        if sel < len(today_items):
            chosen = today_items[sel]
            action_play_smart_sport(sport=chosen['league'].lower(), query=chosen['matchup'])
        else:
            action_sports('sports_bucket', {'bucket': 'live'})
    else:
        dialog.notification('AntiVenom GameDay', 'No live games currently active. Opening live sports...', xbmcgui.NOTIFICATION_INFO, 2500)
        action_sports('sports_bucket', {'bucket': 'live'})

def action_sports_status_notice(status=None, title=None, time_str=None, sport=None):
    """Notice dialog when user clicks an upcoming or completed game card."""
    dialog = xbmcgui.Dialog()
    status_upper = str(status or '').upper()
    title = title or 'Game'
    time_str = time_str or ''

    if status_upper == 'UPCOMING':
        msg = f"{title}\nScheduled: {time_str}\n\nThis game has not started yet. Open league live streams anyway?"
        if dialog.yesno('Game Upcoming', msg, yeslabel='Open Streams', nolabel='Cancel'):
            if sport:
                action_sports_live(sport)
            else:
                action_sports('sports_bucket', {'bucket': 'live'})
    elif status_upper == 'FINAL':
        msg = f"{title}\nThis game has concluded.\n\nWould you like to open Sports Replays?"
        if dialog.yesno('Game Final', msg, yeslabel='Replays', nolabel='Cancel'):
            action_sports_replays({'sport': sport} if sport else {})
    else:
        action_sports_live(sport)

def action_open_genre(genre=None, content='movie'):
    """Open Crew movie or tv genre directory."""
    if not ensure_crew_available():
        return
    if (content or '').lower() == 'tv':
        url = 'plugin://plugin.video.thecrew/?action=tvGenres'
    else:
        url = 'plugin://plugin.video.thecrew/?action=movieGenres'
    open_crew_window(url)

def action_kids_youtube():
    """Launch Kids category or YouTube Kids channels."""
    if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
        xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.youtube/,return)')
    else:
        open_crew_window('plugin://plugin.video.thecrew/?action=tvGenres')

TMDB_API_KEY = '0049795edb57568b95240bc9e61a9dfc'

# Home row titles. IMDb ids checked against Cinemeta (name + year) and Torrentio.
MOVIE_METADATA = {
    'deadpool & wolverine': {'year': '2024', 'imdb': 'tt6263850', 'tmdb': '533535'},
    'dune: part two': {'year': '2024', 'imdb': 'tt15239678', 'tmdb': '693134'},
    'venom: the last dance': {'year': '2024', 'imdb': 'tt16366836', 'tmdb': '912649'},
    'alien: romulus': {'year': '2024', 'imdb': 'tt18412256', 'tmdb': '945961'},
    'gladiator ii': {'year': '2024', 'imdb': 'tt9218128', 'tmdb': '558449'},
    'the batman': {'year': '2022', 'imdb': 'tt1877830', 'tmdb': '414906'},
    'furiosa: a mad max saga': {'year': '2024', 'imdb': 'tt12037194', 'tmdb': '786892'},
    'civil war': {'year': '2024', 'imdb': 'tt17279496', 'tmdb': '929590'},
    'blade runner 2049': {'year': '2017', 'imdb': 'tt1856101', 'tmdb': '335984'},
    'sicario': {'year': '2015', 'imdb': 'tt3397918', 'tmdb': '273481'},
    'american gangster': {'year': '2007', 'imdb': 'tt0765429', 'tmdb': '4982'},
    'training day': {'year': '2001', 'imdb': 'tt0139654', 'tmdb': '2034'},
    'boyz n the hood': {'year': '1991', 'imdb': 'tt0101507', 'tmdb': '650'},
    'new jack city': {'year': '1991', 'imdb': 'tt0102526', 'tmdb': '10960'},
    'the departed': {'year': '2006', 'imdb': 'tt0407887', 'tmdb': '1422'},
    'scarface': {'year': '1983', 'imdb': 'tt0086250', 'tmdb': '111'},
    'city of god': {'year': '2002', 'imdb': 'tt0317248', 'tmdb': '598'},
    'the wonderful autumn of mickey mouse': {'year': '2022', 'imdb': 'tt21272676', 'tmdb': '1031827'},
    'the wonderful summer of mickey mouse': {'year': '2022', 'imdb': 'tt18693892', 'tmdb': '951119'},
    'the wonderful spring of mickey mouse': {'year': '2022', 'imdb': 'tt18357064', 'tmdb': '941126'},
    'the wonderful winter of mickey mouse': {'year': '2022', 'imdb': 'tt16972048', 'tmdb': '913867'},
}

SHOW_METADATA = {
    'stranger things': {'year': '2016', 'imdb': 'tt4574334', 'tmdb': '66732'},
    'severance': {'year': '2022', 'imdb': 'tt11280740', 'tmdb': '95396'},
    'house of the dragon': {'year': '2022', 'imdb': 'tt11198330', 'tmdb': '94997'},
    'the boys': {'year': '2019', 'imdb': 'tt1190634', 'tmdb': '76479'},
    'shogun': {'year': '2024', 'imdb': 'tt2788316', 'tmdb': '126308'},
    'shōgun': {'year': '2024', 'imdb': 'tt2788316', 'tmdb': '126308'},
    'the penguin': {'year': '2024', 'imdb': 'tt15435876', 'tmdb': '194764'},
    'squid game': {'year': '2021', 'imdb': 'tt10919420', 'tmdb': '93405'},
    'fallout': {'year': '2024', 'imdb': 'tt12637874', 'tmdb': '106379'},
    'silo': {'year': '2023', 'imdb': 'tt14688458', 'tmdb': '125988'},
    'cyberpunk: edgerunners': {'year': '2022', 'imdb': 'tt12590266', 'tmdb': '105248'},
    'snowfall': {'year': '2017', 'imdb': 'tt6439752', 'tmdb': '71694'},
    'power': {'year': '2014', 'imdb': 'tt3717208', 'tmdb': '54650'},
    'bmf': {'year': '2021', 'imdb': 'tt10651164', 'tmdb': '129888'},
    'godfather of harlem': {'year': '2019', 'imdb': 'tt8080122', 'tmdb': '82772'},
    'the wire': {'year': '2002', 'imdb': 'tt0306414', 'tmdb': '1438'},
    'top boy': {'year': '2011', 'imdb': 'tt1830379', 'tmdb': '40059'},
    'narcos': {'year': '2015', 'imdb': 'tt2707408', 'tmdb': '63351'},
    'ozark': {'year': '2017', 'imdb': 'tt5071411', 'tmdb': '69050'},
    'peaky blinders': {'year': '2013', 'imdb': 'tt2442560', 'tmdb': '60574'},
    'the bear': {'year': '2022', 'imdb': 'tt14452776', 'tmdb': '1396'},
    'yellowstone': {'year': '2018', 'imdb': 'tt4236770', 'tmdb': '73586'},
    'reacher': {'year': '2022', 'imdb': 'tt9288030', 'tmdb': '108978'},
    'from': {'year': '2022', 'imdb': 'tt9813792', 'tmdb': '124364'},
    'ted lasso': {'year': '2020', 'imdb': 'tt10986410', 'tmdb': '97546'},
    'wednesday': {'year': '2022', 'imdb': 'tt13443470', 'tmdb': '119051'},
    'the last of us': {'year': '2023', 'imdb': 'tt3581920', 'tmdb': '100088'},
    'succession': {'year': '2018', 'imdb': 'tt7660850', 'tmdb': '76331'},
    'fargo': {'year': '2014', 'imdb': 'tt2802850', 'tmdb': '57243'},
    'only murders in the building': {'year': '2021', 'imdb': 'tt12851524', 'tmdb': '110316'},
    'tulsa king': {'year': '2022', 'imdb': 'tt16358384', 'tmdb': '153312'},
    'mayor of kingstown': {'year': '2021', 'imdb': 'tt11712058', 'tmdb': '97951'},
    'yellowjackets': {'year': '2021', 'imdb': 'tt11041332', 'tmdb': '93740'},
    'dexter': {'year': '2006', 'imdb': 'tt0773262', 'tmdb': '1405'},
    'the mandalorian': {'year': '2019', 'imdb': 'tt8111088', 'tmdb': '82856'},
    'loki': {'year': '2021', 'imdb': 'tt9140554', 'tmdb': '84958'},
    'andor': {'year': '2022', 'imdb': 'tt9253284', 'tmdb': '83867'},
}

def action_trailer_trending_movie(title):
    """Hero 'Trailer & Info' button: play the YouTube trailer if the YouTube addon exists,
    otherwise open the title in The Crew Wall view so the user can reach info/streams."""
    import urllib.parse
    video_key = None
    try:
        search_url = (f'https://api.themoviedb.org/3/search/movie?api_key={TMDB_API_KEY}'
                      f'&query={urllib.parse.quote_plus(title)}')
        req = urllib.request.Request(search_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=4) as resp:
            results = json.loads(resp.read().decode('utf-8')).get('results', [])
        if results:
            tmdb_id = results[0].get('id')
            vid_url = f'https://api.themoviedb.org/3/movie/{tmdb_id}/videos?api_key={TMDB_API_KEY}'
            req = urllib.request.Request(vid_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=4) as resp:
                videos = json.loads(resp.read().decode('utf-8')).get('results', [])
            trailers = [v for v in videos if v.get('site') == 'YouTube' and v.get('type') == 'Trailer']
            if trailers:
                video_key = trailers[0].get('key')
    except Exception as e:
        log(f'Trailer lookup failed for {title}: {e}')

    if video_key and xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
        xbmc.executebuiltin(f'PlayMedia(plugin://plugin.video.youtube/play/?video_id={video_key})')
        return

    if not ensure_crew_available():
        return
    open_crew_window(
        f'plugin://plugin.video.thecrew/?action=movieSearchterm&name={urllib.parse.quote_plus(title)}'
    )

def action_play_next_episode():
    """Triggered by Smart Binge dialog to start next episode instantly."""
    xbmc.executebuiltin('Dialog.Close(1111,true)')
    win = xbmcgui.Window(10000)
    show = win.getProperty('AntiVenom.Binge.ShowTitle')
    next_ep = win.getProperty('AntiVenom.Binge.NextEp')
    xbmcgui.Dialog().notification('Smart Binge', f'Loading {show} {next_ep}...', xbmcgui.NOTIFICATION_INFO, 3000)
    # If Kodi playlist has next item, advance immediately
    if xbmc.PlayList(xbmc.PLAYLIST_VIDEO).size() > 1:
        xbmc.executebuiltin('PlayerControl(Next)')
    else:
        # Search the show to list episodes in Wall view
        target = f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={urllib.parse.quote_plus(show)}'
        open_crew_window(target)

def action_zap_previous():
    """Instant swap back to previous stream in Channel Zapper."""
    win = xbmcgui.Window(10000)
    prev = win.getProperty('AntiVenom.Zapper.PrevStream')
    if prev:
        curr = win.getProperty('AntiVenom.Zapper.CurrStream')
        # Swap
        win.setProperty('AntiVenom.Zapper.PrevStream', curr)
        win.setProperty('AntiVenom.Zapper.CurrStream', prev)
        xbmcgui.Dialog().notification('Channel Zapper', 'Swapping to previous stream...', xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.Player().play(prev)
    else:
        xbmcgui.Dialog().notification('Channel Zapper', 'No previous stream recorded yet', xbmcgui.NOTIFICATION_INFO, 2000)

# ─────────────────────────────────────────────
#  Step 7: In-App One-Click Update (Method C)
# ─────────────────────────────────────────────
def _get_installed_version():
    ver_file = os.path.join(ADDON_DATA, 'installed_version.txt')
    if os.path.exists(ver_file):
        try:
            with open(ver_file, 'r', encoding='utf-8') as f:
                v = f.read().strip()
                if v:
                    return v
        except Exception:
            pass
    return ADDON.getAddonInfo('version')

def _set_installed_version(ver):
    try:
        os.makedirs(ADDON_DATA, exist_ok=True)
        ver_file = os.path.join(ADDON_DATA, 'installed_version.txt')
        with open(ver_file, 'w', encoding='utf-8') as f:
            f.write(str(ver))
        xbmc.executebuiltin(f'Skin.SetString(AntiVenomVersion, {ver})')
    except Exception:
        pass

def _parse_version(v):
    return [int(x) for x in re.sub(r'[^0-9.]', '', str(v or '')).split('.') if x]


def _fetch_update_candidates():
    """Collect every published hub version. GitHub Releases can be stale (latest
    is still v1.0.11) while version.json on main already has a newer zip."""
    candidates = []

    try:
        req = urllib.request.Request(
            UPDATE_URL + '?t=' + str(int(time.time())),
            headers={'User-Agent': 'Mozilla/5.0', 'Cache-Control': 'no-cache'},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            vdata = json.loads(resp.read().decode('utf-8'))
        ver = str(vdata.get('version') or '').lstrip('v').strip()
        zip_url = vdata.get('zip_url') or ''
        lines = vdata.get('changelog') or []
        if ver and zip_url:
            candidates.append({
                'version': ver,
                'zip_url': zip_url,
                'changelog': '\n'.join([f'• {l}' for l in lines]) if lines else '',
                'source': 'version.json',
            })
    except Exception as e_v:
        log(f'Version JSON error: {e_v}')

    try:
        req = urllib.request.Request(GITHUB_RELEASE_API, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        tag = str(data.get('tag_name') or '').lstrip('v').strip()
        zip_url = None
        for asset in data.get('assets') or []:
            aname = (asset.get('name') or '').lower()
            if aname.endswith('.zip') and ('antivenom' in aname or 'script' in aname):
                zip_url = asset.get('browser_download_url')
                break
        if not zip_url and data.get('assets'):
            zip_url = data['assets'][0].get('browser_download_url')
        body = (data.get('body') or '').strip()
        if tag and zip_url:
            candidates.append({
                'version': tag,
                'zip_url': zip_url,
                'changelog': body,
                'source': 'github-release',
            })
    except Exception as e_gh:
        log(f'GitHub Release API error: {e_gh}')

    return candidates


def action_check_update(manual=True):
    dialog = xbmcgui.Dialog()
    current_ver = _get_installed_version()
    log(f'Checking for updates... Current version: {current_ver}')

    progress = xbmcgui.DialogProgress()
    if manual:
        progress.create('AntiVenom Update Check', 'Checking GitHub for a newer hub...')

    candidates = _fetch_update_candidates()
    chosen = None
    if candidates:
        chosen = max(candidates, key=lambda c: _parse_version(c.get('version')))
        log(f'Update candidates: {[(c.get("version"), c.get("source")) for c in candidates]} picked={chosen.get("version")} from {chosen.get("source")}')

    remote_ver = (chosen or {}).get('version')
    zip_url = (chosen or {}).get('zip_url')
    changelog_text = (chosen or {}).get('changelog') or ''

    if manual:
        try:
            progress.close()
        except Exception:
            pass

    if not zip_url or not remote_ver:
        if manual:
            dialog.ok('Update Check', f'Unable to reach GitHub update server.\n\nInstalled Version: v{current_ver}\nPlease verify your internet connection.')
        return

    is_newer = _parse_version(remote_ver) > _parse_version(current_ver)

    if is_newer:
        confirm = dialog.yesno(
            '⚡ AntiVenom Update Available ⚡',
            f'[COLOR lime][B]A new version of AntiVenom is available![/B][/COLOR]\n\n'
            f'Installed: [B]v{current_ver}[/B]   -->   Latest: [COLOR cyan][B]v{remote_ver}[/B][/COLOR]\n\n'
            f'[B]What\'s New in this update:[/B]\n{changelog_text}\n\n'
            f'Would you like to download and install this update now?\n'
            f'[COLOR gray](All your settings and Real-Debrid logins are preserved)[/COLOR]',
            yeslabel='Update Now',
            nolabel='Later'
        )
        if confirm:
            perform_update(zip_url, remote_ver)
    else:
        if manual:
            reinstall = dialog.yesno(
                'AntiVenom is Up to Date',
                f'[COLOR lime][B]You are running the latest version (v{current_ver})![/B][/COLOR]\n\n'
                f'Latest published: [B]v{remote_ver}[/B]\n\n'
                f'Would you like to force re-download and re-install this build to refresh all files?',
                yeslabel='Re-install',
                nolabel='Close'
            )
            if reinstall:
                perform_update(zip_url, remote_ver)

def perform_update(zip_url, remote_ver):
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    progress.create('Updating AntiVenom', f'Connecting to GitHub for v{remote_ver}...')

    tmp_zip = os.path.join(HOME_DIR, '_antivenom_update.zip')
    try:
        req = urllib.request.Request(zip_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=30) as resp, open(tmp_zip, 'wb') as out_f:
            total_size = int(resp.headers.get('content-length', 0))
            count = 0
            block_size = 65536
            while True:
                chunk = resp.read(block_size)
                if not chunk:
                    break
                out_f.write(chunk)
                count += len(chunk)
                if total_size > 0:
                    percent = int(count * 85 / total_size)
                    progress.update(min(percent, 85), f'Downloading AntiVenom v{remote_ver}... ({percent}% of {total_size//(1024*1024)}MB)')
                else:
                    progress.update(45, f'Downloading AntiVenom v{remote_ver}... ({count//(1024*1024)}MB)')

        progress.update(90, 'Extracting and applying update...')
        with zipfile.ZipFile(tmp_zip, 'r') as zf:
            zf.extractall(ADDONS_DIR)

        if os.path.exists(tmp_zip):
            os.remove(tmp_zip)

        bundled_skin = os.path.join(ADDONS_DIR, 'script.antivenom', SKIN_ID)
        if os.path.isdir(bundled_skin):
            _deploy_skin_files()

        _set_installed_version(remote_ver)
        sync_realdebrid_vault()
        force_views()

        # Ensure skin.antivenom is registered, enabled & active (JSON-RPC only; no guisettings.xml writes)
        activate_skin()

        progress.update(100, 'Update complete! Refreshing interface...')
        xbmc.sleep(1000)
        progress.close()

        dialog.ok('Update Successful!', f'[COLOR lime][B]AntiVenom has been updated to v{remote_ver}![/B][/COLOR]\n\nThe skin has been refreshed with all new features.')
        xbmc.executebuiltin('ReloadSkin()')
    except Exception as e:
        if os.path.exists(tmp_zip):
            try: os.remove(tmp_zip)
            except Exception: pass
        progress.close()
        log(f'Update failed: {e}\n{traceback.format_exc()}')
        dialog.ok('Update Failed', f'Failed to install update: {e}')

# ─────────────────────────────────────────────
#  Entry Point
# ─────────────────────────────────────────────
#  Step 9: Resume Last Watched Media Action
# ─────────────────────────────────────────────
def action_resume_last_watched():
    try:
        resume_file = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/resume_state.json')
        if not os.path.isfile(resume_file):
            xbmcgui.Dialog().notification('AntiVenom', 'No resume point found', xbmcgui.NOTIFICATION_INFO, 3000)
            return

        with open(resume_file, 'r', encoding='utf-8') as f:
            state = json.load(f)

        title = state.get('title', 'Media')
        time_str = state.get('time_str', '0:00')
        seconds = state.get('seconds', 0)
        file_path = state.get('file', '')
        media_type = state.get('type', 'movie')

        dialog = xbmcgui.Dialog()
        choice = dialog.yesno(
            f'Resume {title}',
            f'You stopped watching at {time_str}.\n\nWould you like to resume where you left off or start over from the beginning?',
            yeslabel=f'Resume at {time_str}',
            nolabel='Start from Beginning'
        )

        if choice is None:
            return

        seek_target = seconds if choice else 0

        if file_path and not file_path.startswith('plugin://'):
            item = xbmcgui.ListItem(title)
            if seek_target > 0:
                item.setProperty('ResumeTime', str(seek_target))
            xbmc.Player().play(file_path, item)
            if seek_target > 0:
                def _seek():
                    for _ in range(30):
                        xbmc.sleep(200)
                        if xbmc.Player().isPlaying():
                            xbmc.sleep(500)
                            xbmc.Player().seekTime(float(seek_target))
                            break
                import threading
                threading.Thread(target=_seek).start()
        else:
            import urllib.parse
            if media_type == 'episode':
                target = f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={urllib.parse.quote_plus(title)}'
            else:
                target = f'plugin://plugin.video.thecrew/?action=movieSearchterm&name={urllib.parse.quote_plus(title)}'
            open_crew_window(target)
            if seek_target > 0:
                xbmcgui.Dialog().notification('AntiVenom Resume', f'Select your stream to resume at {time_str}', xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception as e:
        xbmc.log(f'[AntiVenom] Resume error: {e}', xbmc.LOGWARNING)

def handle_continue_watching():
    try:
        handle = int(sys.argv[1])
    except (IndexError, ValueError):
        handle = -1

    continue_file = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/continue_watching.json')
    items = []
    if os.path.isfile(continue_file):
        try:
            with open(continue_file, 'r', encoding='utf-8') as f:
                items = json.load(f)
                if not isinstance(items, list):
                    items = []
        except Exception:
            items = []

    # Fallback to single resume state if continue_watching list is empty
    if not items:
        resume_file = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/resume_state.json')
        if os.path.isfile(resume_file):
            try:
                with open(resume_file, 'r', encoding='utf-8') as f:
                    st = json.load(f)
                    if st and st.get('active'):
                        items = [st]
            except Exception:
                pass

    if handle >= 0:
        import xbmcplugin
        xbmcplugin.setContent(handle, 'videos')
        for it in items:
            title = it.get('title', 'Resume Media')
            sub = it.get('sub_label', '')
            thumb = it.get('thumb', '')
            fanart = it.get('fanart', thumb)
            pct = str(it.get('percent', 0))
            bar_width = str(it.get('bar_width', 120))
            time_str = it.get('time_str', '')
            item_id = it.get('id', str(abs(hash(title))))

            li = xbmcgui.ListItem(label=title, label2=sub)
            li.setArt({
                'thumb': thumb,
                'poster': thumb,
                'fanart': fanart,
                'icon': thumb
            })
            li.setProperty('ResumePercent', pct)
            li.setProperty('ResumeBarWidth', bar_width)
            li.setProperty('ResumeTime', time_str)
            li.setProperty('IsResume', 'true')
            li.setProperty('QualityBadge', 'special://home/addons/skin.antivenom/media/antivenom/pills/badge_card_4k.png')

            vinfo = li.getVideoInfoTag()
            vinfo.setTitle(title)
            if it.get('year') and str(it['year']).isdigit():
                vinfo.setYear(int(it['year']))
            if it.get('plot'):
                vinfo.setPlot(it['plot'])
            if it.get('type') == 'episode':
                vinfo.setMediaType('episode')
            else:
                vinfo.setMediaType('movie')

            remove_cmd = f"RunScript(script.antivenom,action=remove_resume_item,id={item_id})"
            li.addContextMenuItems([('Remove from Continue Watching', remove_cmd)])

            play_url = f"plugin://script.antivenom/?action=play_resume_item&id={item_id}"
            xbmcplugin.addDirectoryItem(handle, play_url, li, isFolder=False)

        xbmcplugin.endOfDirectory(handle)

def handle_play_resume_item(item_id, args):
    continue_file = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/continue_watching.json')
    matched = None
    if os.path.isfile(continue_file):
        try:
            with open(continue_file, 'r', encoding='utf-8') as f:
                items = json.load(f)
                for it in items:
                    if str(it.get('id')) == str(item_id):
                        matched = it
                        break
        except Exception:
            pass

    if not matched:
        resume_file = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/resume_state.json')
        if os.path.isfile(resume_file):
            try:
                with open(resume_file, 'r', encoding='utf-8') as f:
                    matched = json.load(f)
            except Exception:
                pass

    if not matched:
        xbmcgui.Dialog().notification('AntiVenom', 'Media item not found', xbmcgui.NOTIFICATION_INFO, 2500)
        return

    title = matched.get('title', 'Media')
    time_str = matched.get('time_str', '0:00')
    seconds = matched.get('seconds', 0)
    file_path = matched.get('file', '')
    media_type = matched.get('type', 'movie')

    dialog = xbmcgui.Dialog()
    choice = dialog.yesno(
        f'Resume {title}',
        f'You stopped watching at {time_str}.\n\nWould you like to resume where you left off or start over from the beginning?',
        yeslabel=f'Resume at {time_str}',
        nolabel='Start from Beginning'
    )
    if choice is None:
        return

    seek_target = seconds if choice else 0

    if file_path and not file_path.startswith('plugin://'):
        item = xbmcgui.ListItem(title)
        if seek_target > 0:
            item.setProperty('ResumeTime', str(seek_target))
        xbmc.Player().play(file_path, item)
        if seek_target > 0:
            def _seek():
                for _ in range(30):
                    xbmc.sleep(200)
                    if xbmc.Player().isPlaying():
                        xbmc.sleep(500)
                        xbmc.Player().seekTime(float(seek_target))
                        break
            import threading
            threading.Thread(target=_seek).start()
    else:
        # plugin:// URL = stream through The Crew — re-launch search with seektime hint
        import urllib.parse
        if media_type == 'episode':
            target = f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={urllib.parse.quote_plus(title)}&resume={seek_target}'
        else:
            target = f'plugin://plugin.video.thecrew/?action=movieSearchterm&name={urllib.parse.quote_plus(title)}&resume={seek_target}'
        open_crew_window(target)
        if seek_target > 0:
            xbmcgui.Dialog().notification('AntiVenom Resume', f'Select your stream to resume at {time_str}', xbmcgui.NOTIFICATION_INFO, 4000)


def handle_remove_resume_item(item_id):
    continue_file = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/continue_watching.json')
    if os.path.isfile(continue_file):
        try:
            with open(continue_file, 'r', encoding='utf-8') as f:
                items = json.load(f)
            new_items = [it for it in items if str(it.get('id')) != str(item_id)]
            with open(continue_file, 'w', encoding='utf-8') as f:
                json.dump(new_items, f, indent=2)
            try:
                import service
                service.apply_continue_watching_to_skin(new_items)
            except Exception:
                pass
            xbmc.executebuiltin('Container.Refresh(4900)')
            xbmcgui.Dialog().notification('AntiVenom', 'Item removed from Continue Watching', xbmcgui.NOTIFICATION_INFO, 2000)
        except Exception as e:
            xbmc.log(f'[AntiVenom] remove_resume_item error: {e}', xbmc.LOGWARNING)

def main():
    args = {}
    for i, raw in enumerate(sys.argv[1:]):
        # Plugin handle is argv[1] when launched as plugin://
        if i == 0 and str(raw).isdigit():
            continue
        raw = raw.lstrip('?')
        # RunScript passes each key=value as its own argv item. Titles can contain '&'
        # (Deadpool & Wolverine). Only split on '&' when this is a real query string
        # with more than one key=value pair.
        if raw.count('=') > 1:
            parts = raw.split('&')
        else:
            parts = [raw]
        for pair in parts:
            if '=' in pair:
                k, v = pair.split('=', 1)
                try:
                    import urllib.parse
                    v = urllib.parse.unquote_plus(v)
                except Exception:
                    pass
                args[k] = v

    action = args.get('action')
    xbmc.log(f'[AntiVenom] default.py executed with action={action} args={args} sys.argv={sys.argv}', xbmc.LOGINFO)

    # Opened as plugin://script.antivenom/ with no action (Video add-ons list).
    # Kodi expects a directory listing. Return an empty list immediately — do not
    # run install_skin or the setup wizard (those crash GetDirectory on Fire TV).
    if not action and sys.argv and str(sys.argv[0]).startswith('plugin://'):
        try:
            import xbmcplugin
            handle = int(sys.argv[1])
            xbmcplugin.setContent(handle, 'videos')
            xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
            log('Plugin directory listing (no action) — returned empty list')
        except Exception as e:
            log(f'Plugin directory listing: {e}')
        return

    if action in ('system_check', 'system_check_silent'):
        run_system_check()
    elif action == 'continue_watching':
        handle_continue_watching()
    elif action == 'play_resume_item':
        handle_play_resume_item(args.get('id', ''), args)
    elif action == 'remove_resume_item':
        handle_remove_resume_item(args.get('id', ''))
    elif action == 'setup_wizard':
        action_setup_wizard(first_run=args.get('first_run') == 'true')
    elif action == 'setup':
        action_setup()
    elif action == 'clean_cache':
        clean_system_cache(silent=False)
    elif action == 'check_update':
        action_check_update(manual=True)
    elif action == 'search_movies':
        action_search_movies()
    elif action == 'search_shows':
        action_search_shows()
    elif action in ['search', 'search_universal', 'universal_search']:
        action_universal_search()
    elif action == 'search_hub':
        action_search_hub()
    elif action == 'search_sports':
        action_search_sports()
    elif action == 'search_livetv':
        action_search_livetv()
    elif action == 'play_cached':
        import urllib.parse
        show = args.get('tvshowtitle') or args.get('title') or 'Episode'
        season = args.get('season') or ''
        episode = args.get('episode') or ''
        # Season 0 is a special (House of the Dragon S0E2). The parent show id
        # does not match that clip, so search by the clip's own title.
        if str(season).lstrip('0') == '' and season != '':
            season = ''
            episode = ''
            args['imdb'] = ''
            show = args.get('title') or show
        if season and episode:
            label = f'{show} S{season}E{episode}'
        else:
            label = args.get('title') or show
        lookup_name = show if season and episode else label
        year = args.get('year') or ''
        imdb = args.get('imdb') or ''
        tmdb = args.get('tmdb') or ''

        def crew_url_for(found_imdb):
            if season and episode:
                return (
                    'plugin://plugin.video.thecrew/?action=play'
                    f'&title={urllib.parse.quote_plus(args.get("title") or show)}'
                    f'&tvshowtitle={urllib.parse.quote_plus(show)}'
                    f'&year={urllib.parse.quote_plus(year)}'
                    f'&imdb={urllib.parse.quote_plus(found_imdb)}'
                    f'&tmdb={urllib.parse.quote_plus(tmdb)}'
                    f'&season={urllib.parse.quote_plus(season)}'
                    f'&episode={urllib.parse.quote_plus(episode)}'
                    '&content=tvshows&select=2'
                )
            return (
                'plugin://plugin.video.thecrew/?action=play'
                f'&title={urllib.parse.quote_plus(label)}'
                f'&year={urllib.parse.quote_plus(year)}'
                f'&imdb={urllib.parse.quote_plus(found_imdb)}'
                f'&tmdb={urllib.parse.quote_plus(tmdb)}'
                '&content=movies&select=2'
            )

        play_via_debrid(label, imdb, crew_url_for, season=season, episode=episode,
                        lookup_name=lookup_name, year=year, tmdb=tmdb)
    elif action == 'play_trending_movie':
        import urllib.parse
        title = args.get('title', 'Deadpool & Wolverine')
        t_lower = title.lower().strip()
        if t_lower not in MOVIE_METADATA and t_lower in SHOW_METADATA:
            if not ensure_crew_available():
                return
            meta = SHOW_METADATA[t_lower]
            open_crew_window(
                f'plugin://plugin.video.thecrew/?action=seasons&tvshowtitle={urllib.parse.quote_plus(title)}'
                f'&year={meta["year"]}&imdb={meta["imdb"]}&tmdb={meta["tmdb"]}'
            )
        elif t_lower in MOVIE_METADATA:
            meta = MOVIE_METADATA[t_lower]

            def crew_url_for(found_imdb):
                return (
                    'plugin://plugin.video.thecrew/?action=play'
                    f'&title={urllib.parse.quote_plus(title)}'
                    f'&year={meta["year"]}&imdb={found_imdb}&tmdb={meta["tmdb"]}'
                    '&content=movies&select=2'
                )

            play_via_debrid(title, meta['imdb'], crew_url_for, lookup_name=title, year=meta['year'], tmdb=meta.get('tmdb'))
        else:
            open_crew_window(
                f'plugin://plugin.video.thecrew/?action=movieSearchterm&name={urllib.parse.quote_plus(title)}'
            )
    elif action == 'trailer_trending_movie':
        action_trailer_trending_movie(args.get('title', 'Deadpool & Wolverine'))
    elif action == 'play_popular_show':
        if not ensure_crew_available():
            return
        import urllib.parse
        title = args.get('title', 'Stranger Things')
        t_lower = title.lower().strip()
        if t_lower in SHOW_METADATA:
            meta = SHOW_METADATA[t_lower]
            target = f'plugin://plugin.video.thecrew/?action=seasons&tvshowtitle={urllib.parse.quote_plus(title)}&year={meta["year"]}&imdb={meta["imdb"]}&tmdb={meta["tmdb"]}'
            open_crew_window(target)
        else:
            open_crew_window(
                f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={urllib.parse.quote_plus(title)}'
            )
    elif action == 'browse_network':
        if not ensure_crew_available():
            return
        import urllib.parse
        net = args.get('network', 'Netflix')
        open_crew_window(
            f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={urllib.parse.quote_plus(net)}'
        )
    elif action == 'run_search':
        if not ensure_crew_available():
            return
        import urllib.parse
        term = args.get('name', '')
        media_type = args.get('type', 'shows')
        act = 'tvSearchterm' if media_type == 'shows' else 'movieSearchterm'
        open_crew_window(f'plugin://plugin.video.thecrew/?action={act}&name={urllib.parse.quote_plus(term)}')
    elif action == 'cached_browse':
        try:
            from resources.lib import crewcache
            handle = int(sys.argv[1]) if len(sys.argv) > 1 and str(sys.argv[1]).isdigit() else -1
            crewcache.serve(args.get('url', ''), handle)
        except Exception as e:
            log(f'cached_browse error: {e}')
    elif action == 'movie_categories':
        action_movie_categories()
    elif action in ['tv_categories', 'browse_networks']:
        action_browse_networks()
    elif action == 'open_studio':
        action_open_studio(network=args.get('network', 'Netflix'))
    elif action == 'sports_section':
        action_sports_section(section=args.get('section'))
    elif action == 'sports_live':
        action_sports_live(sport=args.get('sport'))
    elif action == 'sports_replays':
        action_sports_replays(args)
    elif action in ('sports_menu', 'sports_bucket', 'sports_pick', 'sports_games', 'sports_replays', 'sports_notice', 'sports_league', 'sports_open', 'sports_play'):
        action_sports(action, args)
    elif action == 'play_smart_sport':
        action_play_smart_sport(sport=args.get('sport'), query=args.get('query'))
    elif action == 'gameday_live_games':
        action_gameday_live_games()
    elif action == 'sports_status_notice':
        action_sports_status_notice(
            status=args.get('status'),
            title=args.get('title'),
            time_str=args.get('time'),
            sport=args.get('sport')
        )
    elif action == 'open_genre':
        action_open_genre(genre=args.get('genre'), content=args.get('content', 'movie'))
    elif action == 'kids_youtube':
        action_kids_youtube()
    elif action == 'play_next_episode':
        action_play_next_episode()
    elif action == 'zap_previous':
        action_zap_previous()
    elif action == 'refresh_gameday':
        try:
            from resources.lib.gameday import refresh_all_scores
            from resources.lib.sportshub import refresh_nfl_slate
            refresh_all_scores()
            refresh_nfl_slate()
        except Exception as ge:
            xbmc.log(f'[AntiVenom] refresh_gameday error: {ge}', xbmc.LOGWARNING)
    elif action == 'test_show_binge':
        win = xbmcgui.Window(10000)
        win.setProperty('AntiVenom.Binge.ShowTitle', 'Stranger Things')
        win.setProperty('AntiVenom.Binge.CurrentEp', 'S4 E8')
        win.setProperty('AntiVenom.Binge.NextEp', 'S4 E9')
        win.setProperty('AntiVenom.Binge.Thumb', 'special://home/addons/skin.antivenom/media/antivenom/posters/dune2.jpg')
        win.setProperty('AntiVenom.Binge.Active', 'true')
        xbmc.executebuiltin('ActivateWindow(1111)')
    elif action == 'test_show_zapper':
        xbmc.executebuiltin('ActivateWindow(1112)')
    elif action == 'reload_skin':
        xbmc.executebuiltin('ReloadSkin()')
    elif action == 'force_views':
        force_views()
    elif action in ['resume_last_watched', 'resume_playback']:
        action_resume_last_watched()
    elif action == 'apply_resume':
        try:
            import service
            service.apply_resume_to_skin()
        except Exception as e:
            xbmc.log(f'[AntiVenom] apply_resume error: {e}', xbmc.LOGWARNING)
    elif action == 'take_screenshot':
        target_file = args.get('path', r'C:\Users\xelaa\.gemini\antigravity-ide\brain\3a8b4ca8-70cd-4752-a4c4-4276116322ca\kodi_live_render.png')
        xbmc.executebuiltin(f'TakeScreenshot("{target_file}",false)')
    elif action == 'manage_debrid':
        action_manage_debrid()
    elif action == 'send_report':
        action_send_report()
    elif action == 'close_dialogs':
        xbmc.executebuiltin('Dialog.Close(all,true)')
    elif action == 'set_tab':
        tab = args.get('tab', 'home')
        xbmc.executebuiltin('ActivateWindow(Home)')
        xbmc.executebuiltin(f'Skin.SetString(ActiveTab,{tab})')
        if tab == 'movies':
            xbmc.executebuiltin('SetFocus(6000)')
        elif tab == 'tvshows':
            xbmc.executebuiltin('SetFocus(7000)')
        elif tab == 'livetv':
            xbmc.executebuiltin('SetFocus(8000)')
        elif tab == 'sports':
            xbmc.executebuiltin('SetFocus(8500)')
        elif tab == 'favorites':
            xbmc.executebuiltin('SetFocus(9500)')
        else:
            xbmc.executebuiltin('SetFocus(5000)')
    else:
        if action:
            xbmc.log(f'[AntiVenom] Ignored unknown/unhandled action: "{action}" args={args}', xbmc.LOGWARNING)
            return
        # If launched while not running skin.antivenom, prompt to activate it immediately
        if xbmc.getSkinDir() != SKIN_ID:
            dialog = xbmcgui.Dialog()
            if dialog.yesno('AntiVenom Theme', 'The AntiVenom custom streaming interface is not active.\n\nWould you like to activate the AntiVenom theme now?', yeslabel='Activate Now', nolabel='Cancel'):
                install_skin()
                return
        # If already set up, open the settings menu. Otherwise run first-time setup.
        if os.path.exists(DONE_FLAG):
            action_setup()
        else:
            run_setup()

if __name__ == '__main__':
    main()

