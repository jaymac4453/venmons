# -*- coding: utf-8 -*-
"""Disk cache for The Crew catalog directories (Movies / TV lists).

First open still talks to The Crew. Later opens serve the saved listing immediately
and refresh in the background when the copy is older than TTL. Play/scrape URLs
are never cached — those must stay live.
"""
import hashlib
import json
import os
import threading
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

TTL_SECONDS = 6 * 3600
MAX_FILES = 80
WARM_URLS = (
    'plugin://plugin.video.thecrew/?action=movieGenres',
    'plugin://plugin.video.thecrew/?action=tvNetworks',
    'plugin://plugin.video.thecrew/?action=tvGenres',
)
_NO_CACHE_ACTIONS = (
    'play', 'play1', 'download', 'clearAllCache', 'clearCache',
)
_LIVE_HINTS = (
    'nfl', 'nba', 'nhl', 'mlb', 'ncaa', 'ncaab', 'ufc', 'fifa', 'f1',
    'boxing', 'nascar', 'wwe', 'bluehat', 'sports_channels', 'sreplays',
    'streamed_', 'college_sports', 'cfb',
)
_refresh_lock = threading.Lock()
_refreshing = set()


def _log(msg):
    xbmc.log(f'[AntiVenom Cache] {msg}', xbmc.LOGINFO)


def cache_dir():
    path = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/crew_lists/')
    os.makedirs(path, exist_ok=True)
    return path


def _key(url):
    return hashlib.md5((url or '').encode('utf-8')).hexdigest()


def cache_path(url):
    return os.path.join(cache_dir(), _key(url) + '.json')


def is_cacheable(url):
    if not url or not url.startswith('plugin://plugin.video.thecrew/'):
        return False
    q = urllib.parse.urlsplit(url).query
    params = dict(urllib.parse.parse_qsl(q, keep_blank_values=True))
    action = (params.get('action') or '').strip()
    if action in _NO_CACHE_ACTIONS or action.startswith('play'):
        return False
    low = url.lower()
    if any(h in low for h in _LIVE_HINTS):
        return False
    return True


def plugin_url(crew_url):
    return 'plugin://script.antivenom/?action=cached_browse&url=' + urllib.parse.quote(
        sanitize_crew_url(crew_url or ''), safe='')


PENDING_FILE = '_pending.json'


def _pending_path():
    return os.path.join(cache_dir(), PENDING_FILE)


def queue_warmup(url):
    """Remember a Crew list to cache later — never scrape it while the user is waiting."""
    if not is_cacheable(url):
        return
    items, _ = load(url)
    if items:
        return
    path = _pending_path()
    try:
        data = []
        if os.path.isfile(path):
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f) or []
        if url not in data:
            data.append(url)
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f)
    except Exception as e:
        _log(f'queue_warmup failed: {e}')


def next_idle_url():
    path = _pending_path()
    try:
        data = []
        if os.path.isfile(path):
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f) or []
        while data:
            url = data.pop(0)
            items, _ = load(url)
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f)
            if not items:
                return url
    except Exception:
        pass
    # Prefetching genre/network roots on a 1GB stick took 39–42s each and ran
    # during an update (ayobumogos). Only warm lists the user already opened.
    try:
        from . import deviceprofile
        if deviceprofile.is_low_power():
            return None
    except Exception:
        pass
    for url in WARM_URLS:
        items, ts = load(url)
        if not items or (ts and (time.time() - ts) > TTL_SECONDS):
            return url
    return None


_SAFE_QUERY_KEYS = {
    'action', 'tvshowtitle', 'title', 'name', 'year', 'imdb', 'tmdb',
    'season', 'episode', 'content', 'select', 'url', 'tid',
}


def sanitize_crew_url(url):
    """Drop Crew's meta blob. It contains raw '&' (User-Agent&Referer) which splits the plugin URL and returns the wrong list."""
    parts = urllib.parse.urlsplit(url or '')
    if parts.scheme != 'plugin':
        return url
    pairs = urllib.parse.parse_qsl(parts.query, keep_blank_values=True)
    clean = [(k, v) for k, v in pairs if k in _SAFE_QUERY_KEYS]
    return urllib.parse.urlunsplit((parts.scheme, parts.netloc, parts.path, urllib.parse.urlencode(clean), ''))


def _query(url):
    q = urllib.parse.urlsplit(url or '').query
    return dict(urllib.parse.parse_qsl(q, keep_blank_values=True))


def _list_action(url):
    return (_query(url).get('action') or '').strip()


_PLAYBACK_LISTS = ('seasons', 'episodes', 'movieSearchterm', 'tvSearchterm')
_SEARCH_LISTS = ('movieSearchterm', 'tvSearchterm')


def rewrites_playback(url):
    """Search results, season and episode folders are served by us so Play hits Real-Debrid first."""
    return _list_action(url) in _PLAYBACK_LISTS


def is_play_cached(url):
    return (url or '').startswith('plugin://script.antivenom/?action=play_cached')


def cached_play_url(file_url, imdb_hint='', tmdb_hint=''):
    """Point every Crew play link at AntiVenom; a missing IMDb id is looked up by title there."""
    if not file_url or not file_url.startswith('plugin://plugin.video.thecrew/'):
        return file_url
    params = _query(file_url)
    if params.get('action') != 'play':
        return file_url
    if not (params.get('title') or params.get('tvshowtitle') or params.get('imdb')):
        return file_url
    imdb = (params.get('imdb') or imdb_hint or '').strip()
    if imdb in ('0', 'None', 'none'):
        imdb = (imdb_hint or '').strip()
    if imdb in ('0', 'None', 'none'):
        imdb = ''
    tmdb = (params.get('tmdb') or tmdb_hint or '').strip()
    if tmdb in ('0', 'None', 'none'):
        tmdb = (tmdb_hint or '').strip()
    if tmdb in ('0', 'None', 'none'):
        tmdb = ''
    keep = {
        'action': 'play_cached',
        'title': params.get('title') or params.get('tvshowtitle') or '',
        'tvshowtitle': params.get('tvshowtitle') or '',
        'imdb': imdb,
        'tmdb': tmdb,
        'year': params.get('year') or '',
        'season': params.get('season') or '',
        'episode': params.get('episode') or '',
    }
    return 'plugin://script.antivenom/?' + urllib.parse.urlencode(keep)


def browse_target(crew_url):
    """Cache hit → our instant listing. Miss → The Crew itself (no extra GetDirectory hop).

    Season and episode folders always come through AntiVenom so each episode
    tries a cached Real-Debrid file before The Crew search.
    """
    if rewrites_playback(crew_url):
        return plugin_url(crew_url)
    if not is_cacheable(crew_url):
        return crew_url
    items, _ = load(crew_url)
    if items:
        return plugin_url(crew_url)
    queue_warmup(crew_url)
    return crew_url


def load(url):
    path = cache_path(url)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        items = data.get('items') or []
        if not items:
            return None, 0
        return items, int(data.get('ts') or 0)
    except Exception:
        return None, 0


def save(url, items):
    if not items:
        return
    path = cache_path(url)
    tmp = path + '.tmp'
    payload = {'url': url, 'ts': int(time.time()), 'items': items}
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(payload, f, ensure_ascii=False)
        os.replace(tmp, path)
        _purge_old()
    except Exception as e:
        _log(f'save failed: {e}')
        try:
            if os.path.isfile(tmp):
                os.remove(tmp)
        except Exception:
            pass


def clear():
    folder = cache_dir()
    n = 0
    try:
        for name in os.listdir(folder):
            fp = os.path.join(folder, name)
            if os.path.isfile(fp):
                os.remove(fp)
                n += 1
    except Exception:
        pass
    return n


def _purge_old():
    folder = cache_dir()
    try:
        files = []
        for name in os.listdir(folder):
            if not name.endswith('.json'):
                continue
            fp = os.path.join(folder, name)
            files.append((os.path.getmtime(fp), fp, os.path.getsize(fp)))
        files.sort()
        while len(files) > MAX_FILES:
            _, fp, _ = files.pop(0)
            try:
                os.remove(fp)
            except Exception:
                pass
    except Exception:
        pass


def fetch_directory(url, timeout=90):
    """Ask Kodi for The Crew listing (this is the scrape on a cache miss)."""
    url = sanitize_crew_url(url)
    req = json.dumps({
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Files.GetDirectory',
        'params': {
            'directory': url,
            'media': 'video',
            'properties': [
                'title', 'plot', 'year', 'premiered', 'imdbnumber',
                'art', 'fanart', 'thumbnail', 'runtime', 'genre', 'mpaa',
                'playcount', 'file',
            ],
        },
    })
    started = time.time()
    raw = xbmc.executeJSONRPC(req)
    try:
        data = json.loads(raw)
    except Exception:
        _log(f'GetDirectory JSON parse failed for {url}')
        return []
    if data.get('error'):
        _log(f'GetDirectory error {data.get("error")} for {url}')
        return []
    files = (data.get('result') or {}).get('files') or []
    items = []
    for entry in files:
        file_url = entry.get('file') or entry.get('path') or ''
        if not file_url:
            continue
        art = entry.get('art') or {}
        items.append({
            'file': file_url,
            'label': entry.get('label') or entry.get('title') or '',
            'title': entry.get('title') or entry.get('label') or '',
            'plot': entry.get('plot') or '',
            'year': entry.get('year') or 0,
            'premiered': entry.get('premiered') or '',
            'imdb': entry.get('imdbnumber') or '',
            'genre': entry.get('genre') or '',
            'mpaa': entry.get('mpaa') or '',
            'runtime': entry.get('runtime') or 0,
            'playcount': entry.get('playcount') or 0,
            'thumbnail': entry.get('thumbnail') or art.get('thumb') or art.get('poster') or '',
            'fanart': entry.get('fanart') or art.get('fanart') or '',
            'poster': art.get('poster') or art.get('thumb') or entry.get('thumbnail') or '',
            'folder': entry.get('filetype') != 'file',
        })
    _log(f'fetched {len(items)} items from {url} in {int(time.time() - started)}s')
    return items


def _refresh_async(url):
    key = _key(url)
    with _refresh_lock:
        if key in _refreshing:
            return
        _refreshing.add(key)

    def worker():
        try:
            items = fetch_directory(url)
            if items:
                save(url, items)
        except Exception as e:
            _log(f'background refresh failed: {e}')
        finally:
            with _refresh_lock:
                _refreshing.discard(key)

    threading.Thread(target=worker, name='av-crew-cache', daemon=True).start()


def warm_idle():
    """One Crew catalog at a time, only on Home. Never scrape while Videos is open."""
    if not xbmc.getCondVisibility('System.HasAddon(plugin.video.thecrew)'):
        return
    try:
        if xbmcgui.getCurrentWindowId() != 10000:
            return
        # Home window id stays 10000 while a modal is up. Warming during the
        # update progress dialog is what stacked three 40s scrapes.
        if int(xbmcgui.getCurrentWindowDialogId()) not in (9999, 0):
            return
    except Exception:
        return
    if xbmc.Player().isPlaying():
        return
    with _refresh_lock:
        if _refreshing:
            return
    url = next_idle_url()
    if url:
        _log(f'idle warmup {url}')
        _refresh_async(url)


def warm_catalogs():
    warm_idle()


_CONTENT_BY_ACTION = {
    'movieSearchterm': 'movies',
    'movies': 'movies',
    'tvSearchterm': 'tvshows',
    'tvshows': 'tvshows',
    'seasons': 'seasons',
    'episodes': 'episodes',
}


def _content_for(url):
    """Match The Crew's container content so the Wall view keeps its poster/landscape layout."""
    return _CONTENT_BY_ACTION.get(_list_action(url), 'videos')


def _add_items(handle, items, content='videos'):
    entries = []
    for row in items:
        label = row.get('label') or row.get('title') or 'Item'
        original = sanitize_crew_url(row.get('file') or '')
        is_folder = bool(row.get('folder'))
        path = original
        if is_folder and (rewrites_playback(original) or (is_cacheable(original) and not original.startswith('plugin://script.antivenom/'))):
            path = plugin_url(original)
        elif not is_folder:
            path = cached_play_url(original, imdb_hint=row.get('imdb') or '', tmdb_hint=str(row.get('tmdb') or ''))
        li = xbmcgui.ListItem(label=label, offscreen=True)
        art = {}
        if row.get('poster'):
            art['poster'] = row['poster']
        if row.get('thumbnail'):
            art['thumb'] = row['thumbnail']
        if row.get('fanart'):
            art['fanart'] = row['fanart']
        if art:
            li.setArt(art)
        info = {'title': row.get('title') or label}
        if row.get('plot'):
            info['plot'] = row['plot']
        if row.get('year'):
            try:
                info['year'] = int(row['year'])
            except Exception:
                pass
        if row.get('premiered'):
            info['premiered'] = row['premiered']
        if row.get('imdb'):
            info['imdbnumber'] = row['imdb']
        if row.get('genre'):
            info['genre'] = row['genre']
        if row.get('mpaa'):
            info['mpaa'] = row['mpaa']
        try:
            li.setInfo('video', info)
        except Exception:
            pass
        if not is_folder:
            # play_cached starts the player itself (like The Crew's own list items),
            # so Kodi must run it as a script rather than wait for setResolvedUrl.
            li.setProperty('IsPlayable', 'false' if is_play_cached(path) else 'true')
        entries.append((path, li, is_folder))
    if entries:
        xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.setContent(handle, content)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False, updateListing=False)


def _closest_title_items(crew_url, name):
    """Partial or misspelled search: rerun The Crew with the real title, else list TMDB matches."""
    if not name.strip():
        return []
    kind = 'tv' if _list_action(crew_url) == 'tvSearchterm' else 'movie'
    try:
        from . import titlesearch
        corrected = titlesearch.best_title(name, kind)
        if corrected and _norm_title(corrected) != _norm_title(name):
            _log(f'search "{name}" had no Crew results; retrying as "{corrected}"')
            retry = crew_url.replace('name=' + urllib.parse.quote_plus(name),
                                     'name=' + urllib.parse.quote_plus(corrected))
            if retry == crew_url:
                retry = ('plugin://plugin.video.thecrew/?action=' + _list_action(crew_url)
                         + '&name=' + urllib.parse.quote_plus(corrected))
            items = fetch_directory(retry)
            if items:
                return items
        rows = titlesearch.crew_rows(name, kind)
        _log(f'search "{name}": {len(rows)} TMDB closest-title match(es)')
        return rows
    except Exception as e:
        _log(f'closest-title search failed: {e}')
        return []


def _norm_title(text):
    return ''.join(ch for ch in (text or '').lower() if ch.isalnum())


def serve(crew_url, handle):
    crew_url = sanitize_crew_url(urllib.parse.unquote(crew_url or ''))
    if not crew_url.startswith('plugin://plugin.video.thecrew/'):
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    items, ts = load(crew_url)
    age = int(time.time() - ts) if ts else None
    if items:
        _log(f'cache HIT {crew_url} ({len(items)} items, age={age}s)')
        _add_items(handle, items, _content_for(crew_url))
        if age is None or age > TTL_SECONDS:
            _refresh_async(crew_url)
        return

    if rewrites_playback(crew_url):
        _log(f'cache MISS {crew_url} — fetching so play can use Real-Debrid first')
        items = fetch_directory(crew_url)
        if not items and _list_action(crew_url) == 'episodes':
            fallback = 'plugin://plugin.video.thecrew/?' + urllib.parse.urlencode({
                k: v for k, v in _query(crew_url).items()
                if k in _SAFE_QUERY_KEYS and k != 'meta' and v
            })
            if fallback != crew_url:
                _log(f'episode fetch empty — retrying lean URL {fallback}')
                items = fetch_directory(fallback)
        if items:
            save(crew_url, items)
            _add_items(handle, items, _content_for(crew_url))
            return
        if _list_action(crew_url) in _SEARCH_LISTS:
            name = _query(crew_url).get('name') or ''
            items = _closest_title_items(crew_url, name)
            if items:
                save(crew_url, items)
                _add_items(handle, items, _content_for(crew_url))
                return
            xbmcgui.Dialog().notification('AntiVenom', f'No results for {name}', xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
            return
        xbmcgui.Dialog().notification('AntiVenom', 'Could not load this list', xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
        return

    _log(f'cache MISS {crew_url} — opening The Crew directly (no extra scrape hop)')
    queue_warmup(crew_url)
    xbmc.executebuiltin(f'Container.Update({crew_url})')
    xbmcplugin.endOfDirectory(handle, succeeded=False)
