# -*- coding: utf-8 -*-
"""Install The Crew (plugin + script.module.thecrew) and everything it depends on.

Kodi's InstallAddon() only finds The Crew after repository.thecrew is enabled AND
Kodi has downloaded that repo's addons.xml. On a Fire TV Stick that refresh takes
minutes, InstallAddon silently finds nothing, and the old installer gave up after
a few seconds. Here every zip is downloaded straight from the repo datadirs,
dependencies first, extracted in place, then Kodi is told to register and enable
them. Folders are never rmtree'd: Android returns errno 16/39 on live add-ons.
"""
import gzip
import json
import os
import re
import shutil
import time
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

import xbmc
import xbmcvfs

CREW_PLUGIN = 'plugin.video.thecrew'
CREW_MODULE = 'script.module.thecrew'
CREW_REPO_ID = 'repository.thecrew'
CREW_REPO_ZIP = 'https://team-crew.github.io/repository.thecrew-0.3.8.zip'
CREW_TARGETS = (CREW_PLUGIN, CREW_MODULE)

# (addons.xml, datadir). The repo addon.xml is also read at run time so a moved
# datadir is still found; these cover a failed repo download.
CREW_SOURCES = [
    ('https://raw.githubusercontent.com/thecrewwh/zips/master/matrix/_zip/addons.xml',
     'https://raw.githubusercontent.com/thecrewwh/zips/master/matrix/_zip'),
    ('https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml',
     'https://raw.githubusercontent.com/Gujal00/smrzips/master/zips'),
]
# (repo id, repo zip url, fallback sources, label shown in the progress dialog)
CREW_REPO = (CREW_REPO_ID, CREW_REPO_ZIP, CREW_SOURCES, 'The Crew repository')
KODI_REPO = 'https://mirrors.kodi.tv/addons/{}'
KODI_CODENAMES = {19: 'matrix', 20: 'nexus', 21: 'omega', 22: 'piers'}
NEVER_TOUCH = ('skin.antivenom', 'script.antivenom')
# Compiled per platform. Kodi ships these (Android builds include inputstream.adaptive
# and inputstream.ffmpegdirect); a zip from a third-party repo would be the wrong build.
BINARY_PREFIXES = ('inputstream.', 'pvr.', 'audiodecoder.', 'audioencoder.', 'imagedecoder.',
                   'vfs.', 'visualization.', 'screensaver.', 'peripheral.', 'game.')
UA = {'User-Agent': 'Mozilla/5.0 (Linux; Android 9) Kodi/21 AntiVenom'}


def _log(msg):
    xbmc.log(f'[AntiVenom CrewInstall] {msg}', xbmc.LOGINFO)


def _addons_dir():
    return xbmcvfs.translatePath('special://home/addons/')


def _temp_dir():
    path = xbmcvfs.translatePath('special://temp/antivenom_install/')
    os.makedirs(path, exist_ok=True)
    return path


def _get(url, timeout=45, tries=3):
    last = None
    for attempt in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read()
        except Exception as e:
            last = e
            xbmc.sleep(800 * (attempt + 1))
    raise last


def version_tuple(v):
    core = re.split(r'[+~]', v or '0')[0]
    return tuple(int(n) for n in re.findall(r'\d+', core)) or (0,)


def installed_version(addon_id):
    xml_path = os.path.join(_addons_dir(), addon_id, 'addon.xml')
    try:
        with open(xml_path, 'r', encoding='utf-8', errors='ignore') as f:
            head = f.read(4096)
        m = re.search(r'<addon\b[^>]*?\bversion="([^"]+)"', head, re.S)
        return m.group(1) if m else '0'
    except Exception:
        return None


def _is_builtin(addon_id):
    return addon_id.startswith(('xbmc.', 'kodi.'))


def _kodi_codename():
    try:
        major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except Exception:
        major = 21
    return KODI_CODENAMES.get(major, 'omega')


def _repo_dirs(repo_id=CREW_REPO_ID):
    """<dir> entries of an installed repository addon.xml."""
    xml_path = os.path.join(_addons_dir(), repo_id, 'addon.xml')
    dirs = []
    try:
        root = ET.parse(xml_path).getroot()
        for d in root.iter('dir'):
            info = (d.findtext('info') or '').strip()
            data = (d.findtext('datadir') or '').strip()
            if info and data:
                dirs.append((info, data.rstrip('/')))
    except Exception as e:
        _log(f'repo addon.xml unreadable: {e}')
    return dirs


def load_index(sources):
    """addon id -> {version, datadir, deps[(id, minversion, optional)]}; newest version wins."""
    index = {}
    for info_url, datadir in sources:
        try:
            raw = _get(info_url, timeout=60)
            if info_url.endswith('.gz') or raw[:2] == b'\x1f\x8b':
                raw = gzip.decompress(raw)
            root = ET.fromstring(raw)
        except Exception as e:
            _log(f'index unavailable {info_url}: {e}')
            continue
        for a in root.findall('addon'):
            aid = a.get('id')
            ver = a.get('version') or '0'
            if not aid:
                continue
            old = index.get(aid)
            if old and version_tuple(old['version']) >= version_tuple(ver):
                continue
            deps = [(i.get('addon'), i.get('version') or '', (i.get('optional') or '').lower() == 'true')
                    for i in a.findall('requires/import') if i.get('addon')]
            index[aid] = {'version': ver, 'datadir': datadir.rstrip('/'), 'deps': deps}
    return index


def resolve(index, roots):
    """Return (install_order, enable_order, missing). Both orders list dependencies first."""
    install, enable, missing, seen = [], [], [], set()

    def visit(aid, need_ver=''):
        if aid in seen or _is_builtin(aid) or aid in NEVER_TOUCH:
            return
        seen.add(aid)
        if aid.startswith(BINARY_PREFIXES):
            if addon_state(aid) is None and installed_version(aid) is None:
                missing.append(aid)
            else:
                enable.append(aid)
            return
        have = installed_version(aid)
        entry = index.get(aid)
        if entry:
            for dep, dep_ver, optional in entry['deps']:
                if not optional:
                    visit(dep, dep_ver)
        if have is not None:
            too_old = need_ver and version_tuple(have) < version_tuple(need_ver)
            if (too_old or aid in roots) and entry and version_tuple(entry['version']) > version_tuple(have):
                install.append(aid)
            enable.append(aid)
        elif entry:
            install.append(aid)
            enable.append(aid)
        elif xbmc.getCondVisibility(f'System.HasAddon({aid})'):
            pass  # shipped with Kodi (system add-on folder)
        else:
            missing.append(aid)

    for r in roots:
        visit(r)
    return install, enable, missing


def _zip_url(aid, entry):
    return f"{entry['datadir']}/{aid}/{aid}-{entry['version']}.zip"


def download_zip(url, name):
    dest = os.path.join(_temp_dir(), name)
    data = _get(url, timeout=120)
    with open(dest, 'wb') as f:
        f.write(data)
    if not zipfile.is_zipfile(dest):
        os.remove(dest)
        raise ValueError(f'not a zip: {url}')
    return dest


def extract_addon(zip_path, addon_id):
    """Write the add-on over any existing copy, file by file. addon.xml goes last so a
    half-written folder is never mistaken for a finished install."""
    addons = _addons_dir()
    prefix = addon_id + '/'
    failed = 0
    with zipfile.ZipFile(zip_path, 'r') as z:
        members = [m for m in z.infolist()
                   if m.filename.replace('\\', '/').startswith(prefix)
                   and '..' not in m.filename.replace('\\', '/').split('/')]
        if not members:
            raise ValueError(f'{os.path.basename(zip_path)} has no {prefix} folder')
        manifest = prefix + 'addon.xml'
        members.sort(key=lambda m: m.filename.replace('\\', '/') == manifest)
        for m in members:
            rel = m.filename.replace('\\', '/')
            dest = os.path.join(addons, *rel.rstrip('/').split('/'))
            if rel.endswith('/'):
                os.makedirs(dest, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            tmp = dest + '.avnew'
            try:
                with z.open(m) as src, open(tmp, 'wb') as out:
                    shutil.copyfileobj(src, out)
                try:
                    os.replace(tmp, dest)
                except OSError:
                    # FUSE storage on some sticks refuses rename over an open file
                    shutil.copyfile(tmp, dest)
                    os.remove(tmp)
            except OSError as e:
                failed += 1
                _log(f'could not write {rel}: {e}')
                try:
                    if os.path.exists(tmp):
                        os.remove(tmp)
                except OSError:
                    pass
    ok = failed == 0 and os.path.isfile(os.path.join(addons, addon_id, 'addon.xml'))
    if not ok and failed:
        _log(f'{addon_id}: {failed} file(s) failed, trying Kodi Extract()')
        xbmc.executebuiltin(f'Extract({zip_path},{addons})', True)
        ok = installed_version(addon_id) is not None
    return ok


def _rpc(method, params):
    raw = xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}))
    try:
        return json.loads(raw)
    except Exception:
        return {}


def addon_state(addon_id):
    """None = Kodi does not know it yet, else True/False for enabled."""
    res = _rpc('Addons.GetAddonDetails', {'addonid': addon_id, 'properties': ['enabled']})
    details = (res.get('result') or {}).get('addon')
    if not details:
        return None
    return bool(details.get('enabled'))


def enable(addon_id):
    res = _rpc('Addons.SetAddonEnabled', {'addonid': addon_id, 'enabled': True})
    return res.get('result') == 'OK'


def _register_and_enable(ids, progress, pct_from, pct_to):
    monitor = xbmc.Monitor()
    xbmc.executebuiltin('UpdateLocalAddons', True)
    pending = list(ids)
    deadline = time.time() + 60
    rescan_at = time.time() + 15
    while pending and time.time() < deadline and not monitor.abortRequested():
        pending = [a for a in pending if addon_state(a) is None]
        if not pending:
            break
        progress(pct_from, 'Kodi is registering the new add-ons...')
        if monitor.waitForAbort(1.5):
            break
        if time.time() >= rescan_at:
            xbmc.executebuiltin('UpdateLocalAddons', True)
            rescan_at = time.time() + 15
    if pending:
        _log(f'not registered after 60s: {pending}')

    for attempt in range(4):
        off = [a for a in ids if addon_state(a) is not True]
        if not off:
            break
        for n, aid in enumerate(off):
            progress(pct_from + int((pct_to - pct_from) * n / max(len(off), 1)), f'Turning on {aid}...')
            enable(aid)
            xbmc.sleep(250)
        if monitor.waitForAbort(1.5):
            break
    return [a for a in ids if addon_state(a) is not True]


def install_addons(roots, progress=None, with_crew_repo=True, repo=None):
    """Install roots and their required dependencies. Returns (ok, message).

    repo is (repo id, repo zip url, fallback sources, label); defaults to The Crew's."""
    def report(pct, msg):
        _log(msg)
        if progress:
            progress(max(0, min(100, int(pct))), msg)

    roots = tuple(roots)
    if repo is None and with_crew_repo:
        repo = CREW_REPO
    repo_id = repo[0] if repo else None
    sources = []
    enable_first = []
    if repo:
        repo_id, repo_zip, fallback_sources, label = repo
        report(3, f'Getting {label}...')
        if installed_version(repo_id) is None:
            try:
                zp = download_zip(repo_zip, f'{repo_id}.zip')
                extract_addon(zp, repo_id)
                os.remove(zp)
            except Exception as e:
                _log(f'repo zip failed ({e}); using built-in source list')
        if installed_version(repo_id) is not None:
            enable_first.append(repo_id)
        sources.extend(_repo_dirs(repo_id))
        for src in fallback_sources:
            if src[1] not in [d for _, d in sources]:
                sources.append(src)
    kodi_repo = KODI_REPO.format(_kodi_codename())
    sources.append((kodi_repo + '/addons.xml.gz', kodi_repo))

    report(8, 'Checking what is needed...')
    index = load_index(sources)
    unknown = [r for r in roots if r not in index and installed_version(r) is None]
    if unknown:
        return False, 'Could not reach the add-on repositories (check the internet connection).'

    install, enable_order, missing = resolve(index, roots)
    if missing:
        _log(f'required add-ons not found in any repo: {missing}')
        for aid in missing:
            if aid.startswith(BINARY_PREFIXES):
                # Only Kodi's own repo has the right build for this device.
                xbmc.executebuiltin(f'InstallAddon({aid})')
    _log(f'install order: {install}')

    failed = []
    total = max(len(install), 1)
    for n, aid in enumerate(install):
        entry = index[aid]
        report(10 + 65 * n / total, f'Downloading {aid} ({n + 1}/{len(install)})...')
        try:
            zp = download_zip(_zip_url(aid, entry), f'{aid}.zip')
            report(10 + 65 * (n + 0.6) / total, f'Installing {aid}...')
            if not extract_addon(zp, aid):
                failed.append(aid)
            try:
                os.remove(zp)
            except OSError:
                pass
        except Exception as e:
            _log(f'{aid} failed: {e}')
            failed.append(aid)

    report(78, 'Kodi is registering the new add-ons...')
    still_off = _register_and_enable(enable_first + enable_order, report, 80, 97)
    try:
        shutil.rmtree(_temp_dir(), ignore_errors=True)
    except Exception:
        pass

    broken = [r for r in roots if r in failed or r in still_off]
    if broken:
        return False, 'Could not finish: ' + ', '.join(broken + [f for f in failed if f not in broken])
    report(100, 'Done')
    extra = [a for a in failed + still_off + missing if a not in roots and a != repo_id]
    msg = 'Installed.' if not extra else 'Installed. Optional pieces skipped: ' + ', '.join(sorted(set(extra)))
    return True, msg


def install_crew(progress=None):
    return install_addons(CREW_TARGETS, progress=progress, with_crew_repo=True)
