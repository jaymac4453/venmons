# -*- coding: utf-8 -*-
"""Debrid engine: start a Real-Debrid cached file a few seconds after Play.

Order on play (Fast Mode):
  1. The file that played last time for this title (rd_learned.json).
  2. Torrentio cached-only list for the user's Real-Debrid key. Usually already
     fetched while the poster was focused on Home (prefetch), else one request.
  3. Comet (ElfHosted) cached-only list, skipping hashes already tried.
  4. Only when both lists failed to load: Real-Debrid's own "downloaded" check
     on the plain Torrentio hashes.
Streams that fail are remembered for a week and skipped. The caller falls back
to The Crew (if allowed) and can then offer a Real-Debrid download.

The Real-Debrid key is never written to disk or window properties: stored
stream URLs carry KEY_SLOT and the live key is substituted at play time.
"""
import base64
import json
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcvfs

TORRENTIO = 'https://torrentio.strem.fun'
COMET = 'https://comet.elfhosted.com'
RD_API = 'https://api.real-debrid.com/rest/1.0'
BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
RD_UA = 'AntiVenom/1.0'
KEY_SLOT = '{RDKEY}'

SEARCH_BUDGET = 18.0
LIST_TIMEOUT = 7
RESOLVE_TIMEOUT = 5
RD_TIMEOUT = 8
MAX_PLAY_TRIES = 3
MAX_RESOLVE_TRIES = 6
PLAY_WAIT = 30

PREFETCH_TTL = 1800
PREFETCH_KEEP = 8
PREFETCH_PROP = 'AntiVenom.DebridPrefetch.'
PREFETCH_INDEX = 'AntiVenom.DebridPrefetch.index'
PREFETCH_MAX_TITLES = 30

LEARN_MAX = 120
BAD_TTL = 7 * 86400
BAD_MAX = 30

VIDEO_EXT = ('.mkv', '.mp4', '.avi', '.m4v', '.mov', '.wmv', '.ts', '.m2ts')
RD_FAIL_STATUS = ('magnet_error', 'error', 'virus', 'dead')

_SIZE_RE = re.compile(r'(\d+(?:[.,]\d+)?)\s*(TB|GB|MB)\b', re.I)
_SEED_RE = re.compile('\U0001F464\\s*(\\d+)')
_URL_HASH_RE = re.compile(r'/([a-f0-9]{40})(?:/|$)')
_TAIL_HASH_RE = re.compile(r'([a-f0-9]{40})$')

_JUNK = {'cam', 'hdcam', 'camrip', 'ts', 'hdts', 'telesync', 'tsrip', 'tc', 'hdtc', 'telecine',
         'scr', 'screener', 'dvdscr', 'bdscr', 'workprint'}
_HI_RES = {'2160p', '2160', '4k', 'uhd'}
_HDR = {'hdr', 'hdr10', 'hdr10plus', 'dv', 'dovi', '10bit', 'hi10', 'hi10p'}
_THREE_D = {'3d', 'sbs', 'hsbs', 'hou', 'fsbs'}
# Multi-audio and dubbed releases often default to a non-English track.
_FOREIGN = {'multi', 'dual', 'ita', 'hindi', 'rus', 'french', 'truefrench', 'vff', 'vostfr', 'latino',
            'castellano', 'spanish', 'esp', 'german', 'ger', 'tamil', 'telugu', 'kor', 'dublado', 'legendado'}
_CYRILLIC_RE = re.compile('[\u0400-\u04ff]')
_FLAG_RE = re.compile('[\U0001F1E6-\U0001F1FF]{2}')
_ENGLISH_FLAGS = ('\U0001F1EC\U0001F1E7', '\U0001F1FA\U0001F1F8')

_low_power = None


def _log(msg):
    xbmc.log('[AntiVenom Debrid] %s' % msg, xbmc.LOGINFO)


class HttpError(Exception):
    def __init__(self, code, host):
        Exception.__init__(self, 'HTTP %s from %s' % (code, host))
        self.code = code


class AuthError(Exception):
    pass


# ---------------------------------------------------------------- device / settings

def low_power():
    global _low_power
    if _low_power is None:
        try:
            from . import deviceprofile
            _low_power = bool(deviceprofile.is_low_power())
        except Exception:
            _low_power = True
    return _low_power


def fast_mode_on():
    try:
        from . import deviceprofile
        return deviceprofile.is_fast_mode_enabled()
    except Exception:
        return True


# ---------------------------------------------------------------- Real-Debrid key

def _profile(path):
    return xbmcvfs.translatePath('special://profile/' + path)


def _vault_paths():
    return [
        _profile('addon_data/script.antivenom/rd_vault.json'),
        xbmcvfs.translatePath('special://masterprofile/rd_vault.json'),
        xbmcvfs.translatePath('special://home/rd_vault.json'),
        '/sdcard/AntiVenom_rd_vault.json',
        '/storage/emulated/0/AntiVenom_rd_vault.json',
    ]


def _resolveurl_creds():
    path = _profile('addon_data/script.module.resolveurl/settings.xml')
    if not os.path.isfile(path):
        return {}
    try:
        import xml.etree.ElementTree as ET
        found = {}
        for node in ET.parse(path).getroot().findall('setting'):
            sid = node.attrib.get('id') or ''
            if sid.startswith('RealDebridResolver_') and (node.text or '').strip():
                if sid == 'RealDebridResolver_token' and 'default' in node.attrib:
                    continue
                found[sid] = node.text.strip()
        return found if found.get('RealDebridResolver_token') else {}
    except Exception:
        return {}


def _vault_creds():
    for path in _vault_paths():
        try:
            if path and os.path.isfile(path):
                with open(path, 'r', encoding='utf-8') as handle:
                    data = json.load(handle) or {}
                if data.get('RealDebridResolver_token'):
                    return data
        except Exception:
            continue
    return {}


def token():
    """Current RD access token. ResolveURL's copy first (it refreshes it), then the vault."""
    return (_resolveurl_creds() or _vault_creds()).get('RealDebridResolver_token') or ''


def refresh_token():
    """Refresh an expired token with ResolveURL's refresh token; writes back where ResolveURL reads it."""
    try:
        try:
            import service as av_service
        except ImportError:
            import sys
            root = xbmcvfs.translatePath('special://home/addons/script.antivenom/')
            if root not in sys.path:
                sys.path.insert(0, root)
            import service as av_service
        creds = dict(_resolveurl_creds() or _vault_creds())
        if not creds.get('RealDebridResolver_refresh'):
            return ''
        creds, refreshed = av_service.check_and_refresh_token(creds)
        if not refreshed:
            return ''
        av_service.write_vault_credentials(creds)
        av_service.apply_to_resolveurl(creds)
        _log('Real-Debrid token refreshed')
        return creds.get('RealDebridResolver_token') or ''
    except Exception as exc:
        _log('token refresh failed: %s' % exc)
        return ''


def scrub(text, key):
    text = text or ''
    return text.replace(key, KEY_SLOT) if key else text


def unscrub(text, key):
    return (text or '').replace(KEY_SLOT, key or '')


# ---------------------------------------------------------------- HTTP

def _request(url, timeout, ua=BROWSER_UA, bearer=None, data=None, method=None):
    headers = {'User-Agent': ua}
    if bearer:
        headers['Authorization'] = 'Bearer ' + bearer
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data).encode('utf-8')
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=max(1, timeout)) as resp:
            raw = resp.read().decode('utf-8', errors='replace')
    except urllib.error.HTTPError as exc:
        raise HttpError(exc.code, urllib.parse.urlsplit(url).netloc)
    return json.loads(raw) if raw.strip() else {}


def _rd(path, key, timeout=RD_TIMEOUT, data=None, method=None):
    try:
        return _request(RD_API + path, timeout, ua=RD_UA, bearer=key, data=data, method=method)
    except HttpError as exc:
        if exc.code == 401:
            raise AuthError('Real-Debrid rejected the token')
        raise


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_OPENER = urllib.request.build_opener(_NoRedirect)


def resolve(url, timeout=RESOLVE_TIMEOUT):
    """Follow an addon resolve URL to the Real-Debrid file without downloading it.

    Returns (direct_url, reason). Torrentio answers errors with its own
    placeholder videos; anything that does not land on real-debrid.com fails.
    """
    current = url
    for _ in range(3):
        req = urllib.request.Request(current, headers={'User-Agent': BROWSER_UA})
        location = None
        try:
            resp = _OPENER.open(req, timeout=max(1, timeout))
            code = resp.status
            resp.close()
        except urllib.error.HTTPError as exc:
            code = exc.code
            location = exc.headers.get('Location') if exc.headers else None
            exc.close()
        except Exception as exc:
            return '', 'network: %s' % exc
        if code in (301, 302, 303, 307, 308) and location:
            nxt = urllib.parse.urljoin(current, location)
            parts = urllib.parse.urlsplit(nxt)
            host = parts.netloc.lower()
            path = parts.path.lower()
            if host == 'real-debrid.com' or host.endswith('.real-debrid.com'):
                return nxt, ''
            if 'failed_access' in path or 'unauthorized' in path:
                return '', 'auth'
            if path.endswith('.mp4') or '/videos/' in path or '/static/' in path:
                return '', 'placeholder %s' % os.path.basename(path)
            current = nxt
            continue
        return '', 'http %s' % code
    return '', 'too many redirects'


# ---------------------------------------------------------------- stream parsing / ranking

def parse_size(text):
    best = 0
    for num, unit in _SIZE_RE.findall(text or ''):
        value = float(num.replace(',', '.'))
        mult = {'TB': 1024 ** 4, 'GB': 1024 ** 3, 'MB': 1024 ** 2}[unit.upper()]
        best = max(best, int(value * mult))
    return best


def parse_stream(stream, source):
    if not isinstance(stream, dict):
        return None
    name = stream.get('name') or ''
    title = stream.get('title') or stream.get('description') or ''
    hints = stream.get('behaviorHints') or {}
    url = stream.get('url') or ''
    info_hash = (stream.get('infoHash') or stream.get('infohash') or '').strip().lower()
    if len(info_hash) != 40:
        info_hash = ''
        m = _URL_HASH_RE.search(url.lower())
        if m:
            info_hash = m.group(1)
        else:
            m = _TAIL_HASH_RE.search((hints.get('bingeGroup') or '').lower())
            if m:
                info_hash = m.group(1)
    if not info_hash and not url:
        return None
    try:
        size = int(hints.get('videoSize') or 0)
    except Exception:
        size = 0
    size = size or parse_size(title)
    m = _SEED_RE.search(title)
    seeders = int(m.group(1)) if m else 0
    filename = hints.get('filename') or ''
    label = ' '.join(part.replace('\n', ' ') for part in (name, title, filename) if part)
    return {
        'src': source,
        'hash': info_hash,
        'url': url,
        'file': (filename or title.split('\n')[0])[:200],
        'label': label[:400],
        'size': size,
        'seeders': seeders,
        'cached': ('+]' in name) or ('\u26a1' in name),
        'idx': stream.get('fileIdx'),
    }


def _tokens(label):
    low = (label or '').lower()
    toks = set(t for t in re.split(r'[^a-z0-9]+', low) if t)
    if '10-bit' in low or '10 bit' in low:
        toks.add('10bit')
    if 'dolby vision' in low or 'dolby.vision' in low:
        toks.add('dv')
    if 'hdr10+' in low:
        toks.add('hdr10plus')
    return toks


def skip_quality(label, weak):
    toks = _tokens(label)
    if toks & _JUNK or toks & _THREE_D:
        return True
    if toks & _HI_RES:
        return True
    if weak and (toks & _HDR or 'remux' in toks or 'av1' in toks):
        return True
    return False


def score(cand, weak, episode=False):
    toks = _tokens(cand.get('label'))
    total = 0
    if '1080p' in toks or '1080' in toks:
        total += 60
    elif '720p' in toks or '720' in toks:
        total += 45
    elif '480p' in toks or '576p' in toks:
        total += 10
    else:
        total += 25
    if toks & {'x264', 'h264', 'avc'}:
        total += 15 if weak else 5
    elif toks & {'x265', 'h265', 'hevc'}:
        total -= 10 if weak else 0
    if toks & {'web', 'webdl', 'webrip', 'bluray', 'brrip', 'bdrip'}:
        total += 8
    size_gb = (cand.get('size') or 0) / float(1024 ** 3)
    if size_gb:
        if episode:
            lo, hi = (0.3, 3.0) if weak else (0.3, 6.0)
        else:
            lo, hi = (1.2, 8.0) if weak else (1.5, 20.0)
        if lo <= size_gb <= hi:
            total += 15
        elif size_gb > hi:
            total -= min(40, int((size_gb - hi) * 3) + 5)
        else:
            total -= 10
    if toks & _FOREIGN or _CYRILLIC_RE.search(cand.get('label') or ''):
        total -= 20
    else:
        flags = _FLAG_RE.findall(cand.get('label') or '')
        if flags and any(f not in _ENGLISH_FLAGS for f in flags):
            total -= 10
    seeds = cand.get('seeders') or 0
    total += min(10, seeds // 20)
    if cand.get('cached'):
        total += 100
    return total


def rank(cands, weak, episode=False, skip_hashes=()):
    seen = set(h for h in skip_hashes if h)
    ranked = []
    for cand in cands:
        if not cand or skip_quality(cand.get('label'), weak):
            continue
        h = cand.get('hash') or cand.get('url')
        if h in seen:
            continue
        seen.add(h)
        ranked.append((score(cand, weak, episode), cand))
    ranked.sort(key=lambda row: row[0], reverse=True)
    return [cand for _s, cand in ranked]


def _norm_title(text):
    text = (text or '').lower().replace('&', ' and ')
    text = re.sub(r'[^a-z0-9]+', ' ', text).strip()
    return text[4:] if text.startswith('the ') else text


def title_matches(filename, title, year=None, season=None, episode=None):
    """True when the release name is this title (not a spin-off or another film).

    Comet matches by name, so "Stranger Things: Tales From '85" can show up for
    Stranger Things. The words before the episode tag / year must end with the title.
    """
    want = _norm_title(re.sub(r'\s*\(\s*(19|20)\d{2}\s*\)\s*$', '', title or ''))
    text = _norm_title(filename)
    if not want or not text:
        return True
    marker = None
    if season and episode:
        marker = re.search(r'\bs0*%d ?e0*%d\b|\b0*%dx0*%d\b|\bs0*%d\b|\bseason 0*%d\b' % (
            int(season), int(episode), int(season), int(episode), int(season), int(season)), text)
    else:
        yr = re.search(r'(19|20)\d{2}', str(year or ''))
        if yr:
            marker = re.search(r'\b%s\b' % yr.group(0), text)
        if marker is None:
            marker = re.search(r'\b(2160p|1080p|720p|576p|480p)\b', text)
    if marker is None:
        return (' %s ' % want) in (' %s ' % text)
    prefix = text[:marker.start()].strip()
    if season and episode:
        prefix = re.sub(r'\s*\b(19|20)\d{2}\s*$', '', prefix).strip()
    return prefix == want or prefix.endswith(' ' + want)


def stream_path(imdb, season=None, episode=None):
    if season and episode:
        return 'series/%s:%d:%d.json' % (imdb, int(season), int(episode))
    return 'movie/%s.json' % imdb


def torrentio_options(key, weak):
    if weak:
        quality = 'brremux,hdrall,dolbyvision,dolbyvisionwithhdr,threed,4k,scr,cam,unknown'
    else:
        quality = 'brremux,threed,4k,scr,cam,unknown'
    parts = ['qualityfilter=' + quality]
    if weak:
        parts.append('sizefilter=12GB,5GB')
    parts.append('debridoptions=nodownloadlinks,nocatalog')
    parts.append('realdebrid=' + key)
    return '|'.join(parts)


def comet_config(key):
    cfg = {
        'cachedOnly': True,
        'removeTrash': True,
        'resultFormat': ['all'],
        'maxResultsPerResolution': 6,
        'maxSize': 0,
        'debridService': 'realdebrid',
        'debridApiKey': key,
        'resolutions': {'r2160p': False, 'r1440p': False, 'r1080p': True, 'r720p': True,
                        'r576p': True, 'r480p': True, 'r360p': False, 'r240p': False, 'unknown': True},
    }
    # A '/' in standard base64 would split the URL path; pad until there is none.
    for pad in range(12):
        if pad:
            cfg['p'] = 'x' * pad
        encoded = base64.b64encode(json.dumps(cfg, separators=(',', ':')).encode('utf-8')).decode('ascii')
        if '/' not in encoded and '+' not in encoded:
            return encoded
    return encoded.replace('/', '_').replace('+', '-')


def fetch_torrentio(imdb, season, episode, key, weak, timeout=LIST_TIMEOUT):
    url = '%s/%s/stream/%s' % (TORRENTIO, torrentio_options(key, weak), stream_path(imdb, season, episode))
    payload = _request(url, timeout)
    cands = []
    for stream in payload.get('streams') or []:
        cand = parse_stream(stream, 'torrentio')
        if cand and cand['cached'] and cand['url']:
            cand['url'] = scrub(cand['url'], key)
            cands.append(cand)
    return rank(cands, weak, bool(season and episode))


def fetch_comet(imdb, season, episode, key, weak, timeout=LIST_TIMEOUT, title='', year=None):
    url = '%s/%s/stream/%s' % (COMET, comet_config(key), stream_path(imdb, season, episode))
    payload = _request(url, timeout)
    cands = []
    for stream in payload.get('streams') or []:
        cand = parse_stream(stream, 'comet')
        if cand and cand['cached'] and cand['url']:
            if title and not title_matches(cand['file'], title, year, season, episode):
                continue
            cand['url'] = scrub(cand['url'], key)
            cands.append(cand)
    return rank(cands, weak, bool(season and episode))


def fetch_plain(imdb, season, episode, weak, timeout=LIST_TIMEOUT, title=''):
    """Torrentio without a key: every torrent with its hash (used for RD checks/downloads)."""
    url = '%s/stream/%s' % (TORRENTIO, stream_path(imdb, season, episode))
    payload = _request(url, timeout)
    cands = []
    for stream in payload.get('streams') or []:
        cand = parse_stream(stream, 'rd')
        if cand and cand['hash']:
            cand['url'] = ''
            cands.append(cand)
    if not cands and title:
        try:
            q = urllib.parse.quote_plus(title)
            q_url = '%s/search=%s/stream/%s' % (TORRENTIO, q, stream_path(imdb, season, episode))
            q_payload = _request(q_url, max(2, timeout))
            for stream in q_payload.get('streams') or []:
                cand = parse_stream(stream, 'rd')
                if cand and cand['hash']:
                    cand['url'] = ''
                    cands.append(cand)
        except Exception as e:
            _log('fetch_plain title fallback error: %s' % e)
    return rank(cands, weak, bool(season and episode))


# ---------------------------------------------------------------- learning memory

def learn_key(imdb, season=None, episode=None):
    imdb = (imdb or '').strip()
    if season and episode:
        return '%s:%s:%s' % (imdb, int(season), int(episode))
    return imdb


def _memory_path():
    return _profile('addon_data/script.antivenom/rd_learned.json')


def _mem_load():
    try:
        with open(_memory_path(), 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _mem_save(data):
    path = _memory_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if len(data) > LEARN_MAX:
            ranked = sorted(data.items(), key=lambda item: (item[1] or {}).get('ts') or 0)
            data = dict(ranked[-LEARN_MAX:])
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
        os.replace(tmp, path)
    except Exception as exc:
        _log('memory write failed: %s' % exc)


def recall(key):
    row = _mem_load().get(key) or {}
    if not isinstance(row, dict):
        return {}
    now = time.time()
    bad = row.get('bad') or {}
    row['bad'] = dict((h, ts) for h, ts in bad.items() if now - (ts or 0) < BAD_TTL)
    return row


def remember(key, cand, pending=False):
    info_hash = (cand.get('hash') or '').lower()
    if not key or not info_hash:
        return
    data = _mem_load()
    row = data.get(key) if isinstance(data.get(key), dict) else {}
    url = cand.get('url') or ''
    row.update({
        'hash': info_hash,
        'src': cand.get('src') or 'rd',
        # Comet playback URLs are tied to one key; only Torrentio templates are reusable.
        'url': url if (cand.get('src') == 'torrentio' and KEY_SLOT in url) else '',
        'ts': int(time.time()),
    })
    if pending:
        row['pending'] = 1
    else:
        row.pop('pending', None)
    (row.get('bad') or {}).pop(info_hash, None)
    data[key] = row
    _mem_save(data)
    _log('remembered %s -> %s (%s%s)' % (key, info_hash[:12], row['src'], ', pending' if pending else ''))


def remember_bad(key, info_hash, why=''):
    info_hash = (info_hash or '').lower()
    if not key or not info_hash:
        return
    data = _mem_load()
    row = data.get(key) if isinstance(data.get(key), dict) else {}
    now = int(time.time())
    bad = dict((h, ts) for h, ts in (row.get('bad') or {}).items() if now - (ts or 0) < BAD_TTL)
    bad[info_hash] = now
    if len(bad) > BAD_MAX:
        bad = dict(sorted(bad.items(), key=lambda item: item[1])[-BAD_MAX:])
    row['bad'] = bad
    if row.get('hash') == info_hash:
        for field in ('hash', 'url', 'src', 'pending'):
            row.pop(field, None)
    row.setdefault('ts', now)
    data[key] = row
    _mem_save(data)
    _log('skipping %s for %s from now on (%s)' % (info_hash[:12], key, why or 'failed'))


# ---------------------------------------------------------------- prefetch cache (window properties, no key)

def _home():
    return xbmcgui.Window(10000)


def prefetch_save(key, cands):
    try:
        win = _home()
        win.setProperty(PREFETCH_PROP + key, json.dumps({'ts': int(time.time()), 'items': cands[:PREFETCH_KEEP]}))
        index = [k for k in (win.getProperty(PREFETCH_INDEX) or '').split(',') if k and k != key]
        index.append(key)
        for old in index[:-PREFETCH_MAX_TITLES]:
            win.clearProperty(PREFETCH_PROP + old)
        win.setProperty(PREFETCH_INDEX, ','.join(index[-PREFETCH_MAX_TITLES:]))
    except Exception as exc:
        _log('prefetch store failed: %s' % exc)


def prefetch_load(key):
    try:
        raw = _home().getProperty(PREFETCH_PROP + key)
        if not raw:
            return None
        data = json.loads(raw)
        if time.time() - (data.get('ts') or 0) > PREFETCH_TTL:
            return None
        return data.get('items') or []
    except Exception:
        return None


def prefetch(imdb, season=None, episode=None):
    """Fetch and cache the Torrentio cached list only. Never touches the RD account."""
    key = token()
    if not key or not imdb:
        return None
    cands = fetch_torrentio(imdb, season, episode, key, low_power())
    prefetch_save(learn_key(imdb, season, episode), cands)
    return cands


class Prefetcher(object):
    """Service-side focus prefetch: one request at a time, a few per minute."""
    STABLE_S = 1.5
    MAX_PER_MIN = 4

    def __init__(self, lookup):
        self.lookup = lookup
        self._label = ''
        self._since = 0.0
        self._done = {}
        self._recent = []
        self._thread = None

    def reset(self):
        self._label = ''
        self._since = 0.0

    def tick(self, label):
        now = time.time()
        if label != self._label:
            self._label = label
            self._since = now
            return False
        if not label or now - self._since < self.STABLE_S:
            return False
        if self._thread is not None and self._thread.is_alive():
            return False
        target = self.lookup(label)
        if not target:
            return False
        key = learn_key(*target)
        if now - self._done.get(key, 0) < PREFETCH_TTL:
            return False
        self._recent = [t for t in self._recent if now - t < 60]
        if len(self._recent) >= self.MAX_PER_MIN:
            return False
        self._done[key] = now
        if prefetch_load(key) is not None:
            return False
        self._recent.append(now)
        self._thread = threading.Thread(target=self._run, args=target)
        self._thread.daemon = True
        self._thread.start()
        return True

    def _run(self, imdb, season=None, episode=None):
        started = time.time()
        try:
            cands = prefetch(imdb, season, episode)
            if cands is not None:
                _log('prefetched %d cached streams for %s in %.1fs' % (
                    len(cands), learn_key(imdb, season, episode), time.time() - started))
        except Exception as exc:
            _log('prefetch failed for %s: %s' % (imdb, exc))


# ---------------------------------------------------------------- Real-Debrid direct (addMagnet path)

def pick_file(files, season=None, episode=None):
    videos = []
    for item in files or []:
        path = (item.get('path') or '').lower()
        if path.endswith(VIDEO_EXT) and 'sample' not in os.path.basename(path):
            videos.append(item)
    if not videos:
        return None
    if season and episode:
        s = int(season)
        e = int(episode)
        matched = []
        for f in videos:
            p = (f.get('path') or '').lower()
            if re.search(r's0*%d[\s._-]*e0*%d(?!\d)|\b0*%dx0*%d(?!\d)' % (s, e, s, e), p):
                matched.append(f)
            elif re.search(r'season[\s._-]*0*%d.*(?:episode|ep)[\s._-]*0*%d(?!\d)' % (s, e), p):
                matched.append(f)
            elif re.search(r'(?:season[\s._-]*0*%d|s0*%d)[\\/].*?\b0*%d(?!\d)' % (s, s, e), p):
                matched.append(f)
        if matched:
            videos = matched
        elif len(videos) > 1:
            return None
    return max(videos, key=lambda f: int(f.get('bytes') or 0))


def _rd_unrestrict(key, link):
    unlocked = _rd('/unrestrict/link', key, data={'link': link})
    return unlocked.get('download') or ''


def _rd_existing(key, info_hash):
    try:
        rows = _rd('/torrents?limit=100', key)
    except AuthError:
        raise
    except Exception:
        return None
    for row in rows if isinstance(rows, list) else []:
        if (row.get('hash') or '').lower() == info_hash:
            return row
    return None


def _rd_select(key, torrent_id, info, season, episode):
    chosen = pick_file(info.get('files'), season, episode)
    if chosen is not None:
        files = str(chosen.get('id'))
    elif season and episode:
        return False
    else:
        files = 'all'
    _rd('/torrents/selectFiles/%s' % torrent_id, key, data={'files': files})
    return True


def rd_direct(key, info_hash, season=None, episode=None, keep=False):
    """Play-ready RD link for a hash if Real-Debrid already has it downloaded.

    Returns (url, status). Uncached torrents are deleted again unless keep=True.
    """
    existing = _rd_existing(key, info_hash)
    if existing and existing.get('status') == 'downloaded' and existing.get('links'):
        info = _rd('/torrents/info/%s' % existing['id'], key)
        link = _link_for(info, season, episode)
        if link:
            return _rd_unrestrict(key, link), 'downloaded'
    if existing and existing.get('status') not in ('downloaded',) + RD_FAIL_STATUS:
        return '', '%s %s%%' % (existing.get('status'), existing.get('progress') or 0)
    added = _rd('/torrents/addMagnet', key, data={'magnet': 'magnet:?xt=urn:btih:%s' % info_hash})
    torrent_id = added.get('id')
    if not torrent_id:
        return '', 'addMagnet failed'
    info = _rd('/torrents/info/%s' % torrent_id, key)
    if info.get('status') == 'waiting_files_selection':
        if not _rd_select(key, torrent_id, info, season, episode):
            _rd_delete(key, torrent_id)
            return '', 'episode not in torrent'
        info = _rd('/torrents/info/%s' % torrent_id, key)
    status = info.get('status') or ''
    if status == 'downloaded':
        link = _link_for(info, season, episode)
        if link:
            return _rd_unrestrict(key, link), 'downloaded'
    if not keep:
        _rd_delete(key, torrent_id)
    return '', status or 'unknown'


def _link_for(info, season=None, episode=None):
    links = info.get('links') or []
    if not links:
        return ''
    selected = [f for f in info.get('files') or [] if f.get('selected') == 1]
    if len(selected) == len(links) and len(links) > 1:
        chosen = pick_file(selected, season, episode)
        if chosen is not None:
            return links[selected.index(chosen)]
    return links[0]


def _rd_delete(key, torrent_id):
    try:
        _rd('/torrents/delete/%s' % torrent_id, key, method='DELETE')
    except Exception:
        pass


# ---------------------------------------------------------------- playback

class _PlayWatch(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.state = ''

    def onAVStarted(self):
        self.state = 'started'

    def onPlayBackError(self):
        self.state = 'error'

    def onPlayBackStopped(self):
        if not self.state:
            self.state = 'stopped'

    def onPlayBackEnded(self):
        if not self.state:
            self.state = 'ended'


def _list_item(url, meta):
    meta = meta or {}
    item = xbmcgui.ListItem(label=meta.get('label') or 'AntiVenom', path=url)
    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(meta.get('label') or '')
        if meta.get('season') and meta.get('episode'):
            tag.setMediaType('episode')
            tag.setTvShowTitle(meta.get('show') or '')
            tag.setSeason(int(meta['season']))
            tag.setEpisode(int(meta['episode']))
        else:
            tag.setMediaType('movie')
        if meta.get('imdb'):
            tag.setIMDBNumber(meta['imdb'])
        year = str(meta.get('year') or '')
        if year.isdigit():
            tag.setYear(int(year))
    except Exception:
        pass
    if meta.get('thumb'):
        item.setArt({'thumb': meta['thumb'], 'poster': meta['thumb'], 'icon': meta['thumb']})
    return item


def play_url(url, meta=None, wait=PLAY_WAIT):
    """'started' | 'error' | 'stopped' (user backed out) | 'timeout'."""
    watch = _PlayWatch()
    begun = time.time()
    watch.play(url, _list_item(url, meta))
    monitor = xbmc.Monitor()
    deadline = begun + wait
    while time.time() < deadline and not monitor.abortRequested():
        if watch.state == 'started':
            return 'started'
        if watch.state in ('error', 'ended'):
            return 'error'
        if watch.state == 'stopped':
            # Nobody can press Back within 2s; that is a failed open.
            return 'stopped' if time.time() - begun > 2 else 'error'
        xbmc.sleep(250)
    return 'started' if watch.isPlayingVideo() else 'timeout'


# ---------------------------------------------------------------- the play flow

class Result(object):
    def __init__(self):
        self.played = False
        self.cancelled = False
        self.imdb = ''
        self.has_token = False
        self.reason = ''


def _notify(msg, ms=2500):
    xbmcgui.Dialog().notification('AntiVenom', msg, xbmcgui.NOTIFICATION_INFO, ms)


class _Session(object):
    """One Play press: tries candidates in order within the time budget."""

    def __init__(self, key, learn, meta, season, episode, player=None, resolver=None):
        self.key = key
        self.learn = learn
        self.meta = meta
        self.season = season
        self.episode = episode
        self.deadline = time.time() + SEARCH_BUDGET
        self.tried = set()
        self.plays = 0
        self.resolves = 0
        self.refreshed = False
        self.cancelled = False
        self._play = player or play_url
        self._resolve = resolver or resolve

    def remaining(self):
        return self.deadline - time.time()

    def can_try(self):
        return (not self.cancelled and self.plays < MAX_PLAY_TRIES
                and self.resolves < MAX_RESOLVE_TRIES and self.remaining() > 1)

    def _start(self, direct, cand):
        self.plays += 1
        state = self._play(direct, self.meta)
        if state == 'started':
            remember(self.learn, cand)
            _log('playing %s %s' % (cand.get('src'), (cand.get('hash') or '')[:12]))
            return True
        if state == 'stopped':
            self.cancelled = True
            _log('playback stopped by user while loading; not trying other streams')
            return False
        remember_bad(self.learn, cand.get('hash'), 'player %s' % state)
        return False

    def try_stream(self, cand):
        """Resolve an addon stream URL (Torrentio/Comet) and play it."""
        h = cand.get('hash') or cand.get('url')
        if h in self.tried:
            return False
        self.tried.add(h)
        self.resolves += 1
        direct, why = self._resolve(unscrub(cand['url'], self.key), min(RESOLVE_TIMEOUT, max(2, self.remaining())))
        if why == 'auth' and not self.refreshed:
            self.refreshed = True
            fresh = refresh_token()
            if fresh:
                self.key = fresh
                direct, why = self._resolve(unscrub(cand['url'], self.key), RESOLVE_TIMEOUT)
        if not direct:
            _log('%s %s did not resolve (%s)' % (cand.get('src'), (cand.get('hash') or '')[:12], why))
            if cand.get('hash') and self.key:
                _log('addon resolve failed; falling back to direct Real-Debrid check for %s' % cand['hash'][:12])
                try:
                    direct_rd, status = rd_direct(self.key, cand['hash'], self.season, self.episode, keep=False)
                    if direct_rd:
                        _log('direct RD check succeeded for %s' % cand['hash'][:12])
                        return self._start(direct_rd, cand)
                except Exception as rd_exc:
                    _log('direct RD check error: %s' % rd_exc)
            if why.startswith('placeholder') or why.startswith('http 4'):
                remember_bad(self.learn, cand.get('hash'), why)
            return False
        return self._start(direct, cand)

    def try_rd(self, cand, keep=False):
        """Real-Debrid addMagnet path: plays only if RD already has the file."""
        h = cand.get('hash')
        if not h or h in self.tried:
            return False
        self.tried.add(h)
        self.resolves += 1
        try:
            direct, status = rd_direct(self.key, h, self.season, self.episode, keep=keep)
        except AuthError:
            fresh = '' if self.refreshed else refresh_token()
            self.refreshed = True
            if not fresh:
                return False
            self.key = fresh
            direct, status = rd_direct(self.key, h, self.season, self.episode, keep=keep)
        if not direct:
            _log('RD has no ready copy of %s (%s)' % (h[:12], status))
            if cand.get('pending') and status and status[0].isalpha() and '%' in status:
                _notify('Real-Debrid is still getting it ready (%s)' % status.split(' ')[-1], 3000)
            elif not cand.get('pending'):
                remember_bad(self.learn, h, 'rd %s' % status)
            return False
        return self._start(direct, cand)


def find_and_play(title, imdb, season=None, episode=None, lookup_title=None, year=None, thumb='', tmdb=None):
    res = Result()
    from . import imdblookup
    kind = 'series' if season and episode else 'movie'
    name = lookup_title or title
    imdb = imdblookup.clean(imdb)
    res.imdb = imdb
    if not fast_mode_on():
        res.reason = 'fast mode off'
        return res
    key = token()
    if not key:
        res.reason = 'no Real-Debrid token'
        _log('cached play skipped (no token)')
        return res
    res.has_token = True
    looked_up = False
    if not imdb:
        if tmdb:
            imdb = imdblookup.resolve_from_tmdb(tmdb, kind)
        if not imdb:
            imdb = imdblookup.resolve(name, year, kind, tmdb=tmdb)
        looked_up = True
        res.imdb = imdb
    if not imdb:
        res.reason = 'no imdb'
        _log('cached play skipped (no imdb for %s)' % name)
        return res

    _notify('Finding a cached stream...')
    weak = low_power()
    meta = {'label': title, 'show': lookup_title or '', 'season': season, 'episode': episode,
            'imdb': imdb, 'year': year, 'thumb': thumb}
    learn = learn_key(imdb, season, episode)
    session = _Session(key, learn, meta, season, episode)
    started = time.time()

    try:
        row = recall(learn)
        bad = set((row.get('bad') or {}).keys())
        session.tried.update(bad)

        # 1. what worked last time
        if row.get('hash') and row['hash'] not in bad:
            learned = {'hash': row['hash'], 'src': row.get('src') or 'rd', 'url': row.get('url') or '',
                       'pending': row.get('pending')}
            _log('trying learned %s for %s' % (learned['hash'][:12], learn))
            ok = session.try_stream(learned) if learned['url'] else session.try_rd(learned)
            if ok:
                res.played = True
                return res
            if session.cancelled:
                res.cancelled = True
                return res
            session.plays = 0

        # 2. Torrentio cached list (prefetched while browsing, else one request)
        torrentio_err = False
        cands = prefetch_load(learn)
        if cands is not None:
            _log('using prefetched list for %s (%d streams)' % (learn, len(cands)))
        else:
            try:
                cands = fetch_torrentio(imdb, season, episode, session.key, weak, min(LIST_TIMEOUT, session.remaining()))
                prefetch_save(learn, cands)
            except Exception as exc:
                torrentio_err = True
                cands = []
                _log('Torrentio list failed: %s' % exc)
        if not cands and not looked_up and not torrentio_err:
            alt = imdblookup.resolve(name, year, kind, tmdb=tmdb)
            if alt and alt != imdb:
                _log('no cached streams for %s; retrying with title match %s' % (imdb, alt))
                imdb = res.imdb = meta['imdb'] = alt
                learn = session.learn = learn_key(imdb, season, episode)
                try:
                    cands = fetch_torrentio(imdb, season, episode, session.key, weak, min(LIST_TIMEOUT, session.remaining()))
                except Exception as exc:
                    _log('Torrentio list failed: %s' % exc)
        for cand in cands:
            if not session.can_try():
                break
            if session.try_stream(cand):
                res.played = True
                return res
        if session.cancelled:
            res.cancelled = True
            return res

        # 3. Comet backup (only new hashes)
        comet_err = False
        if session.plays < MAX_PLAY_TRIES and session.remaining() > 2:
            try:
                backup = fetch_comet(imdb, season, episode, session.key, weak, min(LIST_TIMEOUT, session.remaining()),
                                     title=name, year=None if season else year)
            except Exception as exc:
                comet_err = True
                backup = []
                _log('Comet list failed: %s' % exc)
            backup = [c for c in backup if c.get('hash') not in session.tried]
            if backup:
                _log('Comet backup: %d new cached streams' % len(backup))
            for cand in backup:
                if not session.can_try():
                    break
                if session.try_stream(cand):
                    res.played = True
                    return res
            if session.cancelled:
                res.cancelled = True
                return res

        # 4. Ask Real-Debrid directly about the best plain hashes if no stream played yet
        if not res.played and session.plays < MAX_PLAY_TRIES and session.remaining() > 2:
            try:
                plain = fetch_plain(imdb, season, episode, weak, min(LIST_TIMEOUT, session.remaining()), title=name)
            except Exception as exc:
                plain = []
                _log('plain Torrentio list failed: %s' % exc)
            plain = [c for c in plain if c.get('hash') not in session.tried]
            if plain:
                _log('plain torrent backup: %d hashes found; checking Real-Debrid directly' % len(plain))
            for cand in plain[:5]:
                if not session.can_try():
                    break
                if session.try_rd(cand):
                    res.played = True
                    return res
            if session.cancelled:
                res.cancelled = True
                return res

        res.cancelled = session.cancelled
        res.reason = 'nothing cached'
        _log('no cached stream played for %s after %.1fs (%d plays, %d resolves)' % (
            learn, time.time() - started, session.plays, session.resolves))
        return res
    except Exception as exc:
        res.reason = 'error: %s' % exc
        _log('cached play failed: %s' % exc)
        return res


def try_play(title, imdb, season=None, episode=None, lookup_title=None, year=None, tmdb=None):
    """Compatibility wrapper: True when a cached Real-Debrid file started playing."""
    return find_and_play(title, imdb, season, episode, lookup_title, year, tmdb=tmdb).played


# ---------------------------------------------------------------- "Getting it ready..." (RD download)

def offer_download(title, imdb, season=None, episode=None, lookup_title=None, year=None, thumb='', tmdb=None):
    """Ask Real-Debrid to download the best torrent, show progress, play when ready."""
    key = token()
    if not imdb and tmdb:
        from . import imdblookup
        imdb = imdblookup.resolve_from_tmdb(tmdb, 'series' if season and episode else 'movie')
    if not key or not imdb:
        return False
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(
        'Not ready yet',
        'No instant copy of [B]%s[/B] was found.\n\n'
        'Ask Real-Debrid to download it now? This usually takes a few minutes. '
        'You can cancel and keep browsing; it keeps downloading.' % title,
        yeslabel='Get it ready',
        nolabel='No thanks',
    ):
        return False
    learn = learn_key(imdb, season, episode)
    bad = set((recall(learn).get('bad') or {}).keys())
    weak = low_power()
    progress = xbmcgui.DialogProgress()
    progress.create('Getting it ready...', 'Finding the best copy for %s...' % title)
    torrent_id = None
    chosen = None
    try:
        try:
            cands = [c for c in fetch_plain(imdb, season, episode, weak, title=title) if c['hash'] not in bad]
        except Exception as exc:
            _log('download: plain list failed: %s' % exc)
            cands = []
        cands.sort(key=lambda c: (c.get('seeders') or 0) >= 5, reverse=True)
        for cand in cands[:3]:
            if progress.iscanceled():
                return False
            try:
                added = _rd('/torrents/addMagnet', key, data={'magnet': 'magnet:?xt=urn:btih:%s' % cand['hash']})
            except AuthError:
                key = refresh_token()
                if not key:
                    break
                added = _rd('/torrents/addMagnet', key, data={'magnet': 'magnet:?xt=urn:btih:%s' % cand['hash']})
            torrent_id = added.get('id')
            if not torrent_id:
                continue
            info = {}
            for _ in range(15):
                info = _rd('/torrents/info/%s' % torrent_id, key)
                if info.get('status') != 'magnet_conversion' or progress.iscanceled():
                    break
                xbmc.sleep(1000)
            if info.get('status') == 'waiting_files_selection':
                if not _rd_select(key, torrent_id, info, season, episode):
                    _rd_delete(key, torrent_id)
                    torrent_id = None
                    continue
            elif info.get('status') in RD_FAIL_STATUS or info.get('status') == 'magnet_conversion':
                _rd_delete(key, torrent_id)
                remember_bad(learn, cand['hash'], 'rd %s' % info.get('status'))
                torrent_id = None
                continue
            chosen = cand
            break
        if not torrent_id or not chosen:
            progress.close()
            dialog.ok('Not available', 'Real-Debrid could not start a download for %s.' % title)
            return False

        monitor = xbmc.Monitor()
        deadline = time.time() + 3600
        info = {}
        while time.time() < deadline and not monitor.abortRequested():
            info = _rd('/torrents/info/%s' % torrent_id, key)
            status = info.get('status') or ''
            if status == 'downloaded':
                break
            if status in RD_FAIL_STATUS:
                progress.close()
                _rd_delete(key, torrent_id)
                remember_bad(learn, chosen['hash'], 'rd %s' % status)
                dialog.ok('Download failed', 'Real-Debrid could not download this copy (%s).' % status)
                return False
            pct = int(info.get('progress') or 0)
            speed = int(info.get('speed') or 0) // (1024 * 1024)
            seeds = info.get('seeders') or 0
            progress.update(pct, 'Real-Debrid is downloading %s\n%d%%  -  %d MB/s  -  %s seeders' % (title, pct, speed, seeds))
            if progress.iscanceled():
                progress.close()
                if dialog.yesno('Keep downloading?', 'Let Real-Debrid keep downloading %s?\n\n'
                                'Press play again later and it will start instantly.' % title,
                                yeslabel='Keep downloading', nolabel='Delete it'):
                    remember(learn, dict(chosen, src='rd'), pending=True)
                else:
                    _rd_delete(key, torrent_id)
                return False
            monitor.waitForAbort(3)
        if info.get('status') != 'downloaded':
            progress.close()
            remember(learn, dict(chosen, src='rd'), pending=True)
            return False
        progress.update(100, 'Ready. Starting %s...' % title)
        link = _link_for(info, season, episode)
        direct = _rd_unrestrict(key, link) if link else ''
        progress.close()
        if not direct:
            dialog.ok('Not available', 'Real-Debrid finished but did not return a playable file.')
            return False
        meta = {'label': title, 'show': lookup_title or '', 'season': season, 'episode': episode,
                'imdb': imdb, 'year': year, 'thumb': thumb}
        if play_url(direct, meta) == 'started':
            remember(learn, dict(chosen, src='rd'))
            return True
        return False
    except Exception as exc:
        _log('download flow failed: %s' % exc)
        try:
            progress.close()
        except Exception:
            pass
        return False
