# -*- coding: utf-8 -*-
"""
Device capability profile and AntiVenom Fast Mode.

Fast Mode is ON by default for every user. It is only off when the user
explicitly disables it (Skin setting AntiVenom_FastMode_Off or flag file).
The service re-applies the active profile on every boot so setup paths cannot
permanently undo it.
"""
import os
import re
import struct

import xbmc
import xbmcaddon
import xbmcvfs

FAST_MODE_OFF_SKIN = 'AntiVenom_FastMode_Off'
FAST_MODE_OFF_FLAG = xbmcvfs.translatePath(
    'special://profile/addon_data/script.antivenom/.fast_mode_off'
)

CREW_FALLBACK_OFF_SKIN = 'AntiVenom_CrewFallback_Off'
CREW_FALLBACK_OFF_FLAG = xbmcvfs.translatePath(
    'special://profile/addon_data/script.antivenom/.crew_fallback_off'
)

CACHE_MB_LITE = 40
CACHE_MB_DEFAULT = 100


def _log(msg):
    xbmc.log(f'[AntiVenom Device] {msg}', xbmc.LOGINFO)


def total_ram_mb():
    label = xbmc.getInfoLabel('System.Memory(total)') or ''
    m = re.search(r'(\d+)', label.replace(',', ''))
    if m:
        val = int(m.group(1))
        return val // 1024 if 'KB' in label.upper() and val > 100000 else val
    try:
        with open('/proc/meminfo', 'r') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    return int(line.split()[1]) // 1024
    except Exception:
        pass
    return 0


def is_android():
    return xbmc.getCondVisibility('System.Platform.Android')


def is_32bit():
    return struct.calcsize('P') * 8 == 32


def is_low_power():
    """True for devices that cannot handle 4K/10-bit HEVC or heavy scraping."""
    if not is_android():
        return False
    ram = total_ram_mb()
    return is_32bit() or (0 < ram <= 1100)


def cache_size_mb():
    return CACHE_MB_LITE if is_low_power() else CACHE_MB_DEFAULT


def describe():
    return (
        f'android={is_android()} 32bit={is_32bit()} ram={total_ram_mb()}MB '
        f'low_power={is_low_power()} fast_mode={is_fast_mode_enabled()}'
    )


def is_fast_mode_enabled():
    """Default ON. Only off when the user explicitly disabled Fast Mode."""
    if os.path.isfile(FAST_MODE_OFF_FLAG):
        return False
    if xbmc.getCondVisibility(f'Skin.HasSetting({FAST_MODE_OFF_SKIN})'):
        return False
    return True


def set_fast_mode_enabled(enabled):
    """Persist opt-out/opt-in. Absent setting means Fast Mode ON."""
    try:
        os.makedirs(os.path.dirname(FAST_MODE_OFF_FLAG), exist_ok=True)
        if enabled:
            if os.path.isfile(FAST_MODE_OFF_FLAG):
                os.remove(FAST_MODE_OFF_FLAG)
            xbmc.executebuiltin(f'Skin.Reset({FAST_MODE_OFF_SKIN})')
        else:
            with open(FAST_MODE_OFF_FLAG, 'w', encoding='utf-8') as f:
                f.write('1')
            xbmc.executebuiltin(f'Skin.SetBool({FAST_MODE_OFF_SKIN})')
    except Exception as e:
        _log(f'set_fast_mode_enabled({enabled}) error: {e}')


def fast_mode_menu_label():
    if is_fast_mode_enabled():
        return '🚀  Fast Mode: ON (tap to turn OFF)'
    return '🐢  Fast Mode: OFF (tap to turn ON)'


def is_crew_fallback_enabled():
    """Default ON. When OFF, a Real-Debrid miss never opens The Crew search."""
    if os.path.isfile(CREW_FALLBACK_OFF_FLAG):
        return False
    if xbmc.getCondVisibility(f'Skin.HasSetting({CREW_FALLBACK_OFF_SKIN})'):
        return False
    return True


def set_crew_fallback_enabled(enabled):
    try:
        os.makedirs(os.path.dirname(CREW_FALLBACK_OFF_FLAG), exist_ok=True)
        if enabled:
            if os.path.isfile(CREW_FALLBACK_OFF_FLAG):
                os.remove(CREW_FALLBACK_OFF_FLAG)
            xbmc.executebuiltin(f'Skin.Reset({CREW_FALLBACK_OFF_SKIN})')
        else:
            with open(CREW_FALLBACK_OFF_FLAG, 'w', encoding='utf-8') as f:
                f.write('1')
            xbmc.executebuiltin(f'Skin.SetBool({CREW_FALLBACK_OFF_SKIN})')
    except Exception as e:
        _log(f'set_crew_fallback_enabled({enabled}) error: {e}')


def crew_fallback_menu_label():
    if is_crew_fallback_enabled():
        return '🛟  The Crew Backup Search: ON (tap to turn OFF)'
    return '🚫  The Crew Backup Search: OFF (tap to turn ON)'


def _crew_addon():
    if not xbmc.getCondVisibility('System.HasAddon(plugin.video.thecrew)'):
        return None
    try:
        return xbmcaddon.Addon('plugin.video.thecrew')
    except Exception as e:
        _log(f'The Crew not loadable: {e}')
        return None


def _set_crew(addon, key, value):
    try:
        cur = addon.getSetting(key)
        if cur != value:
            addon.setSetting(key, value)
            return True
    except Exception as e:
        _log(f'could not set {key}: {e}')
    return False


def _apply_crew_map(crew, settings):
    changed = 0
    for key, value in settings.items():
        if _set_crew(crew, key, value):
            changed += 1
    return changed


def _set_resolveurl_cached_only(cached_first):
    """RD cached-first in Fast Mode; allow uncached torrents when Fast Mode is off."""
    path = xbmcvfs.translatePath(
        'special://profile/addon_data/script.module.resolveurl/settings.xml'
    )
    if not os.path.isfile(path):
        return False
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        want = 'true' if cached_first else 'false'
        new_content, n = re.subn(
            r'(<setting id="RealDebridResolver_cached_only"[^>]*>)(?:true|false)(</setting>)',
            r'\g<1>' + want + r'\g<2>',
            content,
        )
        if n and new_content != content:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            _log(f'ResolveURL cached_only={want}')
            return True
    except Exception as e:
        _log(f'ResolveURL cached_only patch error: {e}')
    return False


def ensure_crew_autoplay():
    """hosts.mode=2 auto-play best stream (also passed as select=2 on play URLs)."""
    crew = _crew_addon()
    if not crew:
        return False
    changed = 0
    changed += _set_crew(crew, 'hosts.mode', '2')
    changed += _set_crew(crew, 'autoplay.sd', 'true')
    if changed:
        _log('The Crew autoplay enabled (hosts.mode=2)')
    return changed > 0


def apply_fast_profile(debrid_linked):
    """Fast Mode ON: two scraper packs, short timeout, autoplay, RD cached-first."""
    crew = _crew_addon()
    if not crew:
        return False

    settings = {
        'crewscrapers.enabled': 'true',
        'classyscrapers.enabled': 'true',
        'gearsscrapers.enabled': 'false',
        'cocoscrapers.enabled': 'false',
        'viperscrapers.enabled': 'false',
        'magneto.enabled': 'false',
        'scrapers.timeout.1': '8',
        'hosts.mode': '2',
        'autoplay.sd': 'true',
        'max.threads': '10',
        'max.limit.sources': '40',
        'torrent.enabled': 'true',
        'debrid.only': 'true' if debrid_linked else 'false',
    }
    if is_low_power():
        settings['hosts.quality'] = '2'

    changed = _apply_crew_map(crew, settings)
    if _set_resolveurl_cached_only(bool(debrid_linked)):
        changed += 1
    _log(f'Fast profile applied ({changed} settings changed): {describe()}')
    return changed > 0


def apply_full_profile(debrid_linked):
    """Fast Mode OFF: restore broader scraper coverage and source picking."""
    crew = _crew_addon()
    if not crew:
        return False

    settings = {
        'crewscrapers.enabled': 'true',
        'classyscrapers.enabled': 'true',
        'gearsscrapers.enabled': 'true',
        'cocoscrapers.enabled': 'true',
        'viperscrapers.enabled': 'true',
        'magneto.enabled': 'true',
        'scrapers.timeout.1': '15',
        'hosts.mode': '1',
        'autoplay.sd': 'true',
        'max.threads': '25',
        'max.limit.sources': '100',
        'torrent.enabled': 'true',
        'debrid.only': 'false',
    }
    changed = _apply_crew_map(crew, settings)
    if _set_resolveurl_cached_only(False):
        changed += 1
    _log(f'Full profile applied ({changed} settings changed): {describe()}')
    return changed > 0


def sync_crew_profile(debrid_linked):
    """Re-apply the active profile every boot (and after toggles)."""
    if is_fast_mode_enabled():
        return apply_fast_profile(debrid_linked)
    return apply_full_profile(debrid_linked)


def apply_crew_lite_profile(debrid_linked, force=False):
    """Backward-compatible alias used by older call sites."""
    if not is_fast_mode_enabled():
        return apply_full_profile(debrid_linked)
    return apply_fast_profile(debrid_linked)


def optimize_for_speed_now(debrid_linked, configure_advancedsettings_fn, clean_cache_fn):
    """One-tap re-apply: cache cap, Crew fast profile, temp cache clean."""
    adv_changed = False
    try:
        adv_changed = bool(configure_advancedsettings_fn())
    except Exception as e:
        _log(f'optimize advancedsettings error: {e}')

    set_fast_mode_enabled(True)
    sync_crew_profile(debrid_linked)
    try:
        clean_cache_fn(silent=True)
    except Exception as e:
        _log(f'optimize cache clean error: {e}')

    msg = (
        'Fast Mode is ON.\n\n'
        '• Crew + Classy scrapers only (~8s timeout)\n'
        '• Auto-play best stream with 3 automatic backups (4 tries total)\n'
    )
    if debrid_linked:
        msg += '• Real-Debrid cached-first\n'
    if adv_changed or not os.path.isfile(
        xbmcvfs.translatePath('special://masterprofile/advancedsettings.xml')
    ):
        msg += '\n[COLOR yellow]Restart Kodi once[/COLOR] if video cache was just changed.'
    return msg
