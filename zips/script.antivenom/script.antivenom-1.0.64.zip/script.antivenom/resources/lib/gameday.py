# -*- coding: utf-8 -*-
"""
AntiVenom GameDay Hub Engine
Pulls live scores, clocks, and matchup states from open sports scoreboard feeds.
Caches data locally with a 90-second TTL and sets dynamic Kodi window properties
for live badges and scoreboard overlays on the AntiVenom Sports canvas.
"""

import os
import json
import time
import datetime
import urllib.request
import urllib.parse
from typing import Dict, List, Any, Optional, Tuple

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
    KODI_ENV = True
except ImportError:
    KODI_ENV = False

LEAGUE_ENDPOINTS = {
    'NFL': 'https://site.web.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard',
    'CFB': 'https://site.web.api.espn.com/apis/site/v2/sports/football/college-football/scoreboard?groups=80&limit=150',
    'CFB_FCS': 'https://site.web.api.espn.com/apis/site/v2/sports/football/college-football/scoreboard?groups=81&limit=150',
    'NBA': 'https://site.web.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard',
    'WNBA': 'https://site.web.api.espn.com/apis/site/v2/sports/basketball/wnba/scoreboard',
    'MLB': 'https://site.web.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard',
    'NHL': 'https://site.web.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard?limit=100',
    'NCAA_HOCKEY': 'https://site.web.api.espn.com/apis/site/v2/sports/hockey/mens-college-hockey/scoreboard?limit=100',
    'EPL': 'https://site.web.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard',
    'UCL': 'https://site.web.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/scoreboard',
    'MLS': 'https://site.web.api.espn.com/apis/site/v2/sports/soccer/usa.1/scoreboard',
    'NCAAB': 'https://site.web.api.espn.com/apis/site/v2/sports/basketball/mens-college-basketball/scoreboard?limit=100',
    'UFC': 'https://site.web.api.espn.com/apis/site/v2/sports/mma/ufc/scoreboard',
    'BOXING': 'https://site.web.api.espn.com/apis/site/v2/sports/boxing/scoreboard',
    'F1': 'https://site.web.api.espn.com/apis/site/v2/sports/racing/f1/scoreboard',
    'NASCAR': 'https://site.web.api.espn.com/apis/site/v2/sports/racing/nascar-premier/scoreboard',
    'PGA': 'https://site.web.api.espn.com/apis/site/v2/sports/golf/pga/scoreboard',
    'TENNIS': 'https://site.web.api.espn.com/apis/site/v2/sports/tennis/atp/scoreboard',
}

DEFAULT_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*'
}

def log(msg: str, level: int = 1) -> None:
    if KODI_ENV:
        xbmc.log(f"[AntiVenom GameDay] {msg}", level)
    else:
        print(f"[AntiVenom GameDay] {msg}")

def _parse_event_timestamp(value: str) -> float:
    if not value:
        return 0.0
    try:
        dt = datetime.datetime.fromisoformat(str(value).strip().replace('Z', '+00:00'))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=datetime.timezone.utc)
        return dt.timestamp()
    except (TypeError, ValueError, OverflowError):
        return 0.0


def _event_is_today(event: Dict[str, Any], now: Optional[float] = None) -> bool:
    try:
        start_ts = float(event.get('start_ts') or _parse_event_timestamp(event.get('date', '')))
    except (TypeError, ValueError):
        start_ts = _parse_event_timestamp(event.get('date', ''))
    if start_ts > 0:
        current = datetime.datetime.fromtimestamp(now or time.time()).date()
        return datetime.datetime.fromtimestamp(start_ts).date() == current
    clock = str(event.get('clock', ''))
    marker = time.strftime('%m/%d').lstrip('0').replace('/0', '/')
    return marker in clock or 'today' in clock.lower()


def _event_sort_key(event: Dict[str, Any]) -> tuple:
    state = str(event.get('state', 'PRE')).upper()
    try:
        start_ts = float(event.get('start_ts') or _parse_event_timestamp(event.get('date', '')) or 0)
    except (TypeError, ValueError):
        start_ts = _parse_event_timestamp(event.get('date', ''))
    if state == 'IN':
        priority = 0
    elif state == 'PRE' and _event_is_today(event):
        priority = 1
    elif state == 'PRE':
        priority = 2
    else:
        priority = 3
    return priority, start_ts


def _with_today(url: str) -> str:
    today = datetime.datetime.now().strftime('%Y%m%d')
    join = '&' if '?' in url else '?'
    return f'{url}{join}dates={today}'


def get_cache_path() -> str:
    if KODI_ENV:
        addon_dir = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom')
        if not os.path.exists(addon_dir):
            os.makedirs(addon_dir, exist_ok=True)
        return os.path.join(addon_dir, 'gameday_scores.json')
    return os.path.join(os.path.dirname(__file__), 'gameday_scores.json')

def fetch_league_scoreboard(league: str, url: str) -> List[Dict[str, Any]]:
    """Fetches and parses scoreboard events for a single sports league, including multi-bout fight cards."""
    events_out = []
    try:
        req = urllib.request.Request(url, headers=DEFAULT_HEADERS)
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            raw_events = data.get('events', [])
            for ev in raw_events:
                status_type = ev.get('status', {}).get('type', {})
                base_state = status_type.get('state', 'pre').upper()  # PRE, IN, POST
                base_detail = status_type.get('detail', '')
                base_short = status_type.get('shortDetail', base_detail)

                comps_list = ev.get('competitions') or [{}]

                # ── Combat sports (UFC / BOXING): parse individual bouts ─────────────────────────
                if league in ('UFC', 'BOXING'):
                    bout_entries = []
                    total_bouts = len(comps_list)
                    for c_idx, comp in enumerate(comps_list):
                        competitors = comp.get('competitors', [])
                        if len(competitors) < 2:
                            continue

                        # Reverse index: 0 = Main Event (last bout in ESPN order)
                        rev = total_bouts - 1 - c_idx
                        if rev == 0:
                            segment = '[Main Event]'
                        elif rev == 1:
                            segment = '[Co-Main]'
                        elif rev < 5:
                            segment = '[Main Card]'
                        else:
                            segment = '[Prelim]'

                        # ESPN MMA uses competitor.athlete, not competitor.team
                        co0 = competitors[0]
                        co1 = competitors[1]
                        ath0 = co0.get('athlete') or {}
                        ath1 = co1.get('athlete') or {}

                        # Short names like "N. Silva"; fall back to displayName
                        short0 = ath0.get('shortName') or ath0.get('displayName') or 'Fighter 1'
                        short1 = ath1.get('shortName') or ath1.get('displayName') or 'Fighter 2'
                        full0 = ath0.get('displayName') or short0
                        full1 = ath1.get('displayName') or short1

                        # Weight class from competition type
                        weight = (comp.get('type') or {}).get('abbreviation') or ''

                        # Winner detection
                        win0 = co0.get('winner', False)
                        win1 = co1.get('winner', False)
                        winner_name = full0 if win0 else (full1 if win1 else None)

                        # Headshots via ESPN combiner (HTTP 200 for all fighter IDs)
                        id0 = co0.get('id') or ath0.get('id') or ''
                        id1 = co1.get('id') or ath1.get('id') or ''
                        head0 = (f'https://a.espncdn.com/combiner/i?img=/i/headshots/mma/players/full/{id0}.png'
                                 if id0 else '')
                        head1 = (f'https://a.espncdn.com/combiner/i?img=/i/headshots/mma/players/full/{id1}.png'
                                 if id1 else '')

                        comp_status = comp.get('status', {}).get('type') or status_type
                        state = comp_status.get('state', base_state).upper()

                        event_short = f'{segment} {short0} vs. {short1}'
                        event_name = f'{segment} {full0} vs. {full1}' + (f' ({weight})' if weight else '')

                        if state == 'IN':
                            clock_str = f'LIVE • {comp_status.get("shortDetail", "")}'
                            score_str = 'LIVE'
                        elif state == 'POST':
                            if winner_name:
                                loser = full1 if win0 else full0
                                clock_str = f'Final • {winner_name} def. {loser}' + (f' · {weight}' if weight else '')
                            else:
                                clock_str = 'Final'
                            score_str = 'Final'
                        else:
                            clock_str = ev.get('status', {}).get('type', {}).get('shortDetail', '')
                            score_str = f'{short0} vs. {short1}'

                        bout_entries.append({
                            'id': f"{ev.get('id', '')}_{comp.get('id', c_idx)}",
                            'date': ev.get('date', ''),
                            'start_ts': _parse_event_timestamp(ev.get('date', '')),
                            'league': league,
                            'name': event_name,
                            'short_name': event_short,
                            'state': state,
                            'detail': comp_status.get('detail', base_detail),
                            'clock': clock_str,
                            'score': score_str,
                            'away_name': full0,
                            'home_name': full1,
                            'away_abbr': short0,
                            'home_abbr': short1,
                            'away_score': '',
                            'home_score': '',
                            'away_logo': head0,
                            'home_logo': head1,
                            'search_terms': f'{full0} {full1} {league}'.lower(),
                        })

                    # Reverse so Main Event is first, Prelims at bottom
                    events_out.extend(reversed(bout_entries))
                    continue  # skip normal competition loop for combat sports

                # ── Standard team sports ────────────────────────────────────────────
                for c_idx, comp in enumerate(comps_list):
                    comps = comp.get('competitors', [])
                    if len(comps) < 2:
                        continue

                    away = next((c for c in comps if c.get('homeAway') == 'away'), comps[0])
                    home = next((c for c in comps if c.get('homeAway') == 'home'), comps[1])

                    away_team = away.get('team') or away.get('athlete') or {}
                    home_team = home.get('team') or home.get('athlete') or {}

                    away_name = away_team.get('displayName') or away_team.get('name') or away.get('displayName') or 'Away'
                    home_name = home_team.get('displayName') or home_team.get('name') or home.get('displayName') or 'Home'
                    away_abbr = away_team.get('abbreviation', away_name[:3].upper())
                    home_abbr = home_team.get('abbreviation', home_name[:3].upper())

                    comp_status = comp.get('status', {}).get('type') or status_type
                    state = comp_status.get('state', base_state).upper()
                    detail = comp_status.get('detail', base_detail)
                    short_detail = comp_status.get('shortDetail') or comp_status.get('detail') or base_short

                    away_score = str(away.get('score', '0'))
                    home_score = str(home.get('score', '0'))
                    away_logo = away_team.get('logo') or (away_team.get('headshot') or {}).get('href', '')
                    home_logo = home_team.get('logo') or (home_team.get('headshot') or {}).get('href', '')

                    # Determine display score / matchup
                    if state == 'PRE':
                        score_str = f"vs {home_abbr}"
                        clock_str = short_detail
                    elif state == 'IN':
                        score_str = f"{away_score} - {home_score}"
                        clock_str = f"LIVE • {short_detail}"
                    else:  # POST
                        score_str = f"{away_score} - {home_score}"
                        clock_str = "Final"

                    event_name = comp.get('name') or ev.get('name') or f"{away_name} vs {home_name}"
                    event_short = comp.get('shortName') or ev.get('shortName') or f"{away_abbr} vs {home_abbr}"

                    events_out.append({
                        "id": f"{ev.get('id', '')}_{comp.get('id', c_idx)}",
                        "date": ev.get('date', ''),
                        "start_ts": _parse_event_timestamp(ev.get('date', '')),
                        "league": league,
                        "name": event_name,
                        "short_name": event_short,
                        "state": state,
                        "detail": detail,
                        "clock": clock_str,
                        "score": score_str,
                        "away_name": away_name,
                        "home_name": home_name,
                        "away_abbr": away_abbr,
                        "home_abbr": home_abbr,
                        "away_score": away_score,
                        "home_score": home_score,
                        "away_logo": away_logo,
                        "home_logo": home_logo,
                        "search_terms": f"{away_name} {home_name} {away_abbr} {home_abbr}".lower()
                    })
    except Exception as e:
        log(f"Error fetching {league} scoreboard: {e}", 2 if KODI_ENV else 1)
        return None
    return events_out


PRIORITY_LEAGUES = ('NFL', 'NBA', 'MLB', 'NHL', 'EPL')
CACHE_TTL = 90
FULL_TTL = 600


def _load_cache() -> Optional[Dict[str, Any]]:
    cache_file = get_cache_path()
    if not os.path.isfile(cache_file):
        return None
    try:
        with open(cache_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return None


def _count_live(leagues: Dict[str, List[Dict[str, Any]]]) -> int:
    return sum(
        1
        for events in leagues.values()
        for event in (events or [])
        if str(event.get('state', '')).upper() == 'IN'
    )


def _write_cache(payload: Dict[str, Any]) -> None:
    """Write only real scoreboard payloads to disk."""
    cache_file = get_cache_path()
    try:
        parent = os.path.dirname(cache_file)
        if parent:
            os.makedirs(parent, exist_ok=True)
        tmp_path = cache_file + '.tmp'
        with open(tmp_path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2)
        os.replace(tmp_path, cache_file)
        log(f"Wrote GameDay cache live={payload.get('total_live')} leagues={len(payload.get('leagues') or {})}", 1)
    except Exception as e:
        log(f"Failed to write cache: {e}", 2 if KODI_ENV else 1)


def _pull_league(league: str, url: str) -> Optional[List[Dict[str, Any]]]:
    events = fetch_league_scoreboard(league, url)
    if events is None:
        return None
    if not events and league in PRIORITY_LEAGUES:
        extra = fetch_league_scoreboard(league, _with_today(url))
        if extra is not None:
            return extra
    return events


def _publish(payload: Dict[str, Any]) -> Dict[str, Any]:
    _write_cache(payload)
    if KODI_ENV:
        try:
            apply_gameday_to_skin(payload)
        except Exception as e:
            log(f"apply_gameday_to_skin failed: {e}", 2)
    return payload


def refresh_all_scores(force: bool = False) -> Dict[str, Any]:
    """Pull real scoreboards, write the cache, and update the Sports chip."""
    now = time.time()
    cached = _load_cache()
    age = now - float((cached or {}).get('last_updated') or 0)
    if not force and cached and age < CACHE_TTL:
        if KODI_ENV:
            apply_gameday_to_skin(cached)
        try:
            from resources.lib.sportshub import refresh_nfl_slate
            refresh_nfl_slate()
        except Exception:
            pass
        return cached

    log("Refreshing live sports scores from feeds...", 1)
    all_events: Dict[str, List[Dict[str, Any]]] = {}
    if cached and isinstance(cached.get('leagues'), dict):
        all_events.update(cached.get('leagues') or {})

    fetched_any = False
    for league in PRIORITY_LEAGUES:
        url = LEAGUE_ENDPOINTS.get(league)
        if not url:
            continue
        events = _pull_league(league, url)
        if events is None:
            continue
        fetched_any = True
        all_events[league] = events

    if fetched_any:
        payload = {
            'last_updated': now,
            'last_full': (cached or {}).get('last_full', 0),
            'total_live': _count_live(all_events),
            'leagues': all_events,
        }
        _publish(payload)
        cached = payload
    elif cached:
        log("Priority scoreboards failed; keeping last real cache", 1)
        if KODI_ENV:
            apply_gameday_to_skin(cached)
        return cached

    last_full = float((cached or {}).get('last_full') or 0)
    if force or now - last_full >= FULL_TTL:
        for league, url in LEAGUE_ENDPOINTS.items():
            if league in PRIORITY_LEAGUES:
                continue
            events = _pull_league(league, url)
            if events is None:
                continue
            fetched_any = True
            all_events[league] = events
        if fetched_any:
            cached = {
                'last_updated': now,
                'last_full': now,
                'total_live': _count_live(all_events),
                'leagues': all_events,
            }
            _publish(cached)

    if cached:
        log(f"GameDay live count: {cached.get('total_live')}", 1)
        try:
            from resources.lib.sportshub import refresh_nfl_slate
            refresh_nfl_slate()
        except Exception as e:
            log(f"NFL slate refresh failed: {e}", 1)
        return cached
    empty = {'last_updated': now, 'last_full': 0, 'total_live': 0, 'leagues': {}}
    log("GameDay live count: 0 (no scoreboard data yet)", 1)
    try:
        from resources.lib.sportshub import refresh_nfl_slate
        refresh_nfl_slate()
    except Exception:
        pass
    return empty

def apply_gameday_to_skin(data: Optional[Dict[str, Any]] = None) -> None:
    """Sets Kodi window properties for Home.xml skin rendering."""
    if not KODI_ENV:
        return

    if data is None:
        data = refresh_all_scores()

    win = xbmcgui.Window(10000)  # Home Window
    leagues = data.get('leagues', {})
    total_live = int(data.get('total_live') or 0)
    if not total_live:
        total_live = sum(1 for evs in leagues.values() for ev in evs if str(ev.get('state', '')).upper() == 'IN')
    total_today = sum(1 for evs in leagues.values() for ev in evs if _event_is_today(ev))

    win.setProperty('AntiVenom.GameDay.TotalLive', str(total_live))
    win.setProperty('AntiVenom.GameDay.TotalToday', str(total_today))
    win.setProperty('AntiVenom.GameDay.HasLive', "true" if total_live > 0 else "")
    win.setProperty('AntiVenom.GameDay.HasToday', "true" if total_today > 0 else "")
    if total_live > 0:
        win.setProperty('AntiVenom.GameDay.ChipLabel', f"LIVE: {total_live} GAMES NOW")
        win.setProperty('AntiVenom.GameDay.ChipColor', "FF00FF55")
    elif total_today > 0:
        win.setProperty('AntiVenom.GameDay.ChipLabel', f"GAMEDAY: {total_today} GAMES TODAY")
        win.setProperty('AntiVenom.GameDay.ChipColor', "FFFFCC00")
    else:
        win.setProperty('AntiVenom.GameDay.ChipLabel', "GAMEDAY HUB")
        win.setProperty('AntiVenom.GameDay.ChipColor', "FF00F5A0")

    for league, events in leagues.items():
        ordered_events = sorted(events, key=_event_sort_key)
        league_live_count = sum(1 for e in ordered_events if str(e.get('state', '')).upper() == 'IN')
        has_today = any(_event_is_today(ev) for ev in ordered_events)
        win.setProperty(f"AntiVenom.GameDay.{league}.HasLive", "true" if league_live_count > 0 else "")
        win.setProperty(f"AntiVenom.GameDay.{league}.HasToday", "true" if has_today else "")
        win.setProperty(f"AntiVenom.GameDay.{league}.LiveCount", str(league_live_count))

        # Top 8 games per league
        for i, ev in enumerate(ordered_events[:8], start=1):
            prefix = f"AntiVenom.GameDay.{league}.{i}."
            win.setProperty(f"{prefix}Active", "true")
            win.setProperty(f"{prefix}Matchup", ev.get('name', ''))
            win.setProperty(f"{prefix}Short", ev.get('short_name', ''))
            win.setProperty(f"{prefix}Score", ev.get('score', ''))
            win.setProperty(f"{prefix}Clock", ev.get('clock', ''))
            win.setProperty(f"{prefix}State", ev.get('state', 'PRE'))
            win.setProperty(f"{prefix}AwayName", ev.get('away_name', ''))
            win.setProperty(f"{prefix}HomeName", ev.get('home_name', ''))
            win.setProperty(f"{prefix}AwayAbbr", ev.get('away_abbr', ''))
            win.setProperty(f"{prefix}HomeAbbr", ev.get('home_abbr', ''))
            win.setProperty(f"{prefix}AwayScore", ev.get('away_score', '0'))
            win.setProperty(f"{prefix}HomeScore", ev.get('home_score', '0'))
            win.setProperty(f"{prefix}AwayLogo", ev.get('away_logo', ''))
            win.setProperty(f"{prefix}HomeLogo", ev.get('home_logo', ''))
            win.setProperty(f"{prefix}SearchTerms", ev.get('search_terms', ''))

            # Quick status color for skin: Red for IN (live), Gray for POST, Gold for PRE
            state = ev.get('state')
            if state == 'IN':
                color = "crimson"
                badge = "[B][COLOR crimson]● LIVE[/COLOR][/B]"
            elif state == 'POST':
                color = "dimgray"
                badge = "[COLOR gray]FINAL[/COLOR]"
            else:
                color = "gold"
                badge = f"[COLOR gold]{ev.get('clock')}[/COLOR]"
            win.setProperty(f"{prefix}Badge", badge)
            win.setProperty(f"{prefix}Color", color)

        # Clear remaining unused slots up to 8
        for i in range(len(events) + 1, 9):
            prefix = f"AntiVenom.GameDay.{league}.{i}."
            win.clearProperty(f"{prefix}Active")

    # Set unified NCAA College Football (FBS + FCS) HUD properties
    ncaa_events = list(leagues.get('CFB', [])) + list(leagues.get('CFB_FCS', []))
    if ncaa_events:
        order = {'IN': 0, 'PRE': 1, 'POST': 2}
        ncaa_sorted = sorted(ncaa_events, key=lambda ev: order.get(ev.get('state'), 9))
        ncaa_live_count = sum(1 for e in ncaa_events if e.get('state') == 'IN')
        win.setProperty("AntiVenom.GameDay.NCAA.HasLive", "true" if ncaa_live_count > 0 else "")
        win.setProperty("AntiVenom.GameDay.NCAA.LiveCount", str(ncaa_live_count))
        for i, ev in enumerate(ncaa_sorted[:8], start=1):
            prefix = f"AntiVenom.GameDay.NCAA.{i}."
            win.setProperty(f"{prefix}Score", ev.get('score', ''))
            win.setProperty(f"{prefix}Clock", ev.get('clock', ''))
            win.setProperty(f"{prefix}Matchup", ev.get('name', ''))

    # Set unified Hockey (NHL + NCAA College Hockey) HUD properties
    hockey_events = list(leagues.get('NHL', [])) + list(leagues.get('NCAA_HOCKEY', []))
    if hockey_events:
        order = {'IN': 0, 'PRE': 1, 'POST': 2}
        hockey_sorted = sorted(hockey_events, key=lambda ev: order.get(ev.get('state'), 9))
        hockey_live_count = sum(1 for e in hockey_events if e.get('state') == 'IN')
        win.setProperty("AntiVenom.GameDay.HOCKEY.HasLive", "true" if hockey_live_count > 0 else "")
        win.setProperty("AntiVenom.GameDay.HOCKEY.LiveCount", str(hockey_live_count))
        for i, ev in enumerate(hockey_sorted[:8], start=1):
            prefix = f"AntiVenom.GameDay.HOCKEY.{i}."
            win.setProperty(f"{prefix}Score", ev.get('score', ''))
            win.setProperty(f"{prefix}Clock", ev.get('clock', ''))
            win.setProperty(f"{prefix}Matchup", ev.get('name', ''))

def find_best_game_match(query: str) -> Optional[Dict[str, Any]]:
    """Matches a scraper sports title or query against the latest live scores cache."""
    cache_file = get_cache_path()
    if not os.path.exists(cache_file):
        return None

    try:
        with open(cache_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        return None

    q_lower = query.lower()
    best_match = None
    max_score = 0

    leagues = data.get('leagues', {})
    for league, events in leagues.items():
        for ev in events:
            # Check team names in query
            terms = [
                ev.get('away_name', '').lower(),
                ev.get('home_name', '').lower(),
                ev.get('away_abbr', '').lower(),
                ev.get('home_abbr', '').lower()
            ]
            matches = sum(1 for t in terms if t and t in q_lower)
            if matches >= 2 and matches > max_score:
                max_score = matches
                best_match = ev

    return best_match
