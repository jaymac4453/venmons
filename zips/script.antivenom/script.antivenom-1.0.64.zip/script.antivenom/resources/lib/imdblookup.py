# -*- coding: utf-8 -*-
"""Find the IMDb id for a title when a play link has none (or a bad one).

Multi-tiered metadata resolver:
1. TMDb ID direct lookup (/movie/{id} or /tv/{id}/external_ids) — fast, 100% accurate.
2. Cinemeta catalog search — Stremio primary index.
3. TMDb title/year search (/search/movie or /search/tv) — resilient fallback when Cinemeta times out or misses.
4. TVMaze search (TV shows) — zero-auth public index.
"""
import json
import os
import re
import time
import urllib.parse
import urllib.request

import xbmc
import xbmcvfs

CINEMETA_SEARCH = 'https://v3-cinemeta.strem.io/catalog/{kind}/top/search={query}.json'
TMDB_KEY = '0049795edb57568b95240bc9e61a9dfc'
TMDB_API = 'https://api.themoviedb.org/3'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
TIMEOUT = 3.0
MAX_ENTRIES = 300
MISS_TTL = 12 * 3600
_IMDB_RE = re.compile(r'^tt\d{6,10}$')


def _log(msg):
    xbmc.log(f'[AntiVenom IMDb] {msg}', xbmc.LOGINFO)


def clean(imdb):
    """Return a well-formed IMDb id or '' (The Crew sends '0' when it has none)."""
    imdb = (imdb or '').strip().lower()
    return imdb if _IMDB_RE.match(imdb) else ''


def _year(value):
    m = re.search(r'(19|20)\d{2}', str(value or ''))
    return int(m.group(0)) if m else 0


def _norm(name):
    name = re.sub(r'\[/?[^\]]*\]', '', name or '')
    name = name.lower().replace('&', ' and ')
    name = re.sub(r'\(\s*(19|20)\d{2}\s*\)', ' ', name)
    name = re.sub(r'[^a-z0-9]+', ' ', name).strip()
    if name.startswith('the '):
        name = name[4:]
    return name


def _cache_path():
    return xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/imdb_lookup.json')


def _load():
    try:
        with open(_cache_path(), 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _store(key, imdb):
    path = _cache_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        data = _load()
        data[key] = {'imdb': imdb, 'ts': int(time.time())}
        if len(data) > MAX_ENTRIES:
            ranked = sorted(data.items(), key=lambda item: (item[1] or {}).get('ts') or 0)
            data = dict(ranked[-MAX_ENTRIES:])
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
        os.replace(tmp, path)
    except Exception as exc:
        _log('cache write failed: %s' % exc)


def _pick(metas, title, year, kind):
    want = _norm(title)
    best, best_score = '', 0
    for rank, meta in enumerate(metas[:15]):
        imdb = clean(meta.get('imdb_id') or meta.get('id'))
        if not imdb:
            continue
        name = _norm(meta.get('name'))
        if name == want:
            score = 100
        elif want and name and (name.startswith(want + ' ') or want.startswith(name + ' ')):
            score = 40
        else:
            continue
        found_year = _year(meta.get('releaseInfo') or meta.get('year'))
        if year:
            if not found_year:
                continue
            # A show's "year" on an episode link can be a later season's year.
            if kind == 'series':
                if found_year > year + 1:
                    continue
            elif abs(found_year - year) > 1:
                continue
            score += 50 if found_year == year else 25
        elif score < 100:
            continue
        score -= rank
        if score > best_score:
            best, best_score = imdb, score
    return best


def resolve_from_tmdb(tmdb_id, kind='movie'):
    """Resolve IMDb id directly from TMDb ID in <100ms."""
    tmdb_str = str(tmdb_id or '').strip()
    if not tmdb_str.isdigit():
        return ''
    kind = 'series' if kind in ('series', 'tv', 'tvshow', 'show', 'episode') else 'movie'
    cache_key = f'tmdb|{kind}|{tmdb_str}'
    row = _load().get(cache_key)
    if row and row.get('imdb'):
        return row['imdb']

    endpoints = [
        f'{TMDB_API}/tv/{tmdb_str}/external_ids?api_key={TMDB_KEY}' if kind == 'series' else f'{TMDB_API}/movie/{tmdb_str}?api_key={TMDB_KEY}',
        f'{TMDB_API}/movie/{tmdb_str}?api_key={TMDB_KEY}' if kind == 'series' else f'{TMDB_API}/tv/{tmdb_str}/external_ids?api_key={TMDB_KEY}'
    ]
    for url in endpoints:
        try:
            req = urllib.request.Request(url, headers={'User-Agent': UA})
            with urllib.request.urlopen(req, timeout=3.0) as resp:
                data = json.loads(resp.read().decode('utf-8', errors='replace') or '{}')
                imdb = clean(data.get('imdb_id'))
                if imdb:
                    _store(cache_key, imdb)
                    return imdb
        except Exception:
            continue
    return ''


def search_tmdb(query, year=None, kind='movie'):
    """Resilient fallback search via TMDb API when Cinemeta is down or times out."""
    kind = 'series' if kind in ('series', 'tv', 'tvshow', 'show', 'episode') else 'movie'
    path = 'tv' if kind == 'series' else 'movie'
    url = f'{TMDB_API}/search/{path}?api_key={TMDB_KEY}&query={urllib.parse.quote_plus(query)}'
    if year:
        url += f'&first_air_date_year={year}' if kind == 'series' else f'&year={year}'
    try:
        req = urllib.request.Request(url, headers={'User-Agent': UA})
        with urllib.request.urlopen(req, timeout=3.5) as resp:
            data = json.loads(resp.read().decode('utf-8', errors='replace') or '{}')
            results = data.get('results') or []
            want = _norm(query)
            for r in results[:5]:
                name = _norm(r.get('title') if kind == 'movie' else r.get('name'))
                if name == want or (want and (name.startswith(want + ' ') or want.startswith(name + ' '))):
                    r_id = r.get('id')
                    imdb = resolve_from_tmdb(r_id, kind)
                    if imdb:
                        return imdb
    except Exception as exc:
        _log('TMDb search failed for %s: %s' % (query, exc))
    return ''


def search_tvmaze(query):
    """Free public TV metadata index fallback."""
    try:
        url = f'https://api.tvmaze.com/singlesearch/shows?q={urllib.parse.quote_plus(query)}'
        req = urllib.request.Request(url, headers={'User-Agent': UA})
        with urllib.request.urlopen(req, timeout=3.0) as resp:
            data = json.loads(resp.read().decode('utf-8', errors='replace') or '{}')
            return clean(data.get('externals', {}).get('imdb'))
    except Exception:
        return ''


def resolve(title, year=None, kind='movie', tmdb=None):
    """Best-matching IMDb id for title (+year), or '' when unsure.

    Multi-tiered fallback hierarchy:
    1. Direct TMDb ID resolution (instant, 100% precision)
    2. Cinemeta catalog search
    3. TMDb title/year search
    4. TVMaze API (for series)
    """
    kind = 'series' if kind in ('series', 'tv', 'tvshow', 'show', 'episode') else 'movie'
    query = re.sub(r'\[/?[^\]]*\]', '', title or '')
    query = re.sub(r'\s*\(\s*(19|20)\d{2}\s*\)\s*$', '', query).strip()
    if not query and not tmdb:
        return ''

    # Tier 0: Direct TMDb ID lookup if available (Always priority 1, bypasses title cache misses)
    if tmdb:
        imdb = resolve_from_tmdb(tmdb, kind)
        if imdb:
            _log('%s "%s" (TMDb: %s) -> %s (via direct TMDb)' % (kind, query, tmdb, imdb))
            if query:
                yr = _year(year)
                _store('%s|%s|%s' % (kind, _norm(query), yr or ''), imdb)
            return imdb

    yr = _year(year)
    key = '%s|%s|%s' % (kind, _norm(query), yr or '')
    row = _load().get(key)
    if row:
        cached = row.get('imdb') or ''
        if cached:
            return cached
        # Brief 5-minute negative cache to prevent rapid loops while allowing recovery
        if (time.time() - (row.get('ts') or 0)) < 300:
            return ''

    # Tier 1: Cinemeta search (primary catalog)
    imdb = ''
    if query:
        url = CINEMETA_SEARCH.format(kind=kind, query=urllib.parse.quote(query, safe=''))
        try:
            req = urllib.request.Request(url, headers={'User-Agent': UA})
            with urllib.request.urlopen(req, timeout=3.0) as resp:
                payload = json.loads(resp.read().decode('utf-8', errors='replace') or '{}')
                imdb = _pick(payload.get('metas') or [], query, yr, kind)
                if imdb:
                    _log('%s "%s" (%s) -> %s (via Cinemeta)' % (kind, query, yr or '?', imdb))
                    _store(key, imdb)
                    return imdb
        except Exception as exc:
            _log('Cinemeta lookup failed for %s: %s; initiating resilient fallbacks' % (query, exc))

    # Tier 2: TMDb Search fallback
    if query:
        imdb = search_tmdb(query, yr, kind)
        if imdb:
            _log('%s "%s" (%s) -> %s (via TMDb Search)' % (kind, query, yr or '?', imdb))
            _store(key, imdb)
            return imdb

    # Tier 3: TVMaze Search fallback for TV shows
    if kind == 'series' and query:
        imdb = search_tvmaze(query)
        if imdb:
            _log('%s "%s" -> %s (via TVMaze)' % (kind, query, imdb))
            _store(key, imdb)
            return imdb

    _log('%s "%s" (%s) -> no match across all resolvers' % (kind, query, yr or '?'))
    _store(key, '')
    return ''
