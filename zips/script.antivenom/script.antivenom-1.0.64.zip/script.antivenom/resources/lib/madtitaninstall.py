# -*- coding: utf-8 -*-
"""Install Mad Titan Sports (plugin.video.madtitansports) from the Magnetic repo.

Same direct-zip method as crewinstall: repository.Magnetic is extracted first, its
<dir> datadirs plus Kodi's own repo are indexed, and Mad Titan's required
dependencies are downloaded and enabled in order. Only sports use Mad Titan.
"""
import re

import xbmc

from resources.lib import crewinstall

MT_PLUGIN = 'plugin.video.madtitansports'
MAGNETIC_REPO_ID = 'repository.Magnetic'
MAGNETIC_REPO_PAGE = 'https://magnetic.website/repo/'
MAGNETIC_REPO_ZIP = MAGNETIC_REPO_PAGE + 'repository.Magnetic-1.1.0b.zip'
MAGNETIC_SOURCES = [
    ('https://magnetic.website/__zips/addons.xml', 'https://magnetic.website/__zips'),
    ('https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml',
     'https://raw.githubusercontent.com/Gujal00/smrzips/master/zips'),
]


def _log(msg):
    xbmc.log(f'[AntiVenom MadTitanInstall] {msg}', xbmc.LOGINFO)


def is_installed():
    return bool(xbmc.getCondVisibility(f'System.HasAddon({MT_PLUGIN})'))


def _repo_zip_url():
    """Newest repository.Magnetic zip listed on the repo page; the pinned one if the page is down."""
    try:
        page = crewinstall._get(MAGNETIC_REPO_PAGE, timeout=20, tries=2).decode('utf-8', 'ignore')
        names = re.findall(r'href="(repository\.Magnetic-[^"/]+\.zip)"', page)
        if names:
            names.sort(key=lambda n: crewinstall.version_tuple(n[len('repository.Magnetic-'):-4]))
            return MAGNETIC_REPO_PAGE + names[-1]
    except Exception as e:
        _log(f'repo page unavailable: {e}')
    return MAGNETIC_REPO_ZIP


def install_madtitan(progress=None):
    """Returns (ok, message) like crewinstall.install_addons."""
    repo = (MAGNETIC_REPO_ID, _repo_zip_url(), MAGNETIC_SOURCES, 'the Magnetic repository')
    return crewinstall.install_addons((MT_PLUGIN,), progress=progress, repo=repo)
