# -*- coding: utf-8 -*-
"""
Playback fallback for AntiVenom Fast Mode.

Resolve-time retries: The Crew sourcesDirect (select=2) already walks
smart_resolve when a link fails to resolve — AntiVenom does NOT duplicate that.

Playback fail chain (Fast Mode ON, all automatic):
  1. Auto-play best stream (select=2)
  2. playItem index 1 (backup 1)
  3. playItem index 2 (backup 2)
  4. playItem index 3 (backup 3)
  5. Only after all four fail: normal no-stream notification (no source list)

Important: Crew+Classy still loads ~30 internal scraper modules in its progress UI.
Fast Mode disables extra packs (Gears/Coco/Viper/Magneto); the count is not pack count.
"""
import json
import time
import urllib.parse

import xbmc
import xbmcgui

CONTAINER_ITEMS = 'plugin.video.thecrew.container.items'
SMART_RESOLVE_PROP = 'thecrew.smart_resolve.active'
MAX_PLAY_TRIES = 4
# Progress, Crew overlay, resolve status, yes/no during play route
CREW_BUSY_DIALOGS = (10101, 10138, 12000, 12002, 10100, 13002)
MAX_CREW_WAIT_SECONDS = 180
CREW_IDLE_SECONDS = 4
MIN_PLAY_SECONDS = 8
EARLY_FAIL_SECONDS = 12


def _log(msg):
    xbmc.log(f'[AntiVenom PlayFallback] {msg}', xbmc.LOGINFO)


def _home_property(name):
    try:
        return xbmcgui.Window(10000).getProperty(name) or ''
    except Exception:
        return ''


def container_item_count():
    raw = _home_property(CONTAINER_ITEMS)
    if not raw:
        return 0
    try:
        data = json.loads(raw)
        return len(data) if isinstance(data, list) else 0
    except Exception:
        return 0


def _current_dialog_id():
    try:
        return int(xbmcgui.getCurrentWindowDialogId())
    except Exception:
        return 0


def _is_crew_busy():
    if _home_property(SMART_RESOLVE_PROP) == 'true':
        return True
    if _current_dialog_id() in CREW_BUSY_DIALOGS:
        return True
    return False


def _playback_sustained():
    player = xbmc.Player()
    if not player.isPlayingVideo():
        return False

    started = time.time()
    while time.time() - started < MIN_PLAY_SECONDS:
        if not player.isPlayingVideo():
            elapsed = time.time() - started
            if elapsed < EARLY_FAIL_SECONDS:
                _log(f'playback stopped early after {elapsed:.1f}s')
            return False
        xbmc.sleep(500)
    return True


def _wait_for_play_or_finish():
    """Wait until video sustains OR Crew fully finishes without playback."""
    deadline = time.time() + MAX_CREW_WAIT_SECONDS
    idle_since = None

    while time.time() < deadline:
        if xbmc.Player().isPlayingVideo():
            if _playback_sustained():
                return 'playing'

        if _is_crew_busy():
            idle_since = None
        else:
            if idle_since is None:
                idle_since = time.time()
            elif time.time() - idle_since >= CREW_IDLE_SECONDS:
                if xbmc.Player().isPlayingVideo() and _playback_sustained():
                    return 'playing'
                return 'failed'

        xbmc.sleep(500)

    if xbmc.Player().isPlayingVideo() and _playback_sustained():
        return 'playing'
    if _is_crew_busy():
        _log('crew still busy at wait timeout; treating attempt as failed')
    return 'timeout'


def _stop_playback_if_idle():
    if _is_crew_busy():
        _log('crew still busy; not stopping in-flight resolve')
        return
    try:
        if xbmc.Player().isPlaying():
            xbmc.executebuiltin('PlayerControl(Stop)')
    except Exception:
        pass
    xbmc.sleep(400)


def _attempt_play(play_url, title, attempt_no):
    _log(f'attempt {attempt_no}/{MAX_PLAY_TRIES} {title}: {play_url}')
    safe_url = play_url.replace('\\', '\\\\').replace('"', '\\"')
    xbmc.executebuiltin('PlayMedia("%s")' % safe_url)
    result = _wait_for_play_or_finish()
    if result == 'playing':
        _log(f'attempt {attempt_no} sustained playback for {title}')
        return True
    _log(f'attempt {attempt_no} finished without playback ({result}, crew_busy={_is_crew_busy()})')
    _stop_playback_if_idle()
    return False


def _playitem_url(title, index):
    encoded = urllib.parse.quote_plus(title or '')
    return (
        f'plugin://plugin.video.thecrew/?action=playItem'
        f'&title={encoded}&index={index}'
    )


def _show_no_stream(title):
    if xbmc.Player().isPlayingVideo():
        _log('suppress no-stream notification; playback is active')
        return
    xbmcgui.Dialog().notification(
        'AntiVenom',
        f'No stream available for {title} after {MAX_PLAY_TRIES} automatic tries.',
        xbmcgui.NOTIFICATION_ERROR,
        5000,
    )


def play_with_fallback(play_url, title):
    """Try primary autoplay then three playItem backups. Returns True if playback sustained."""
    if _attempt_play(play_url, title, 1):
        return True

    count = container_item_count()
    _log(f'container sources available for backups: {count}')

    for backup_no, idx in enumerate(range(1, MAX_PLAY_TRIES), start=2):
        if idx >= count:
            _log(f'skipping backup {backup_no - 1}: only {count} scraped sources')
            continue
        if _attempt_play(_playitem_url(title, idx), title, backup_no):
            return True

    if xbmc.Player().isPlayingVideo() and _playback_sustained():
        _log('playback started during backup phase; suppressing failure')
        return True

    _log(f'all {MAX_PLAY_TRIES} automatic playback attempts failed for {title}')
    _show_no_stream(title)
    return False
