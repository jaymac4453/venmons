# -*- coding: utf-8 -*-
"""Real-Debrid cached play (kept for older call sites).

The work now lives in debridengine: Torrentio cached list for the user's key,
Comet backup, learned memory, and Real-Debrid's own downloaded check.
"""
from .debridengine import (  # noqa: F401
    find_and_play,
    learn_key as _learn_key,
    offer_download,
    recall,
    remember,
    token as _token,
    try_play,
)
