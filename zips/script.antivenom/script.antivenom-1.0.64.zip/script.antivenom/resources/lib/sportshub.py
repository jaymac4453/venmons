# -*- coding: utf-8 -*-
"""AntiVenom Sports: Live games, College, Pros, Replay games.

Primary live streaming engine is powered by The Crew (plugin.video.thecrew).
Scores, schedules and live team stats are synced from GameDay HUD.
Mad Titan Sports serves solely as an optional secondary backup when installed.
"""
import base64
import datetime
import json
import os
import re
import sys
import threading
import time
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

BASE = 'plugin://script.antivenom/'
CREW_ID = 'plugin.video.thecrew'
CREW = 'plugin://' + CREW_ID + '/'
CREW_HOP = CREW + '?action=bluehat'
ART = 'special://home/addons/script.thecrew.artwork/resources/'

# The Crew sports action map
CREW_ACTIONS = {
    'ncaa': 'ncaa',
    'ncaab': 'ncaab',
    'nhl': 'nhl',
    'nfl': 'nfl',
    'nba': 'nba',
    'wnba': 'nba',
    'mlb': 'mlb',
    'ufc': 'ufc',
    'boxing': 'boxing',
    'fifa': 'fifa',
    'wwe': 'wwe',
    'f1': 'f1',
    'nascar': 'nascar',
    'motogp': 'motogp',
    'tennis': 'tennis',
    'pga': 'pga',
    'ppv': 'ufc',
    'channels': 'sports_channels',
    'replay': 'sreplays',
    'all': 'bluehat',
}

# Optional Mad Titan fallback definitions
MT_ID = 'plugin.video.madtitansports'
MT = 'plugin://' + MT_ID
MAGNETIC = 'https://magnetic.website'
MT_LEAGUE = MAGNETIC + '/MAD_TITAN_SPORTS/SPORTS/LEAGUE/titansports_{}.json'
MT_ALL_LIVE = MAGNETIC + '/MAD_TITAN_SPORTS/SPORTS/sports.json'
MT_NETWORKS = MAGNETIC + '/jet/TVGUIDE/TVGUIDE_Sports Networks.json'
MT_REPLAY_DEBRID = MAGNETIC + '/MAD_TITAN_SPORTS/SPORTS/DIRECTREPLAY/DEBRID/1debrid.json'

# key, label, description, fanart name (script.thecrew.artwork/resources/fanart/<name>_fanart.jpg)
MENU = (
    ('live', 'Live games', 'Games on right now, plus 24/7 sports channels', 'sports'),
    ('college', 'College Sports', 'College football (FBS & FCS), basketball, baseball', 'ncaa'),
    ('pros', 'Pro Sports', 'NFL, NBA, MLB, NHL, Soccer, UFC, Boxing, Racing and more', 'nfl'),
    ('thecrew', 'The Crew Sports Center', 'The Crew\'s full sports hub with all scrapers & channels', 'sports'),
    ('channels', 'Sports TV Networks', '24/7 Live Sports Channels (ESPN, FOX, NBC, CBS, NHL Network)', 'sports'),
    ('replay', 'Replay games', 'Full replays of fights, games and races', 'boxing'),
)
FANART_NAME = {'wwe': 'wwe_raw'}

# key -> (name, icon/fanart name)
LEAGUES = {
    'ncaa': ('College Football', 'ncaa'),
    'ncaab': ('College Basketball', 'ncaab'),
    'nfl': ('NFL Football', 'nfl'),
    'nba': ('NBA Basketball', 'nba'),
    'wnba': ('WNBA Basketball', 'nba'),
    'mlb': ('MLB Baseball', 'mlb'),
    'nhl': ('NHL Hockey', 'nhl'),
    'fifa': ('Soccer', 'fifa'),
    'ufc': ('UFC / MMA', 'ufc'),
    'boxing': ('Boxing', 'boxing'),
    'wwe': ('WWE Wrestling', 'wwe'),
    'f1': ('Formula 1', 'f1'),
    'nascar': ('NASCAR', 'nascar'),
    'motogp': ('MotoGP', 'motogp'),
    'tennis': ('Tennis', 'tennis'),
    'pga': ('Golf', 'pga'),
    'ppv': ('Live PPV Events', 'boxing'),
}
COLLEGE = ('ncaa', 'ncaab')
PROS = ('nfl', 'nba', 'wnba', 'mlb', 'nhl', 'fifa', 'ufc', 'boxing', 'wwe', 'f1', 'nascar', 'motogp', 'tennis', 'pga', 'ppv')

# Mad Titan fallback mapping if installed
MT_LIVE = {
    'ncaa': 'ncaaf', 'ncaab': 'ncaab', 'nfl': 'nfl', 'nba': 'nba', 'wnba': 'nba',
    'mlb': 'mlb', 'nhl': 'nhl', 'fifa': 'soccer', 'ufc': 'ufc', 'boxing': 'boxing',
    'wwe': 'wrestling', 'f1': 'motorsport', 'nascar': 'motorsport', 'motogp': 'motorsport',
    'tennis': 'tennis', 'pga': 'golf', 'ppv': 'ppv',
}
MT_PROS = dict(MT_LIVE, fifa='england_soccer')
MT_COLLEGE = {'nfl': 'ncaaf', 'ncaa': 'ncaaf', 'nba': 'ncaab', 'ncaab': 'ncaab', 'mlb': 'ncaa_baseball', 'nhl': 'ice_hockey'}
_PRO_FOR = {'ncaa': 'nfl', 'ncaab': 'nba'}

MT_REPLAY = {
    'nfl': 'NflVideo', 'nba': 'BasketballReplays', 'ncaab': 'CollegeBasketball Replays',
    'nhl': 'NhlVideo', 'fifa': 'SoccerFullMatch', 'ufc': 'FullFightReplays',
    'boxing': 'FullFightReplays', 'wwe': 'WatchProWrestling',
    'f1': 'Fullraces', 'nascar': 'Fullraces', 'motogp': 'Fullraces',
}
REPLAY_MENU = (
    ('NFL replays', 'NflVideo', 'nfl', 'Full NFL games'),
    ('NBA replays', 'BasketballReplays', 'nba', 'Full NBA games'),
    ('College Basketball replays', 'CollegeBasketball Replays', 'ncaab', 'Full college basketball games'),
    ('NHL replays', 'NhlVideo', 'nhl', 'Full NHL games'),
    ('Soccer replays', 'SoccerFullMatch', 'fifa', 'Full soccer matches'),
    ('Fight replays (UFC, boxing)', 'FullFightReplays', 'ufc', 'Full UFC, MMA and boxing cards'),
    ('Racing replays (F1, NASCAR, MotoGP)', 'Fullraces', 'f1', 'Full races'),
    ('Wrestling replays', 'WatchProWrestling', 'wwe', 'WWE and AEW shows'),
    ('All full replays', 'FullReplays', 'sports', 'Every full replay listed'),
    ('Sports on demand', 'SportsVideo', 'sports', 'Recent games from many sports'),
    ('Replay Rewind (Real-Debrid)', None, 'boxing', 'Direct replays. A debrid account may be needed.'),
)

# Older skin buttons / GameDay leagues -> league key
ALIASES = {'cfb': 'ncaa', 'college_football': 'ncaa', 'ncaaf': 'ncaa', 'cfb_fcs': 'ncaa', 'CFB_FCS': 'ncaa',
           'college_basketball': 'ncaab',
           'epl': 'fifa', 'soccer': 'fifa', 'ucl': 'fifa', 'mls': 'fifa',
           'mma': 'ufc', 'golf': 'pga', 'CFB': 'ncaa', 'EPL': 'fifa', 'UCL': 'fifa', 'MLS': 'fifa',
           'boxing': 'boxing', 'BOXING': 'boxing', 'wnba': 'wnba', 'WNBA': 'wnba', 'ppv': 'ppv', 'PPV': 'ppv',
           'nhl': 'nhl', 'NHL': 'nhl', 'hockey': 'nhl', 'ice_hockey': 'nhl', 'ncaa_hockey': 'nhl', 'NCAA_HOCKEY': 'nhl'}


def log(msg):
    xbmc.log(f'[AntiVenom Sports] {msg}', xbmc.LOGINFO)


def league_key(sport):
    s = (sport or '').strip()
    s = ALIASES.get(s, ALIASES.get(s.lower(), s.lower()))
    return s if s in LEAGUES else ''


def crew_sport_url(sport_key):
    """Direct URL to The Crew's live sports scraper.

    NFL is the game list (one row per game). The Crew NFL page is thirty
    copies of the same live tile, so it is not used.
    """
    key = league_key(sport_key) or sport_key
    if key == 'nfl':
        return plugin_url(action='sports_league', key='nfl')
    action = CREW_ACTIONS.get(key, 'bluehat')
    return f'{CREW}?action={action}'


def plugin_url(**params):
    return BASE + '?' + urllib.parse.urlencode(params)


def mt_list(json_url):
    return f'{MT}/get_list/{json_url}'


def mt_league(file_key):
    return mt_list(MT_LEAGUE.format(file_key))


def mt_replay(site):
    return f'{MT}/sportjetextractors/games/{site}' if site else mt_list(MT_REPLAY_DEBRID)


def madtitan_ready():
    return bool(xbmc.getCondVisibility(f'System.HasAddon({MT_ID})'))


def crew_ready():
    return bool(xbmc.getCondVisibility(f'System.HasAddon({CREW_ID})'))


def _fanart(name):
    return f'{ART}fanart/{FANART_NAME.get(name, name)}_fanart.jpg'


def _art(name):
    img = _fanart(name)
    return {'thumb': img, 'poster': img, 'icon': img, 'fanart': img}


def _with_poster(art):
    if not art:
        return art
    art = dict(art)
    poster = art.get('poster') or art.get('fanart') or art.get('thumb')
    if poster:
        art['poster'] = poster
        art.setdefault('thumb', poster)
        art.setdefault('fanart', poster)
    return art


def _folder(label, url, art=None, plot='', label2=''):
    li = xbmcgui.ListItem(label=label, label2=label2, offscreen=True)
    art = _with_poster(art)
    if art:
        li.setArt(art)
    li.setInfo('video', {'title': label, 'plot': plot or label, 'mediatype': 'movie'})
    return (url, li, True)


def _finish(handle, entries, ok=True):
    if entries:
        xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.setContent(handle, 'movies')
    xbmcplugin.endOfDirectory(handle, succeeded=ok, cacheToDisc=False)
    xbmc.executebuiltin('Container.SetViewMode(500)')
    xbmc.executebuiltin('AlarmClock(AntiVenomWallView,Container.SetViewMode(500),00:01,silent)')


# ── Directory levels ───────────────────────────────────────────

def render_menu(handle):
    entries = []
    for key, label, plot, art in MENU:
        if key == 'thecrew':
            url = f'{CREW}?action=bluehat'
        elif key == 'channels':
            url = f'{CREW}?action=sports_channels'
        else:
            url = plugin_url(action='sports_bucket', bucket=key)
        entries.append(_folder(label, url, _art(art), plot))
    _finish(handle, entries)


# Every sport on the Live list, whether or not a game is in progress right now.
LIVE_SPORTS = (
    'ppv', 'nfl', 'ncaa', 'nba', 'wnba', 'ncaab', 'mlb', 'nhl', 'fifa', 'ufc',
    'boxing', 'f1', 'nascar', 'wwe', 'tennis', 'pga', 'motogp',
)


def _games_by_sport():
    try:
        from resources.lib.gameday import refresh_all_scores
        data = refresh_all_scores(force=True) or {}
    except Exception as e:
        log(f'GameDay unavailable: {e}')
        return {}
    found = {}
    for league, events in (data.get('leagues') or {}).items():
        key = league_key(league)
        if key:
            found.setdefault(key, []).extend(events or [])
    return found


def render_bucket(handle, bucket):
    entries = []
    if bucket == 'live':
        by_sport = _games_by_sport()
        for key in LIVE_SPORTS:
            name, art_name = LEAGUES[key]
            events = by_sport.get(key) or []
            live_n = sum(1 for ev in events if ev.get('state') == 'IN')
            if live_n:
                label2 = f'{live_n} live now · {len(events)} today'
            elif events:
                label2 = f'{len(events)} today'
            else:
                label2 = 'No games on the board today'
            entries.append(_folder(
                name,
                plugin_url(action='sports_games', key=key),
                _art(art_name),
                f'{name}. Open it for today\'s games and The Crew streams.',
                label2,
            ))
        entries.append(_folder('The Crew Sports Center', f'{CREW}?action=bluehat', _art('sports'),
                               'The Crew\'s full sports hub: NFL, NHL, NBA, MLB, NCAA, UFC, FIFA & more'))
        entries.append(_folder('Sports TV channels (ESPN, FOX, NBC...)', f'{CREW}?action=sports_channels',
                               _art('sports'), '24/7 live sports networks'))
    elif bucket == 'replay':
        entries.append(_folder('The Crew Sports Replays', f'{CREW}?action=sreplays', _art('boxing'),
                               'Full match and event replays from The Crew'))
        for label, site, art_name, plot in REPLAY_MENU:
            if site and madtitan_ready():
                entries.append(_folder(label, mt_replay(site), _art(art_name), plot))
    elif bucket == 'college':
        entries.append(_folder('NCAA College Football', plugin_url(action='sports_league', key='ncaa'), _art('ncaa'),
                               'College Football live schedule, direct streams & channels'))
        entries.append(_folder('NCAA College Basketball', plugin_url(action='sports_league', key='ncaab'), _art('ncaab'),
                               'College Basketball live schedule, direct streams & channels'))
        entries.append(_folder('College Sports Networks (ESPNU, SEC, ACC, Big Ten)', f'{CREW}?action=sports_channels',
                               _art('ncaa'), '24/7 Live College Sports Channels'))
        if madtitan_ready():
            entries.append(_folder('College Baseball (Mad Titan Backup)', mt_league('ncaa_baseball'), _art('mlb'),
                                   'College baseball and softball'))
            entries.append(_folder('College Ice Hockey (Mad Titan Backup)', mt_league('ice_hockey'), _art('nhl'),
                                   'NCAA & World ice hockey'))
    else:
        for key in PROS:
            name, art_name = LEAGUES[key]
            url = plugin_url(action='sports_league', key=key)
            entries.append(_folder(name, url, _art(art_name), f'{name} live games and streams'))
    _finish(handle, entries)


# ESPN scoreboard key used by gameday.py. Supports multi-league boards (e.g., EPL, UCL, MLS for soccer).
_SCOREBOARD = {
    'nba': ['NBA'], 'wnba': ['WNBA'], 'nfl': ['NFL'], 'mlb': ['MLB'],
    'nhl': ['NHL', 'NCAA_HOCKEY'],
    'fifa': ['EPL', 'UCL', 'MLS'],
    'ncaa': ['CFB', 'CFB_FCS'],
    'ncaab': ['NCAAB'],
    'ufc': ['UFC'], 'boxing': ['BOXING'], 'f1': ['F1'], 'nascar': ['NASCAR'],
    'pga': ['PGA'], 'tennis': ['TENNIS'],
}


def render_games(handle, key):
    """Clean, simplified sports hub for any league: live games, direct feeds, 24/7 channels, replays."""
    key = league_key(key)
    if not key:
        return _finish(handle, [], ok=False)
    if key == 'nfl':
        return render_nfl(handle)

    name, art_name = LEAGUES.get(key, ('Sports', 'sports'))
    art = _art(art_name)
    crew_target = crew_sport_url(key)
    mt_key = MT_LIVE.get(key)
    has_mt = madtitan_ready() and bool(mt_key)
    primary_stream_url = mt_league(mt_key) if has_mt else crew_target

    games = []
    boards = _SCOREBOARD.get(key, [])
    if isinstance(boards, str):
        boards = [boards]
    if boards:
        try:
            from resources.lib.gameday import LEAGUE_ENDPOINTS, fetch_league_scoreboard
            for board in boards:
                url = LEAGUE_ENDPOINTS.get(board)
                if url:
                    fetched = fetch_league_scoreboard(board, url) or []
                    games.extend(fetched)
        except Exception as e:
            log(f'scoreboard failed for {key}: {e}')

    if not games and boards:
        try:
            from resources.lib.gameday import _load_cache
            cached = _load_cache() or {}
            cached_leagues = cached.get('leagues') or {}
            for board in boards:
                cached_games = cached_leagues.get(board) or []
                if cached_games:
                    games.extend(cached_games)
        except Exception as e:
            log(f'cached scoreboard lookup failed for {key}: {e}')

    if not games and has_mt:
        try:
            mt_items = _fetch_mt_items(key)
            for it in mt_items:
                if not isinstance(it, dict):
                    continue
                links = it.get('link') or []
                if isinstance(links, str):
                    links = [links]
                if len(links) < 2:
                    continue
                raw_title = it.get('title') or ''
                clean_title = _COLOR_TAGS.sub('', raw_title)
                clean_title = re.sub(r'[^\x00-\x7F]+', ' ', clean_title).strip()
                low_title = clean_title.lower()
                if 'refresh' in low_title or 'previous search' in low_title or 'scoreboard' in low_title or not clean_title:
                    continue
                matchup_text = clean_title
                if '|' in matchup_text:
                    matchup_text = matchup_text.split('|')[-1].strip()
                games.append({
                    'name': matchup_text,
                    'short_name': matchup_text,
                    'state': 'IN',
                    'clock': 'LIVE',
                    'score': '',
                    'away_logo': it.get('thumbnail') or '',
                    'home_logo': it.get('thumbnail') or ''
                })
        except Exception as e:
            log(f'MT games fallback failed for {key}: {e}')

    entries = []

    # 1. LIVE GAMES (At the very top if any are in progress - CLICK TO AUTO-PLAY)
    live_games = [g for g in games if str(g.get('state', '')).upper() == 'IN']
    for ev in live_games:
        matchup = ev.get('name') or ev.get('short_name') or name
        score = ev.get('score', '')
        clock = ev.get('clock', '')
        score_txt = f"({score} · {clock})" if score and score != '0 - 0' else f"({clock})"
        label = f"[B][COLOR crimson]● LIVE[/COLOR][/B]  [COLOR white]{matchup}[/COLOR]  [COLOR gold]{score_txt}[/COLOR]"
        game_art = dict(art)
        logo = ev.get('away_logo') or ev.get('home_logo')
        if logo:
            game_art['poster'] = logo
            game_art['thumb'] = logo
        play_url = plugin_url(action='sports_play_universal', sport=key, matchup=matchup)
        url, li, is_folder = _playable(
            label,
            play_url,
            game_art,
            f"Live Now: {matchup}. Click to auto-play the best stream.",
            f"{clock or 'LIVE NOW'}"
        )
        cm = [
            (f'{name} Backup Scrapers (The Crew)', f'ActivateWindow(Videos,{crew_target},return)'),
        ]
        if has_mt:
            cm.append((f'{name} Mad Titan Feeds', f'ActivateWindow(Videos,{primary_stream_url},return)'))
        li.addContextMenuItems(cm)
        entries.append((url, li, is_folder))

    # 2. DIRECT LIVE FEEDS & SCHEDULE (Mad Titan - direct working feeds)
    if has_mt:
        entries.append(_folder(
            f'⚡ [B][COLOR #00F5A0]{name} Live Events & Direct Streams[/COLOR][/B]',
            primary_stream_url,
            art,
            f'Direct schedule and verified working match stream feeds for {name}.',
            'Direct Working Feeds'
        ))

    # 3. 24/7 DEDICATED TV CHANNELS
    if key in ('ufc', 'boxing', 'ppv'):
        entries.append(_folder(
            '📺 [B][COLOR white]24/7 Combat & Fight TV Networks[/COLOR][/B]',
            f'{CREW}?action=sports_channels',
            art,
            '24/7 Live Fight Channels: UFC Fight Pass, ESPN, ESPN2, FS1, Combat GO',
            '24/7 Channels'
        ))
    elif key == 'nhl':
        entries.append(_folder(
            '📺 [B][COLOR white]NHL Network & Live Sports Channels[/COLOR][/B]',
            f'{CREW}?action=sports_channels',
            art,
            '24/7 Live Channels: NHL Network, ESPN, FOX Sports, TSN 1-5',
            '24/7 Channels'
        ))
    elif key in ('nba', 'wnba'):
        entries.append(_folder(
            '📺 [B][COLOR white]NBA TV & Live Basketball Channels[/COLOR][/B]',
            f'{CREW}?action=sports_channels',
            art,
            '24/7 Live Channels: NBA TV, ESPN, TNT, ABC Sports',
            '24/7 Channels'
        ))
    elif key == 'mlb':
        entries.append(_folder(
            '📺 [B][COLOR white]MLB Network & Live Baseball Channels[/COLOR][/B]',
            f'{CREW}?action=sports_channels',
            art,
            '24/7 Live Channels: MLB Network, ESPN, FOX Sports',
            '24/7 Channels'
        ))
    elif key == 'fifa':
        entries.append(_folder(
            '📺 [B][COLOR white]Live Soccer & Sports TV Channels[/COLOR][/B]',
            f'{CREW}?action=sports_channels',
            art,
            '24/7 Live Channels: NBC Sports, FS1, TSN, Sports Networks',
            '24/7 Channels'
        ))
    elif key in ('ncaa', 'ncaab'):
        entries.append(_folder(
            '📺 [B][COLOR white]College Sports Networks (Big Ten, SEC, ACC, ESPNU)[/COLOR][/B]',
            f'{CREW}?action=sports_channels',
            art,
            '24/7 Live College Sports Channels: Big Ten Network, ESPNU, ACC, SEC, FS1',
            '24/7 Channels'
        ))
    elif key in ('f1', 'nascar', 'motogp'):
        entries.append(_folder(
            '📺 [B][COLOR white]Live Racing Networks & Channels[/COLOR][/B]',
            f'{CREW}?action=sports_channels',
            art,
            '24/7 Live Channels: Sky Sports F1, FOX Sports, NBC Sports, Motor Racing',
            '24/7 Channels'
        ))
    else:
        entries.append(_folder(
            '📺 [B][COLOR white]Live Sports TV Channels (ESPN, FOX, NBC, CBS)[/COLOR][/B]',
            f'{CREW}?action=sports_channels',
            art,
            '24/7 Live Sports Networks (ESPN, FOX, NBC, CBS, TSN)',
            '24/7 Channels'
        ))

    # 4. TODAY'S UPCOMING SCHEDULED MATCHUPS (Click to auto-play when game starts)
    pre_games = [g for g in games if str(g.get('state', '')).upper() == 'PRE']
    for ev in pre_games:
        matchup = ev.get('name') or ev.get('short_name') or name
        clock = ev.get('clock') or 'Today'
        label = f"[COLOR gold]{clock}[/COLOR]  [COLOR white]{matchup}[/COLOR]"
        game_art = dict(art)
        logo = ev.get('away_logo') or ev.get('home_logo')
        if logo:
            game_art['poster'] = logo
            game_art['thumb'] = logo
        play_url = plugin_url(action='sports_play_universal', sport=key, matchup=matchup)
        url, li, is_folder = _playable(
            label,
            play_url,
            game_art,
            f"{matchup} scheduled for {clock}. Click to auto-find and play the best stream.",
            f"{clock}"
        )
        cm = [
            (f'{name} Backup Scrapers (The Crew)', f'ActivateWindow(Videos,{crew_target},return)'),
        ]
        if has_mt:
            cm.append((f'{name} Mad Titan Feeds', f'ActivateWindow(Videos,{primary_stream_url},return)'))
        li.addContextMenuItems(cm)
        entries.append((url, li, is_folder))

    # 5. RECENT FINAL GAMES (Top 6)
    post_games = [g for g in games if str(g.get('state', '')).upper() == 'POST']
    for ev in post_games[:6]:
        matchup = ev.get('name') or ev.get('short_name') or name
        score = ev.get('score', '')
        label = f"[COLOR gray]Final[/COLOR]  [COLOR #A0AAB8]{matchup}[/COLOR]  [COLOR gray]({score})[/COLOR]"
        entries.append(_folder(
            label,
            f'{CREW}?action=sreplays',
            art,
            f"{matchup} - Final score {score}. Open full event replays.",
            "Final"
        ))

    # 6. FULL EVENT & MATCH REPLAYS
    entries.append(_folder(
        f'🔄 [B][COLOR white]{name} Full Replays & Events[/COLOR][/B]',
        f'{CREW}?action=sreplays',
        _art('boxing'),
        f'Full match, fight, and event replays for {name} from The Crew.',
        'Event Replays'
    ))

    # 7. BACKUP SCRAPERS (Tucked away at the bottom!)
    entries.append(_folder(
        f'📁 [COLOR gray]The Crew Backup Scrapers (All Providers: RS, SE, FS...)[/COLOR]',
        crew_target,
        art,
        f'The Crew\'s 17 raw scrapers for {name}. Use only as a secondary backup if direct streams fail.',
        'Backup Only'
    ))

    xbmcplugin.setPluginCategory(handle, f'{name}')
    _finish(handle, entries)


_NOTICE_TEXT = {
    'college': ('No college league for {name}',
                '{name} does not have a college version. Use Live games, Pros, or Replay games.'),
    'replay': ('No {name} replays',
               'The Crew has no dedicated replay list for {name}. Use Live games or Pros.'),
}


def render_notice(handle, title, plot, back_key):
    url = plugin_url(action='sports_pick', sport=back_key) if back_key else plugin_url(action='sports_menu')
    art_name = LEAGUES[back_key][1] if back_key in LEAGUES else 'sports'
    _finish(handle, [_folder(title, url, _art(art_name), plot)])


def render_sport_choices(handle, key):
    """Inside one sport: delegate to unified clean sport hub."""
    return render_games(handle, key)


# ── Opening a stream ───────────────────────────────────────────

def _wait_for_crew_container(timeout_s=20):
    monitor = xbmc.Monitor()
    waited = 0.0
    while waited < timeout_s and not monitor.abortRequested():
        if (xbmc.getCondVisibility('Window.IsActive(videos)')
                and xbmc.getInfoLabel('Container.FolderPath').startswith(CREW)
                and not xbmc.getCondVisibility('Container.IsUpdating')):
            xbmc.sleep(250)
            return True
        xbmc.sleep(200)
        waited += 0.2
    return False


def open_stream(url, kind='folder'):
    """Open Crew stream or container."""
    if not (url or '').startswith(CREW):
        return
    if kind == 'play':
        xbmc.executebuiltin(f'RunPlugin({url})')
    else:
        if xbmcgui.getCurrentWindowId() == 10025:
            xbmc.executebuiltin(f'Container.Update({url})')
        else:
            xbmc.executebuiltin(f'ActivateWindow(Videos,{url},return)')


# ── Entry points ───────────────────────────────────────────────

def open_window(url):
    """From the skin (RunScript): show a Sports list in the Videos window."""
    if xbmcgui.getCurrentWindowId() == 10025:
        xbmc.executebuiltin(f'Container.Update({url})')
    else:
        xbmc.executebuiltin(f'ActivateWindow(Videos,{url},return)')
        if url.startswith(BASE):
            xbmc.executebuiltin('AlarmClock(AntiVenomWallView,Container.SetViewMode(500),00:02,silent)')


def _redirect(handle, url):
    """Redirect to target directory."""
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
    xbmc.executebuiltin(f'Container.Update({url})')


def plugin_handle():
    try:
        if sys.argv and str(sys.argv[0]).startswith('plugin://') and len(sys.argv) > 1:
            h = int(sys.argv[1])
            return h if h >= 0 else None
    except Exception:
        pass
    return None


NFL_JSON = MAGNETIC + '/MAD_TITAN_SPORTS/SPORTS/LEAGUE/titansports_nfl.json'
NFL_SLATE_TTL = 90
_COLOR_TAGS = re.compile(r'\[/?(?:COLOR|B|I)[^\]]*\]', re.I)
_KICKOFF = re.compile(r'(\d{1,2}):(\d{2})\s*([AP]M)', re.I)
_VERSUS = re.compile(r'([A-Za-z0-9][A-Za-z0-9 .\'-]{2,}?)\s+vs\s+([A-Za-z0-9][A-Za-z0-9 .\'-]{2,})$')


def _plain_title(title):
    text = _COLOR_TAGS.sub('', title or '')
    text = re.sub(r'[^\x00-\x7F]+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip(' |-')


def _kickoff_minutes(text):
    match = _KICKOFF.search(text or '')
    if not match:
        return 24 * 60
    hour, minute, meridiem = int(match.group(1)), int(match.group(2)), match.group(3).upper()
    if meridiem == 'PM' and hour != 12:
        hour += 12
    if meridiem == 'AM' and hour == 12:
        hour = 0
    return hour * 60 + minute


def _slate_path():
    try:
        folder = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom')
    except Exception:
        folder = os.path.dirname(__file__)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, 'nfl_slate.json')


def _load_nfl_slate():
    path = _slate_path()
    if not os.path.isfile(path):
        return None
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _write_nfl_slate(payload):
    path = _slate_path()
    tmp_path = path + '.tmp'
    with open(tmp_path, 'w', encoding='utf-8') as handle:
        json.dump(payload, handle, indent=2)
    os.replace(tmp_path, path)
    log(f"Wrote NFL slate games={len(payload.get('rows') or [])}")


NFL_ABBR = {
    'arizona': 'ari', 'cardinals': 'ari',
    'atlanta': 'atl', 'falcons': 'atl',
    'baltimore': 'bal', 'ravens': 'bal',
    'buffalo': 'buf', 'bills': 'buf',
    'carolina': 'car', 'panthers': 'car',
    'chicago': 'chi', 'bears': 'chi',
    'cincinnati': 'cin', 'bengals': 'cin',
    'cleveland': 'cle', 'browns': 'cle',
    'dallas': 'dal', 'cowboys': 'dal',
    'denver': 'den', 'broncos': 'den',
    'detroit': 'det', 'lions': 'det',
    'green bay': 'gb', 'packers': 'gb',
    'houston': 'hou', 'texans': 'hou',
    'indianapolis': 'ind', 'colts': 'ind',
    'jacksonville': 'jax', 'jaguars': 'jax',
    'kansas city': 'kc', 'chiefs': 'kc',
    'las vegas': 'lv', 'oakland': 'lv', 'raiders': 'lv',
    'los angeles chargers': 'lac', 'chargers': 'lac',
    'los angeles rams': 'lar', 'rams': 'lar',
    'miami': 'mia', 'dolphins': 'mia',
    'minnesota': 'min', 'vikings': 'min',
    'new england': 'ne', 'patriots': 'ne',
    'new orleans': 'no', 'saints': 'no',
    'new york giants': 'nyg', 'giants': 'nyg',
    'new york jets': 'nyj', 'jets': 'nyj',
    'philadelphia': 'phi', 'eagles': 'phi',
    'pittsburgh': 'pit', 'steelers': 'pit',
    'san francisco': 'sf', '49ers': 'sf', 'niners': 'sf',
    'seattle': 'sea', 'seahawks': 'sea',
    'tampa': 'tb', 'buccaneers': 'tb', 'bucs': 'tb',
    'tennessee': 'ten', 'titans': 'ten',
    'washington': 'wsh', 'commanders': 'wsh',
}
NFL_LOGO_STYLES = (
    'https://a.espncdn.com/i/teamlogos/nfl/500/{abbr}.png',
    'https://a.espncdn.com/i/teamlogos/nfl/500/scoreboard/{abbr}.png',
    'https://a.espncdn.com/i/teamlogos/nfl/500-dark/{abbr}.png',
)
NFL_LEAGUE_LOGO = 'https://a.espncdn.com/i/teamlogos/nfl/500/nfl.png'


def _nfl_week():
    return datetime.date.today().isocalendar()[1]


def _team_abbr(name):
    text = (name or '').lower()
    for key in sorted(NFL_ABBR, key=len, reverse=True):
        if key in text:
            return NFL_ABBR[key]
    return ''


def _art_dir():
    folder = os.path.join(os.path.dirname(_slate_path()), 'nfl_art')
    os.makedirs(folder, exist_ok=True)
    return folder


def _download_logo(dest, url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=8) as resp:
        data = resp.read()
    if not data or len(data) < 400:
        return False
    tmp = dest + '.tmp'
    with open(tmp, 'wb') as handle:
        handle.write(data)
    os.replace(tmp, dest)
    return True


def _cache_team_logo(abbr, style=0, preferred_url=''):
    if not abbr:
        return preferred_url or ''
    dest = os.path.join(_art_dir(), f'{abbr}_{int(style)}.png')
    if os.path.isfile(dest) and os.path.getsize(dest) > 400:
        return dest
    urls = []
    if preferred_url:
        urls.append(preferred_url)
    urls.append(NFL_LOGO_STYLES[int(style) % len(NFL_LOGO_STYLES)].format(abbr=abbr))
    for idx, tmpl in enumerate(NFL_LOGO_STYLES):
        if idx != int(style) % len(NFL_LOGO_STYLES):
            urls.append(tmpl.format(abbr=abbr))
    for url in urls:
        try:
            if _download_logo(dest, url):
                return dest
        except Exception:
            continue
    return preferred_url or ''


def _team_picture(away, home, away_logo='', home_logo=''):
    """Scan both teams and pick this week's picture. Home/away and logo style flip each week."""
    week = _nfl_week()
    style = week % len(NFL_LOGO_STYLES)
    away_abbr = _team_abbr(away)
    home_abbr = _team_abbr(home)
    if week % 2:
        first = (away_abbr, away_logo)
        second = (home_abbr, home_logo)
    else:
        first = (home_abbr, home_logo)
        second = (away_abbr, away_logo)
    return _cache_team_logo(first[0], style, first[1]) or _cache_team_logo(second[0], style, second[1])


def _redzone_picture():
    dest = os.path.join(_art_dir(), 'nfl_0.png')
    if os.path.isfile(dest) and os.path.getsize(dest) > 400:
        return dest
    try:
        if _download_logo(dest, NFL_LEAGUE_LOGO):
            return dest
    except Exception:
        pass
    return 'special://home/addons/skin.antivenom/media/antivenom/sports/nfl.jpg'


def _apply_row_picture(row, away='', home='', away_logo='', home_logo=''):
    query = row.get('query') or ''
    if query.lower() == 'redzone':
        row['thumb'] = _redzone_picture()
        return row
    if not away or not home:
        parts = re.split(r'\s+vs\s+', query, maxsplit=1, flags=re.I)
        if len(parts) == 2:
            away, home = parts[0].strip(), parts[1].strip()
    picture = _team_picture(away, home, away_logo, home_logo)
    if picture:
        row['thumb'] = picture
    return row


def _espn_nfl_events():
    path = os.path.join(os.path.dirname(_slate_path()), 'gameday_scores.json')
    if not os.path.isfile(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return list((data.get('leagues') or {}).get('NFL') or [])
    except Exception:
        return []


def _annotate_nfl_row(row, events):
    query = (row.get('query') or '').lower()
    if 'redzone' in query:
        live = any(str(event.get('state', '')).upper() == 'IN' for event in events)
        row['state'] = 'IN' if live else row.get('state') or 'PRE'
        row['label2'] = 'LIVE' if live else 'Every game at once'
        return _apply_row_picture(row)
    best = None
    best_score = 0
    for event in events:
        hay = ' '.join([
            str(event.get('away_name') or ''),
            str(event.get('home_name') or ''),
            str(event.get('short_name') or ''),
            str(event.get('name') or ''),
        ]).lower()
        score = 0
        for part in query.replace(' vs ', ' ').split():
            if len(part) >= 4 and part in hay:
                score += 1
        if score > best_score:
            best_score = score
            best = event
    if not best or best_score < 2:
        return row
    state = str(best.get('state') or '').upper()
    row['state'] = state
    if state == 'IN':
        row['label'] = f"LIVE  {row['query']}"
        row['label2'] = best.get('clock') or best.get('score') or 'LIVE'
    elif state == 'POST':
        row['label'] = f"Final  {row['query']}"
        row['label2'] = best.get('score') or 'Final'
    else:
        row['label2'] = best.get('clock') or row.get('label2') or 'Today'
    return _apply_row_picture(
        row,
        best.get('away_name') or '',
        best.get('home_name') or '',
        best.get('away_logo') or '',
        best.get('home_logo') or '',
    )


def _rows_from_items(items):
    redzone = None
    games = []
    seen = set()
    for item in items or []:
        if not isinstance(item, dict):
            continue
        links = item.get('link') or []
        if isinstance(links, str):
            links = [links] if links else []
        if not links:
            continue
        plain = _plain_title(item.get('title'))
        low = plain.lower()
        if not plain or 'refresh' in low or 'previous search' in low or 'schedule' in low:
            continue
        if 'redzone' in low or 'red zone' in low:
            if redzone is None or len(links) > redzone[0]:
                redzone = (len(links), item)
            continue
        match = _VERSUS.search(plain)
        if not match:
            continue
        away = re.sub(r'^.*\bNFL\s*:\s*', '', match.group(1)).strip()
        home = match.group(2).strip()
        key = f'{away.lower()} vs {home.lower()}'
        if key in seen:
            continue
        seen.add(key)
        when_match = _KICKOFF.search(plain)
        when = re.sub(r'\s+', ' ', when_match.group(0).upper()) if when_match else ''
        games.append((_kickoff_minutes(when), when, away, home, item.get('thumbnail') or '', item))
    games.sort(key=lambda row: (row[0], row[2]))
    rows = []
    keep_items = []
    if redzone:
        rows.append(_apply_row_picture({
            'label': 'NFL RedZone',
            'query': 'RedZone',
            'label2': 'Every game at once',
            'thumb': '',
            'state': 'PRE',
        }))
        keep_items.append(redzone[1])
    for _mins, when, away, home, _thumb, item in games:
        rows.append(_apply_row_picture({
            'label': f'{when}  {away} vs {home}'.strip(),
            'query': f'{away} vs {home}',
            'label2': 'Today',
            'thumb': '',
            'state': 'PRE',
        }, away, home))
        keep_items.append(item)
    events = _espn_nfl_events()
    if events:
        rows = [_annotate_nfl_row(row, events) for row in rows]
    return rows, keep_items


def _fetch_nfl_items(live=True):
    if live:
        try:
            req = urllib.request.Request(NFL_JSON, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=15) as resp:
                payload = json.loads(resp.read().decode('utf-8', 'replace'))
            items = payload.get('items') if isinstance(payload, dict) else payload
            if items:
                return list(items)
        except Exception as e:
            log(f'NFL slate fetch failed: {e}')
    cached = _load_nfl_slate() or {}
    return list(cached.get('items') or [])


def refresh_nfl_slate(force=False):
    """Write today's real NFL game list. Keep the last good file if the feed fails."""
    now = time.time()
    cached = _load_nfl_slate()
    age = now - float((cached or {}).get('last_updated') or 0)
    if not force and cached and cached.get('rows') and age < NFL_SLATE_TTL:
        _apply_nfl_slate_to_skin(cached)
        return cached
    items = _fetch_nfl_items(live=True)
    if not items:
        if cached and cached.get('rows'):
            log('NFL slate feed missed; keeping last real file')
            _apply_nfl_slate_to_skin(cached)
            return cached
        return {'last_updated': now, 'rows': [], 'items': []}
    rows, keep_items = _rows_from_items(items)
    payload = {
        'last_updated': now,
        'rows': rows,
        'items': keep_items,
        'live': sum(1 for row in rows if row.get('state') == 'IN'),
    }
    try:
        _write_nfl_slate(payload)
    except Exception as e:
        log(f'NFL slate write failed: {e}')
    _apply_nfl_slate_to_skin(payload)
    return payload


def _apply_nfl_slate_to_skin(payload):
    try:
        win = xbmcgui.Window(10000)
    except Exception:
        return
    rows = payload.get('rows') or []
    live_n = sum(1 for row in rows if row.get('state') == 'IN')
    win.setProperty('AntiVenom.NFL.SlateCount', str(len(rows)))
    win.setProperty('AntiVenom.NFL.LiveCount', str(live_n))
    win.setProperty('AntiVenom.NFL.HasLive', 'true' if live_n else '')
    next_game = next((row for row in rows if row.get('state') == 'IN'), None)
    if not next_game:
        next_game = next((row for row in rows if row.get('query') != 'RedZone' and row.get('state') != 'POST'), None)
    if next_game:
        win.setProperty('AntiVenom.NFL.NextGame', next_game.get('label') or '')
    else:
        win.clearProperty('AntiVenom.NFL.NextGame')


def nfl_choices():
    """One row for RedZone and one row per game. Uses the auto-written slate."""
    payload = refresh_nfl_slate()
    return list((payload or {}).get('rows') or [])


def _match_nfl_item(query):
    wanted = (query or '').strip()
    low_q = wanted.lower()
    teams = [part.strip().lower() for part in re.split(r'\s+vs\s+', wanted, maxsplit=1, flags=re.I)]
    items = _fetch_nfl_items(live=True) or _fetch_nfl_items(live=False)
    best = None
    best_score = 0
    for item in items:
        if not isinstance(item, dict):
            continue
        links = item.get('link') or []
        if isinstance(links, str):
            links = [links] if links else []
        if not links:
            continue
        plain = _plain_title(item.get('title')).lower()
        if 'redzone' in low_q or 'red zone' in low_q:
            score = 5 if ('redzone' in plain or 'red zone' in plain) else 0
        else:
            score = 0
            for team in teams:
                if not team:
                    continue
                if team in plain:
                    score += 3
                else:
                    last = team.split()[-1]
                    if len(last) >= 4 and last in plain:
                        score += 2
            if 'redzone' in plain or 'schedule' in plain:
                score -= 5
        if score > best_score:
            best_score = score
            best = item
    return best if best_score > 0 else None


def _playable(label, url, art=None, plot='', label2=''):
    li = xbmcgui.ListItem(label=label, label2=label2, offscreen=True)
    art = _with_poster(art)
    if art:
        li.setArt(art)
    li.setInfo('video', {'title': label, 'plot': plot or label, 'mediatype': 'movie'})
    li.setProperty('IsPlayable', 'true')
    return (url, li, False)


def _pick_best_nfl_stream(item):
    """Automatically selects the best single stream link from an NFL item.
    Never returns a list so that Jetextractors/Mad Titan does not pop up a link selection dialog.
    """
    if not item or not isinstance(item, dict):
        return None
    raw_links = item.get('link') or []
    if isinstance(raw_links, str):
        raw_links = [raw_links]
    
    valid = [
        l for l in raw_links
        if isinstance(l, str) and l.strip()
        and 'cache_dialog' not in l
        and '*(CACHED SEARCHES)' not in l
        and 'refresh_menu' not in l
    ]
    if not valid:
        return None
    
    channels = item.get('channels') or []
    # Priority channels: Sunday Ticket, Major US Networks, Sky Sports NFL, Event Stream, TSN
    pref_channels = ['sunday ticket', 'cbs', 'fox', 'nbc', 'espn', 'nfl network', 'sky sports nfl', 'event stream', 'tsn']
    for pref in pref_channels:
        for ch in channels:
            ch_name = (ch.get('channel_name') or '').lower()
            ch_id = (ch.get('channel_id') or '').lower()
            if pref in ch_name or pref in ch_id:
                m = re.search(r'id=(\d+)', ch_id)
                if m:
                    target_id = m.group(1)
                    for l in valid:
                        if f'id={target_id}' in l:
                            return l
    
    # Next preference: Scraper search for the game
    for l in valid:
        if 'search_dialog' in l:
            return l

    # Next preference: Major US network in link string
    for net in ('cbs', 'fox', 'nbc', 'espn', 'tsn'):
        for l in valid:
            if net in l.lower():
                return l

    # Fallback to the first valid stream link
    return valid[0]


def _start_playback_monitor(title, backup_url, sport_label='Sports'):
    """Spawns a background thread to verify that playback starts.
    If playback fails or stops within 10 seconds, automatically tries backup streams
    then falls back to The Crew scrapers.
    """
    def _worker():
        started = time.time()
        while time.time() - started < 10:
            xbmc.sleep(500)
            if xbmc.Player().isPlayingVideo():
                log(f'{sport_label} playback confirmed for {title}')
                return
        if not xbmc.Player().isPlaying():
            log(f'{sport_label} playback failed after 10s for {title}; launching backup: {backup_url}')
            try:
                xbmcgui.Dialog().notification(
                    sport_label,
                    'Primary feed unavailable. Opening backup scrapers...',
                    xbmcgui.NOTIFICATION_WARNING,
                    3500
                )
            except Exception:
                pass
            xbmc.executebuiltin(f'ActivateWindow(Videos,{backup_url},return)')

    t = threading.Thread(target=_worker)
    t.daemon = True
    t.start()


# Keep backward compat alias
def _start_nfl_playback_monitor(title, backup_url):
    _start_playback_monitor(title, backup_url, sport_label='NFL Live')


# ── Universal Auto-Play Engine (all sports) ───────────────────

# Preferred channels by sport for auto-stream selection
_PREF_CHANNELS = {
    'nba': ['nba tv', 'espn', 'tnt', 'abc', 'event stream', 'tsn'],
    'nhl': ['nhl gamecenter', 'nhl network', 'espn', 'msg', 'tnt', 'event stream', 'tsn'],
    'mlb': ['mlb network', 'espn', 'fox', 'tbs', 'event stream', 'tsn'],
    'ufc': ['ufc fight pass', 'espn', 'espn+', 'event stream', 'paramount'],
    'boxing': ['espn', 'showtime', 'dazn', 'event stream'],
    'fifa': ['nbc sports', 'peacock', 'espn', 'fox', 'event stream', 'tsn'],
    'ncaa': ['espn', 'espnu', 'abc', 'fox', 'sec network', 'big ten', 'event stream'],
    'ncaab': ['espn', 'espnu', 'cbs', 'fox', 'big ten', 'sec network', 'event stream'],
    'wwe': ['usa network', 'raw', 'smackdown', 'event stream'],
    'f1': ['sky sports f1', 'espn', 'event stream'],
    'nascar': ['fox', 'nbc', 'usa network', 'event stream'],
    'motogp': ['bein', 'event stream'],
    'tennis': ['espn', 'tennis channel', 'event stream'],
    'pga': ['golf channel', 'espn', 'cbs', 'event stream'],
    'wnba': ['espn', 'abc', 'ion', 'event stream'],
    'ppv': ['event stream', 'espn', 'showtime', 'dazn'],
    'nfl': ['sunday ticket', 'cbs', 'fox', 'nbc', 'espn', 'nfl network', 'event stream', 'tsn'],
}


def _fetch_mt_items(sport_key):
    """Fetch the Mad Titan league JSON for any sport and return its items list."""
    mt_key = MT_LIVE.get(sport_key)
    if not mt_key:
        return []
    json_url = MT_LEAGUE.format(mt_key)
    try:
        req = urllib.request.Request(json_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            payload = json.loads(resp.read().decode('utf-8', 'replace'))
        items = payload.get('items') if isinstance(payload, dict) else payload
        return list(items) if items else []
    except Exception as e:
        log(f'MT feed fetch failed for {sport_key}: {e}')
        return []


def _match_mt_item(items, matchup, sport_key=''):
    """Find the best matching Mad Titan item for a given matchup string.
    Works for all sports: NBA, NHL, UFC, MLB, Soccer, etc.
    """
    if not items or not matchup:
        return None
    matchup_lower = matchup.lower()
    # Extract meaningful words from matchup (team names, fighter names)
    # Remove common noise words
    noise = {'vs', 'at', 'the', 'of', 'and', 'in', 'on', 'for', 'a', 'an', 'to'}
    matchup_words = [w for w in re.split(r'[\s,\-@]+', matchup_lower) if len(w) >= 3 and w not in noise]

    best = None
    best_score = 0
    for item in items:
        if not isinstance(item, dict):
            continue
        links = item.get('link') or []
        if isinstance(links, str):
            links = [links] if links else []
        # Skip items without playable links
        if not links or len(links) < 2:
            continue
        title_raw = item.get('title') or ''
        title_clean = _COLOR_TAGS.sub('', title_raw)
        title_clean = re.sub(r'[^\x00-\x7F]+', ' ', title_clean)
        title_lower = title_clean.lower()
        # Skip non-game items
        if 'refresh' in title_lower or 'previous search' in title_lower or 'scoreboard' in title_lower:
            continue
        score = 0
        for word in matchup_words:
            if word in title_lower:
                score += 1
        if score > best_score:
            best_score = score
            best = item
    # Require at least 2 matching words to avoid false positives
    return best if best_score >= 2 else None


def _pick_best_stream(item, sport_key=''):
    """Universal best-stream picker for any sport's Mad Titan item.
    Returns a list of stream URLs ordered by quality priority (best first).
    """
    if not item or not isinstance(item, dict):
        return []
    raw_links = item.get('link') or []
    if isinstance(raw_links, str):
        raw_links = [raw_links]

    valid = [
        l for l in raw_links
        if isinstance(l, str) and l.strip()
        and 'cache_dialog' not in l
        and '*(CACHED SEARCHES)' not in l
        and 'refresh_menu' not in l
    ]
    if not valid:
        return []

    # Categorize links
    direct_streams = []  # sportjetextractors/play URLs (best - direct playable)
    channel_links = []   # search_json channel-specific URLs
    scraper_links = []   # search_dialog scraper URLs
    other_links = []     # anything else

    for l in valid:
        if 'sportjetextractors/play' in l:
            direct_streams.append(l)
        elif 'search_json' in l:
            channel_links.append(l)
        elif 'search_dialog' in l:
            scraper_links.append(l)
        elif 'search_music' in l:
            other_links.append(l)
        else:
            other_links.append(l)

    # Prioritize direct streams by preferred channels for this sport
    channels = item.get('channels') or []
    prefs = _PREF_CHANNELS.get(sport_key, ['espn', 'event stream', 'tsn'])
    ordered_direct = []

    # Match preferred channels to their direct stream links
    for pref in prefs:
        for ch in channels:
            ch_name = (ch.get('channel_name') or '').lower()
            if pref in ch_name:
                ch_id = ch.get('channel_id') or ''
                # Find matching direct stream link
                for ds in direct_streams:
                    if ch_id in ds and ds not in ordered_direct:
                        ordered_direct.append(ds)
                        break

    # Add remaining direct streams not yet picked
    for ds in direct_streams:
        if ds not in ordered_direct:
            ordered_direct.append(ds)

    # Build final priority list: preferred direct streams > other directs > channels > scrapers
    result = ordered_direct + channel_links + scraper_links + other_links
    return result


def _try_play_stream(stream_url, title, attempt_no, total):
    """Attempt to play a single stream URL. Returns True if playback starts within timeout."""
    log(f'AutoPlay attempt {attempt_no}/{total} for {title}: {stream_url[:100]}')
    xbmc.executebuiltin('PlayMedia("%s")' % stream_url.replace('"', ''))
    # Wait up to 12 seconds for playback to start
    started = time.time()
    while time.time() - started < 12:
        xbmc.sleep(500)
        if xbmc.Player().isPlayingVideo():
            log(f'AutoPlay attempt {attempt_no} succeeded for {title}')
            return True
    return False


def play_sport(sport_key, matchup):
    """Universal auto-play: find the best stream for any sport and play it automatically.
    Tries multiple streams in priority order, then falls back to The Crew scrapers.
    """
    handle = plugin_handle()
    name = LEAGUES.get(sport_key, ('Sports',))[0]
    crew_action = CREW_ACTIONS.get(sport_key, 'bluehat')
    crew_backup = f'{CREW}?action={crew_action}'

    if not madtitan_ready():
        log(f'{name}: Mad Titan not installed. Opening The Crew scrapers.')
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmc.executebuiltin(f'ActivateWindow(Videos,{crew_backup},return)')
        return

    # Fetch Mad Titan feed for this sport
    items = _fetch_mt_items(sport_key)
    if not items:
        log(f'{name}: MT feed empty. Opening The Crew backup.')
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification(name, 'No games on feed. Opening backup scrapers...', xbmcgui.NOTIFICATION_INFO, 3500)
        xbmc.executebuiltin(f'ActivateWindow(Videos,{crew_backup},return)')
        return

    # Match the clicked game to a Mad Titan item
    item = _match_mt_item(items, matchup, sport_key)
    if not item:
        log(f'{name}: No match for "{matchup}". Opening The Crew backup.')
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification(name, 'Game not found on feed. Opening backup scrapers...', xbmcgui.NOTIFICATION_INFO, 3500)
        xbmc.executebuiltin(f'ActivateWindow(Videos,{crew_backup},return)')
        return

    # Get prioritized stream list
    streams = _pick_best_stream(item, sport_key)
    if not streams:
        log(f'{name}: No valid streams for "{matchup}". Opening backup.')
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification(name, 'No streams available. Opening backup scrapers...', xbmcgui.NOTIFICATION_INFO, 3500)
        xbmc.executebuiltin(f'ActivateWindow(Videos,{crew_backup},return)')
        return

    title = _plain_title(item.get('title')) or matchup

    # For direct sportjetextractors links, play them directly (they're already plugin:// URLs)
    # For search_dialog/search_json links, use the Mad Titan play_video token approach
    best = streams[0]

    if 'sportjetextractors/play' in best:
        play_url = best
    else:
        clean_item = dict(item)
        clean_item['link'] = best
        clean_item.pop('channels', None)
        clean_item.pop('guidedata', None)
        token = base64.urlsafe_b64encode(json.dumps(clean_item).encode('utf-8')).decode('utf-8')
        play_url = f'{MT}/play_video/{token}'

    log(f'{name} AutoPlay selected best stream for {title}: {play_url[:90]}')

    # Start backup monitor: if primary fails, try next streams then The Crew
    _start_sport_backup_chain(title, streams[1:], crew_backup, name)

    if handle is not None:
        li = xbmcgui.ListItem(label=title, path=play_url)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(handle, True, li)
        return

    xbmc.executebuiltin('PlayMedia("%s")' % play_url.replace('"', ''))


def _start_sport_backup_chain(title, backup_streams, crew_backup, sport_label):
    """Background thread: if primary stream fails, try backup streams in order,
    then fall back to The Crew scrapers as last resort.
    """
    def _worker():
        # Wait for primary to start
        started = time.time()
        while time.time() - started < 12:
            xbmc.sleep(500)
            if xbmc.Player().isPlayingVideo():
                log(f'{sport_label} primary stream confirmed for {title}')
                return
        if xbmc.Player().isPlaying():
            return

        # Primary failed. Try backup streams (up to 3 more)
        max_backups = min(len(backup_streams), 3)
        for i, stream in enumerate(backup_streams[:max_backups]):
            log(f'{sport_label} backup {i+1}/{max_backups} for {title}: {stream[:80]}')
            try:
                xbmcgui.Dialog().notification(
                    sport_label,
                    f'Trying backup stream {i+1}...',
                    xbmcgui.NOTIFICATION_INFO,
                    2000
                )
            except Exception:
                pass
            if 'sportjetextractors/play' in stream:
                xbmc.executebuiltin('PlayMedia("%s")' % stream.replace('"', ''))
            else:
                xbmc.executebuiltin('PlayMedia("%s")' % stream.replace('"', ''))

            backup_started = time.time()
            while time.time() - backup_started < 10:
                xbmc.sleep(500)
                if xbmc.Player().isPlayingVideo():
                    log(f'{sport_label} backup {i+1} succeeded for {title}')
                    return
            if xbmc.Player().isPlaying():
                return

        # All backup streams failed. Fall back to The Crew
        log(f'{sport_label} all streams failed for {title}; opening The Crew backup')
        try:
            xbmcgui.Dialog().notification(
                sport_label,
                'All direct feeds failed. Opening The Crew scrapers...',
                xbmcgui.NOTIFICATION_WARNING,
                3500
            )
        except Exception:
            pass
        xbmc.executebuiltin(f'ActivateWindow(Videos,{crew_backup},return)')

    t = threading.Thread(target=_worker)
    t.daemon = True
    t.start()


def render_nfl(handle):
    """Today's NFL games. Features direct backup scraper choices and one tile per game."""
    try:
        rows = nfl_choices()
    except Exception as e:
        log(f'NFL list failed: {e}')
        rows = []
    art = _art('nfl')
    entries = []

    # Top Live Shortcuts: Direct Mad Titan Feeds & RedZone
    if madtitan_ready():
        entries.append(_folder(
            '⚡ [B][COLOR #00F5A0]Mad Titan NFL All Live Feeds & Sunday Ticket[/COLOR][/B]',
            mt_league('nfl'),
            art,
            'Direct game schedule, RedZone, Sunday Ticket and working live feeds for NFL.',
            'Direct Working Feeds',
        ))
    entries.append(_folder(
        '📺 [B][COLOR white]NFL RedZone & 24/7 Sports Channels[/COLOR][/B]',
        f'{CREW}?action=sports_channels',
        art,
        '24/7 Live Sports Channels: NFL Network, RedZone, ESPN, FOX Sports, CBS Sports, NBC Sports.',
        'Live TV Channels',
    ))

    if not rows:
        entries.append(_folder(
            'NFL games did not load (Click to retry)',
            plugin_url(action='sports_league', key='nfl'),
            art,
            'Open this again to reload today\'s games.',
        ))

    for row in rows:
        item_art = dict(art)
        if row.get('thumb'):
            item_art['poster'] = row['thumb']
            item_art['thumb'] = row['thumb']

        url, li, is_folder = _playable(
            row['label'],
            plugin_url(action='sports_play', sport='nfl', query=row['query']),
            item_art,
            row['label'],
            row.get('label2') or '',
        )
        cm = [
            ('The Crew NFL Scrapers (Backup)', f'ActivateWindow(Videos,{CREW}?action=nfl,return)'),
            ('The Crew Sports Center', f'ActivateWindow(Videos,{CREW}?action=bluehat,return)'),
        ]
        if madtitan_ready():
            cm.append(('Mad Titan NFL Feeds (Backup)', f'ActivateWindow(Videos,{mt_league("nfl")},return)'))
        li.addContextMenuItems(cm)
        entries.append((url, li, is_folder))

    entries.append(_folder(
        '🔄 [B][COLOR white]NFL Full Game Replays[/COLOR][/B]',
        f'{CREW}?action=sreplays',
        _art('boxing'),
        'Full match and game replays for NFL from The Crew.',
        'Game Replays',
    ))
    entries.append(_folder(
        '📁 [COLOR gray]The Crew NFL Backup Scrapers (All Providers)[/COLOR]',
        f'{CREW}?action=nfl',
        art,
        'The Crew\'s 8 live NFL scrapers: TopStreams, StreamCheck, RippleStreams, GiveMeStreams, FoxyStreams, Goal24, VipKey, PakStreams.',
        'Backup Only',
    ))

    xbmcplugin.setPluginCategory(handle, 'NFL')
    _finish(handle, entries)


def play_nfl(query):
    """Play the game automatically choosing the best stream without dialogs, with automatic backup scraper fallback."""
    handle = plugin_handle()
    crew_backup = f'{CREW}?action=nfl'
    try:
        item = _match_nfl_item(query)
    except Exception as e:
        log(f'NFL play lookup failed: {e}')
        item = None

    if not item:
        log(f'NFL game not matched for "{query}". Opening The Crew backup scrapers.')
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification('NFL Live', 'Direct feed not on slate. Opening backup scrapers...', xbmcgui.NOTIFICATION_INFO, 3500)
        xbmc.executebuiltin(f'ActivateWindow(Videos,{crew_backup},return)')
        return

    best_link = _pick_best_nfl_stream(item)
    title = _plain_title(item.get('title')) or query

    if not best_link:
        log(f'No valid stream link found for "{query}". Opening The Crew backup scrapers.')
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification('NFL Live', 'No direct feed available. Opening backup scrapers...', xbmcgui.NOTIFICATION_INFO, 3500)
        xbmc.executebuiltin(f'ActivateWindow(Videos,{crew_backup},return)')
        return

    # Set link to a SINGLE string so Mad Titan does NOT display the link selection dialog
    clean_item = dict(item)
    clean_item['link'] = best_link
    clean_item.pop('channels', None)
    clean_item.pop('guidedata', None)

    token = base64.urlsafe_b64encode(json.dumps(clean_item).encode('utf-8')).decode('utf-8')
    play_url = f'{MT}/play_video/{token}'
    log(f'NFL AutoPlay selected best stream for {title}: {best_link[:80]}')

    # Background monitor ensures fallback to The Crew if playback fails to start
    _start_nfl_playback_monitor(title, crew_backup)

    if handle is not None:
        li = xbmcgui.ListItem(label=title, path=play_url)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(handle, True, li)
        return

    xbmc.executebuiltin('PlayMedia("%s")' % play_url.replace('"', ''))


def route(action, args):
    """Handles sports_menu / sports_bucket / sports_pick / sports_games / sports_league /
    sports_replays / sports_notice / sports_open."""
    handle = plugin_handle()
    if action == 'sports_play':
        play_nfl(args.get('query') or '')
        return True
    if action == 'sports_play_universal':
        sport = league_key(args.get('sport') or args.get('key') or '')
        matchup = args.get('matchup') or args.get('query') or ''
        if sport == 'nfl':
            play_nfl(matchup)
        else:
            play_sport(sport, matchup)
        return True
    if action == 'sports_open':
        open_stream(args.get('url', ''), args.get('kind', 'folder'))
        return True
    external = None
    render = None
    if action == 'sports_menu':
        url = plugin_url(action='sports_menu')
        render = lambda h: render_menu(h)
    elif action == 'sports_bucket':
        bucket = args.get('bucket', 'pros')
        url = plugin_url(action='sports_bucket', bucket=bucket)
        render = lambda h: render_bucket(h, bucket)
    elif action == 'sports_pick':
        key = league_key(args.get('sport') or args.get('key'))
        if not key:
            return route('sports_menu', {})
        if key == 'nfl':
            url = plugin_url(action='sports_league', key='nfl')
            render = lambda h: render_nfl(h)
        else:
            url = plugin_url(action='sports_pick', sport=key)
            render = lambda h: render_sport_choices(h, key)
    elif action == 'sports_notice':
        sport = league_key(args.get('sport'))
        kind = 'replay' if args.get('kind') == 'replay' else 'college'
        name = LEAGUES[sport][0] if sport in LEAGUES else 'This sport'
        title, plot = (t.format(name=name) for t in _NOTICE_TEXT[kind])
        url = plugin_url(action='sports_notice', sport=sport or '', kind=kind)
        render = lambda h: render_notice(h, title, plot, sport)
    elif action == 'sports_replays':
        external = f'{CREW}?action=sreplays'
    elif action == 'sports_games':
        key = league_key(args.get('key') or args.get('sport'))
        if not key:
            return route('sports_menu', {})
        url = plugin_url(action='sports_games', key=key)
        render = lambda h: render_games(h, key)
    elif action == 'sports_league':
        key = args.get('key') or args.get('sport')
        if key == 'all_live':
            external = f'{CREW}?action=bluehat'
        elif key == 'channels':
            external = f'{CREW}?action=sports_channels'
        else:
            key = league_key(key)
            if not key:
                return route('sports_menu', {})
            url = plugin_url(action='sports_league', key=key)
            render = lambda h: render_games(h, key)
    else:
        return False
    if external:
        if handle is None:
            open_window(external)
        else:
            _redirect(handle, external)
    elif handle is None:
        open_window(url)
    else:
        render(handle)
    return True
