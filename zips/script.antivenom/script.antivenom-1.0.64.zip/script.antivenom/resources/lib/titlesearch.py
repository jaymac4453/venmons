# -*- coding: utf-8 -*-
"""Closest-title lookup for Movie/TV search.

The Crew's search returns nothing for partial or misspelled titles
("james and the giant"). TMDB matches partial titles; Cinemeta tolerates typos.
"""
import json
import re
import threading
import urllib.parse
import urllib.request

TMDB_KEY = '0049795edb57568b95240bc9e61a9dfc'
TMDB = 'https://api.themoviedb.org/3'
IMG = 'https://image.tmdb.org/t/p/'
CINEMETA = 'https://v3-cinemeta.strem.io/catalog/{kind}/top/search={q}.json'
MAX_RESULTS = 12


def _get(url, timeout=6):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 AntiVenom'})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8', 'replace'))


def _norm(text):
    return re.sub(r'[^a-z0-9 ]+', '', (text or '').lower()).strip()


def _tmdb_search(query, kind):
    path = 'tv' if kind == 'tv' else 'movie'
    url = (f'{TMDB}/search/{path}?api_key={TMDB_KEY}&include_adult=false&page=1'
           f'&query={urllib.parse.quote_plus(query)}')
    try:
        return _get(url).get('results') or []
    except Exception:
        return []


def _cinemeta_names(query, kind):
    url = CINEMETA.format(kind='series' if kind == 'tv' else 'movie',
                          q=urllib.parse.quote(query))
    try:
        metas = _get(url).get('metas') or []
    except Exception:
        return []
    names = []
    for m in metas:
        name = (m.get('name') or '').strip()
        if name and name.lower() not in (n.lower() for n in names):
            names.append(name)
    return names


def _rank(results, query):
    q = _norm(query)

    def key(r):
        title = _norm(r.get('title') or r.get('name'))
        return (not title.startswith(q), q not in title, -(r.get('popularity') or 0))
    return sorted(results, key=key)


def find(query, kind='movie'):
    """TMDB results for the closest real title(s). kind is 'movie' or 'tv'."""
    query = (query or '').strip()
    if not query:
        return []
    results = _tmdb_search(query, kind)
    if not results:
        for name in _cinemeta_names(query, kind)[:2]:
            results = _tmdb_search(name, kind)
            if results:
                query = name
                break
    if not results:
        words = query.split()
        while len(words) > 1 and not results:
            words = words[:-1]
            results = _tmdb_search(' '.join(words), kind)
    return _rank(results, query)[:MAX_RESULTS]


def best_title(query, kind='movie'):
    results = find(query, kind)
    if not results:
        return ''
    return results[0].get('title') or results[0].get('name') or ''


def _imdb_ids(results, kind):
    path = 'tv' if kind == 'tv' else 'movie'
    ids = {}

    def worker(tmdb_id):
        try:
            ext = _get(f'{TMDB}/{path}/{tmdb_id}/external_ids?api_key={TMDB_KEY}', timeout=5)
            ids[tmdb_id] = ext.get('imdb_id') or ''
        except Exception:
            ids[tmdb_id] = ''

    threads = [threading.Thread(target=worker, args=(r.get('id'),), daemon=True)
               for r in results if r.get('id')]
    for t in threads:
        t.start()
    for t in threads:
        t.join(8)
    return ids


def crew_rows(query, kind='movie'):
    """Wall-view rows (crewcache item format) built straight from TMDB matches."""
    results = find(query, kind)
    if not results:
        return []
    imdb = _imdb_ids(results, kind)
    rows = []
    for r in results:
        tmdb_id = r.get('id')
        title = r.get('title') or r.get('name') or ''
        date = r.get('release_date') or r.get('first_air_date') or ''
        year = date[:4] if len(date) >= 4 else ''
        imdb_id = imdb.get(tmdb_id, '')
        if kind == 'tv':
            if not imdb_id:
                continue
            params = {'action': 'seasons', 'tvshowtitle': title, 'year': year,
                      'imdb': imdb_id, 'tmdb': tmdb_id}
        else:
            params = {'action': 'play', 'title': title, 'year': year,
                      'imdb': imdb_id, 'tmdb': tmdb_id, 'content': 'movies', 'select': '2'}
        poster = IMG + 'w500' + r['poster_path'] if r.get('poster_path') else ''
        fanart = IMG + 'w1280' + r['backdrop_path'] if r.get('backdrop_path') else ''
        rows.append({
            'file': 'plugin://plugin.video.thecrew/?' + urllib.parse.urlencode(params),
            'label': f'{title} ({year})' if year else title,
            'title': title,
            'plot': r.get('overview') or '',
            'year': int(year) if year.isdigit() else 0,
            'premiered': date,
            'imdb': imdb_id,
            'genre': '',
            'mpaa': '',
            'runtime': 0,
            'playcount': 0,
            'thumbnail': poster,
            'fanart': fanart,
            'poster': poster,
            'folder': kind == 'tv',
        })
    return rows
