# -*- coding: utf-8 -*-
"""
AntiVenom Sports Engine & Display Sanitizer for Mad Titan Sports
Eliminates scraper garbage (separators, duplicate refresh buttons, dead memes),
substitutes official TMDB high-definition artwork for broken scraper thumbnails,
and formats league cards with pristine typography.
"""
from ..plugin import Plugin
from xbmcplugin import addDirectoryItems, endOfDirectory, setContent, addSortMethod, SORT_METHOD_NONE, SORT_METHOD_LABEL
from ..DI import DI
import sys
import re
import time
import datetime

route_plugin = DI.plugin

# Curated High-Definition TMDB Artwork Map (Official Permanent CDN)
WRESTLING_ART_MAP = {
    'raw': {
        'title': 'WWE Monday Night Raw',
        'poster': 'https://image.tmdb.org/t/p/w500/f6xIVdQeAKVL8qZR1500MKUTtLe.jpg',
        'fanart': 'https://image.tmdb.org/t/p/original/90ceOXlFWCsqwk9W1dW0Ou4wPGn.jpg'
    },
    'smackdown': {
        'title': 'WWE Friday Night SmackDown',
        'poster': 'https://image.tmdb.org/t/p/w500/oOiGZPiQUaIfajBSZMqC9pGUqsy.jpg',
        'fanart': 'https://image.tmdb.org/t/p/original/A8pQdnIkBG9LGkwGCZOciOM20r.jpg'
    },
    'nxt': {
        'title': 'WWE NXT',
        'poster': 'https://image.tmdb.org/t/p/w500/9nLBX5Bf7PW4FAaWJLXpFFdeTlV.jpg',
        'fanart': 'https://image.tmdb.org/t/p/original/YaQ8YhHYpLkH3e7FRwBkcGoJhS.jpg'
    },
    'dynamite': {
        'title': 'AEW Dynamite',
        'poster': 'https://image.tmdb.org/t/p/w500/2xAAC0Hwm9yxMn9ukgglfIuABc1.jpg',
        'fanart': 'https://image.tmdb.org/t/p/original/veIrzS2AkYm0UaYYcVw9ziWkJoB.jpg'
    },
    'collision': {
        'title': 'AEW Collision',
        'poster': 'https://image.tmdb.org/t/p/w500/3BjRrrvmL9TuiOfvvKgeHDURuuW.jpg',
        'fanart': 'https://image.tmdb.org/t/p/original/6fbzFk1fTE8I8UEYn9hG9dUo8jh.jpg'
    },
    'rampage': {
        'title': 'AEW Rampage',
        'poster': 'https://image.tmdb.org/t/p/w500/itLcy79zMVU9K4OTU4h8I61nPJi.jpg',
        'fanart': 'https://image.tmdb.org/t/p/original/qk852jxQzofuvvWRc5fATSh4NOc.jpg'
    },
    'roh': {
        'title': 'ROH Ring of Honor',
        'poster': 'https://image.tmdb.org/t/p/w500/kvLS3nd5YBpwIeFsdlHCffUhl3b.jpg',
        'fanart': 'https://image.tmdb.org/t/p/original/faB96g5FQ2PysSjDCjVpakuOXk.jpg'
    },
    'njpw': {
        'title': 'NJPW New Japan Pro-Wrestling',
        'poster': 'https://image.tmdb.org/t/p/w500/c6IZc3avqSgTzSXrrj9vV0EwRp.jpg',
        'fanart': 'https://image.tmdb.org/t/p/original/zcQRmnySOmVqT6WRmdztbiA9vVk.jpg'
    },
    'impact': {
        'title': 'TNA / Impact Wrestling',
        'poster': 'https://image.tmdb.org/t/p/w500/jpyxrPBjIaJ2UgYSl5RmjkMb8Jg.jpg',
        'fanart': 'https://image.tmdb.org/t/p/original/tV8Jw34xC4yubgYSCVKSVuhxm73.jpg'
    }
}

MOTORSPORT_ART_MAP = (
    (('nascar', 'cup series', 'xfinity', 'truck series', 'daytona', 'talladega'), 'nascar.png'),
    (('formula 1', 'formula one', 'grand prix', 'paddock'), 'formula1.png'),
    (('motogp', 'moto2', 'moto3', 'superbike'), 'motogp.png'),
    (('rally', 'wrc', 'stage '), 'rally.png'),
    (('sportscar', 'sports car', 'imsa', 'michelin raceway', 'endurance'), 'sportscar.png'),
    (('motorsport', 'motor sports', 'racing'), 'motorsport.png'),
)

SECTION_RENAME_MAP = {
    'new section': 'MLB Extra Innings',
    'new section2': 'NBA League Pass',
    'new section3': 'NFL Sunday Ticket',
    'new section4': 'NHL Centre Ice'
}

DEAD_IMAGE_HOSTS = (
    'watchprowrestling.org',
    'watchwrestlingup.live',
    'encrypted-tbn0.gstatic.com',
    'deadline.com',
    'sports_schedule_test/icons/sports_icon.png'
)

JUNK_KEYWORDS = (
    'refresh link',
    'previous search results',
    'watch wrestling live and replays',
    'please no reviews or uploads',
    'or any other social media',
    'clear slow scrapers',
    'search titan categories',
    'search by team or event',
    '2 widget test'
)


class display(Plugin):
    name = "display"

    # weekday (Mon=0), start hour ET, duration hours
    WRESTLING_AIR = {
        'raw': (0, 20, 4),
        'nxt': (1, 20, 3),
        'dynamite': (2, 20, 3),
        'smackdown': (4, 20, 3),
        'collision': (5, 20, 3),
        'rampage': (4, 22, 2),
        'impact': (3, 20, 3),
        'roh': (3, 19, 3),
    }

    def _wrestling_air_status(self, key):
        """LIVE / UPCOMING for weekly wrestling cards using Eastern time."""
        window = self.WRESTLING_AIR.get(key)
        if not window:
            return ''
        weekday, start_hour, duration = window
        now_et = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-4)))
        start = now_et.replace(hour=start_hour, minute=0, second=0, microsecond=0)
        days_ahead = (weekday - now_et.weekday()) % 7
        start = start + datetime.timedelta(days=days_ahead)
        if days_ahead == 0 and now_et.hour < start_hour and now_et < start:
            pass
        elif days_ahead == 0 and now_et >= start + datetime.timedelta(hours=duration):
            start = start + datetime.timedelta(days=7)
        end = start + datetime.timedelta(hours=duration)
        if start <= now_et <= end:
            return 'LIVE NOW'
        return 'UPCOMING'

    def _expected_duration(self, title):
        """Conservative event windows used only when a feed has no precise end state."""
        text = (title or "").lower()
        if any(term in text for term in ('ufc', 'mma', 'boxing', 'wrestling', 'wwe')):
            return 5 * 60 * 60
        if any(term in text for term in ('nfl', 'ncaaf', 'football', 'mlb', 'baseball', 'nascar', 'formula', 'f1', 'motogp')):
            return 4 * 60 * 60
        if any(term in text for term in ('soccer', 'epl', 'fifa')):
            return int(2.5 * 60 * 60)
        return 3 * 60 * 60

    def _parse_time_part(self, tp):
        if not tp:
            return 0
        try:
            m = re.search(r'(\d{1,2})/(\d{1,2})\s+(\d{1,2}):(\d{2})\s*(AM|PM)?(?:\s*([A-Z]{3}))?', tp, re.IGNORECASE)
            if not m:
                return 0
            month, day, hour, minute, ampm, tz = m.groups()
            month, day, hour, minute = int(month), int(day), int(hour), int(minute)
            if ampm:
                ampm = ampm.upper()
                if ampm == 'PM' and hour < 12:
                    hour += 12
                elif ampm == 'AM' and hour == 12:
                    hour = 0
            current = datetime.datetime.now()
            year = current.year
            if current.month >= 11 and month <= 2:
                year += 1
            elif current.month <= 2 and month >= 11:
                year -= 1
            offsets = {
                'UTC': 0, 'GMT': 0,
                'EST': -5, 'EDT': -4,
                'CST': -6, 'CDT': -5,
                'MST': -7, 'MDT': -6,
                'PST': -8, 'PDT': -7,
            }
            tz_offset = datetime.timezone(datetime.timedelta(hours=offsets.get((tz or 'EDT').upper(), -4)))
            dt = datetime.datetime(year, month, day, hour, minute, tzinfo=tz_offset)
            return dt.timestamp()
        except Exception:
            return 0

    def _clean_and_filter_item(self, item):
        if not item or not isinstance(item, dict):
            return None

        link = item.get("link", "")
        if isinstance(link, list):
            if not link or link == ['#'] or link == ['']:
                return None
            link_str = str(link[0])
        else:
            link_str = str(link)

        if not link_str or link_str.strip() in ('', '#', 'ignore'):
            return None
        if 'refresh_menu' in link_str.lower() or 'clear_cache' in link_str.lower():
            return None

        # Extract title from item or list_item
        raw_title = item.get("title") or item.get("name") or ""
        list_item = item.get("list_item")
        if not raw_title and list_item:
            try:
                raw_title = list_item.getLabel()
            except Exception:
                raw_title = ""

        # Strip BBCode color tags and formatting
        clean_title = re.sub(r'\[/?(?:COLOR|B|I)[^\]]*\]', '', raw_title, flags=re.IGNORECASE).strip()
        # Thoroughly sanitize unrenderable emojis, flags, and symbols that turn into [?] boxes in Kodi
        clean_title = re.sub(r'[\U00010000-\U0010ffff\u2600-\u26ff\u2700-\u27bf\ufe00-\ufe0f\u200d\u20e3\u25a0-\u25ff\u2190-\u21ff]', '', clean_title).strip()
        if not clean_title or clean_title.startswith('---') or clean_title.startswith('===') or clean_title.startswith('***'):
            return None

        clean_lower = clean_title.lower()
        if any(kw in clean_lower for kw in JUNK_KEYWORDS):
            return None
        # Drop date header separators (e.g. Schedule 09-29, Schedule 10-01)
        if re.search(r'schedule\s*\d{1,2}[-/]\d{1,2}', clean_lower):
            return None

        # Check section rename mapping
        if clean_lower in SECTION_RENAME_MAP:
            clean_title = SECTION_RENAME_MAP[clean_lower]
            clean_lower = clean_title.lower()

        # Check curated artwork mapping (wrestling shows)
        matched = None
        matched_key = ''
        for key, info in WRESTLING_ART_MAP.items():
            if key in clean_lower:
                if key == 'raw' and 'smackdown' in clean_lower:
                    continue
                matched = info
                matched_key = key
                break

        motorsport_art = ""
        for keywords, filename in MOTORSPORT_ART_MAP:
            if any(keyword in clean_lower for keyword in keywords):
                motorsport_art = (
                    'special://home/addons/script.antivenom/'
                    f'resources/media/motorsport/{filename}'
                )
                break

        final_title = clean_title
        poster = item.get("thumbnail") or ""
        fanart = item.get("fanart") or ""
        if motorsport_art:
            poster = motorsport_art
            fanart = motorsport_art

        # Status evaluation: LIVE NOW, UPCOMING, REPLAY, or 24/7 CHANNEL
        now = time.time()
        order_weight = 5  # 1: LIVE NOW, 2: UPCOMING, 3: CHANNEL, 4: FINAL/REPLAY, 5: OTHER
        status_label = ""
        time_part = ""
        match_part = clean_title

        is_channel = (
            any(net in clean_lower for net in (
                'network', 'redzone', 'channel', '24/7', 'league pass',
                'centre ice', 'sunday ticket', 'sky sports'
            ))
            or bool(re.search(r'\b(?:ESPN|FS1|FS2|TNT|TBS|NBA TV|MLB TV|NHL TV)\b', clean_title, re.IGNORECASE))
        )
        is_explicit_replay = any(term in clean_lower for term in (
            'replay', 'full match', 'full fight', 'full race', 'watch wrestling'
        ))
        is_live_schedule = bool(re.search(r'\d{1,2}/\d{1,2}\s+\d{1,2}:\d{2}', clean_title))

        if '|' in clean_title:
            parts = [p.strip() for p in clean_title.split('|') if p.strip()]
            if len(parts) >= 3:
                time_part = parts[1].replace('-EST', ' EST').replace('-EDT', ' EDT').strip()
                match_part = parts[2].replace('vs', '@').strip()
            elif len(parts) == 2:
                time_part = parts[0].replace('-EST', ' EST').replace('-EDT', ' EDT').strip()
                match_part = parts[1].replace('vs', '@').strip()
        elif ' - ' in clean_title:
            parts = [p.strip() for p in clean_title.split(' - ') if p.strip()]
            if len(parts) >= 2:
                if re.search(r'\d{1,2}/\d{1,2}', parts[1]):
                    time_part = parts[1].strip()
                    match_part = parts[0].replace('vs', '@').strip()
                elif re.search(r'\d{1,2}/\d{1,2}', parts[0]):
                    time_part = parts[0].strip()
                    match_part = parts[1].replace('vs', '@').strip()

        # Strip sports league prefix e.g. "NFL : " or "MLB : "
        match_part = re.sub(r'^(?:NFL|MLB|NBA|NHL|CFB|NCAAF|MLS|EPL)\s*:\s*', '', match_part, flags=re.IGNORECASE).strip()
        match_part = re.sub(r'\s{2,}', ' ', match_part).strip()

        # Check guidedata for exact start time & duration (3 hours default)
        guidedata = item.get("guidedata")
        start_ts = 0
        dur_ts = self._expected_duration(clean_title)
        if guidedata and isinstance(guidedata, list) and len(guidedata) > 0 and isinstance(guidedata[0], dict):
            try:
                start_ts = float(guidedata[0].get("starttime", 0) or 0)
            except (TypeError, ValueError):
                start_ts = 0
            try:
                feed_duration = float(guidedata[0].get("duration", 0) or 0)
                if feed_duration > 86400:
                    feed_duration /= 1000.0
                if feed_duration > 0:
                    dur_ts = max(dur_ts, feed_duration)
            except (TypeError, ValueError):
                pass

        if start_ts == 0 and time_part:
            start_ts = self._parse_time_part(time_part)

        if is_channel and not is_live_schedule:
            order_weight = 3
            status_label = "24/7 CHANNEL"
            final_title = f"[COLOR #00F5A0][B]24/7 CHANNEL[/B][/COLOR] | {clean_title}"
        elif start_ts > 0:
            if now < start_ts:
                order_weight = 2
                status_label = "UPCOMING"
                final_title = f"[COLOR #FFFFCC00][B]UPCOMING ({time_part or 'Tonight'})[/B][/COLOR] | {match_part}"
            elif start_ts <= now <= (start_ts + dur_ts):
                order_weight = 1
                status_label = "LIVE NOW"
                final_title = f"[B][COLOR #00FF55]LIVE NOW[/COLOR][/B] | [B]{match_part}[/B]"
            else:
                order_weight = 4
                if is_explicit_replay:
                    status_label = "REPLAY"
                    final_title = f"[COLOR #FFAA00][B]REPLAY ({time_part or 'Available'})[/B][/COLOR] | {match_part}"
                else:
                    status_label = "FINAL"
                    final_title = f"[COLOR gray][B]FINAL ({time_part or 'Ended'})[/B][/COLOR] | {match_part}"
        elif is_live_schedule and time_part:
            order_weight = 2
            status_label = "SCHEDULED"
            final_title = f"[COLOR #FFFFCC00][B]UPCOMING ({time_part})[/B][/COLOR] | {match_part}"
        elif matched:
            item['_replay_key'] = matched_key
            air = self._wrestling_air_status(matched_key)
            replay_title = matched['title']
            poster = matched['poster']
            fanart = matched['fanart']
            dated = re.search(r'\d{1,2}/\d{1,2}(?:/\d{2,4})?', clean_title)
            in_replay_list = 'DIRECTREPLAY' in str(item.get('link') or '').upper()
            if dated or in_replay_list:
                order_weight = 4
                status_label = "REPLAY"
                final_title = f"[COLOR #FFAA00][B]REPLAY[/B][/COLOR] | {clean_title}"
            elif air == 'LIVE NOW':
                order_weight = 1
                status_label = "LIVE NOW"
                final_title = f"[B][COLOR #00FF55]LIVE NOW[/COLOR][/B] | [B]{replay_title}[/B]"
            else:
                order_weight = 4
                status_label = "REPLAY"
                final_title = f"[COLOR #FFAA00][B]REPLAY[/B][/COLOR] | {replay_title}"
        elif is_explicit_replay:
            order_weight = 4
            status_label = "REPLAY"
            final_title = f"[COLOR #FFAA00][B]REPLAY[/B][/COLOR] | {clean_title}"
        else:
            final_title = clean_title

        # Reliable fallbacks for missing artwork
        if not poster or any(dead in poster for dead in DEAD_IMAGE_HOSTS):
            if matched:
                poster = matched['poster']
                fanart = matched['fanart']
            else:
                poster = 'https://image.tmdb.org/t/p/w500/f6xIVdQeAKVL8qZR1500MKUTtLe.jpg'
                if not fanart:
                    fanart = 'https://image.tmdb.org/t/p/original/90ceOXlFWCsqwk9W1dW0Ou4wPGn.jpg'

        if list_item:
            try:
                list_item.setLabel(final_title)
                status_color_label = status_label
                if status_label == "LIVE NOW":
                    status_color_label = "[B][COLOR #00FF55]LIVE NOW[/COLOR][/B]"
                elif status_label == "UPCOMING":
                    status_color_label = "[B][COLOR #FFFFCC00]UPCOMING[/COLOR][/B]"
                elif status_label == "REPLAY":
                    status_color_label = "[B][COLOR #FFAA00]REPLAY / FINAL[/COLOR][/B]"
                elif status_label == "FINAL":
                    status_color_label = "[B][COLOR gray]FINAL[/COLOR][/B]"
                elif status_label == "24/7 CHANNEL":
                    status_color_label = "[B][COLOR #00F5A0]24/7 CHANNEL[/COLOR][/B]"

                # Pristine plot / description for details side-panel without broken [?] characters
                clean_plot = f"[B]Status:[/B] {status_color_label}\n[B]Event:[/B] {match_part}"
                if time_part:
                    clean_plot += f"\n[B]Scheduled Time:[/B] {time_part}"
                list_item.setInfo('video', {'plot': clean_plot, 'title': final_title})
                art = {}
                if poster:
                    art.update({"thumb": poster, "icon": poster, "poster": poster})
                if fanart:
                    art["fanart"] = fanart
                if art:
                    list_item.setArt(art)
            except Exception:
                pass

        item["title"] = final_title
        item["_status_label"] = status_label
        item["_status_time"] = time_part
        item["_status_match"] = match_part
        item["_order_weight"] = order_weight
        return item

    def display_list(self, jen_list):
        if not jen_list:
            endOfDirectory(route_plugin.handle)
            return True

        cleaned_items = []
        for item in jen_list:
            c = self._clean_and_filter_item(item)
            if c is not None:
                cleaned_items.append(c)

        # Sort items: 1. LIVE NOW (top) -> 2. UPCOMING -> 3. 24/7 CHANNELS -> 4. REPLAYS
        cleaned_items.sort(key=lambda x: x.get("_order_weight", 2))

        display_list = []
        for item in cleaned_items:
            status = item.get("_status_label", "")
            link_blob = str(item.get('link') or '')
            if status == "REPLAY" and 'DIRECTREPLAY' not in link_blob.upper():
                replay_files = {
                    'raw': 'Replays_WWE.json',
                    'smackdown': 'Replays_WWE.json',
                    'nxt': 'Replays_NXT.json',
                    'dynamite': 'Replays_AEW.json',
                    'rampage': 'Replays_AEW.json',
                    'collision': 'Replays_AEW.json',
                    'impact': 'TNA.json',
                    'roh': 'Replays_ROH.json',
                    'njpw': 'newjapanwrestling.json',
                }
                replay_file = replay_files.get(item.get('_replay_key') or '', 'Replays_WWE.json')
                target = (
                    'plugin://plugin.video.madtitansports/get_list/'
                    'https://magnetic.website/MAD_TITAN_SPORTS/SPORTS/DIRECTREPLAY/DEBRID/'
                    + replay_file
                )
                is_dir = True
            elif status in ("UPCOMING", "SCHEDULED"):
                import urllib.parse
                query = urllib.parse.urlencode({
                    "action": "sports_status_notice",
                    "status": status,
                    "title": item.get("_status_match", item.get("title", "")),
                    "time": item.get("_status_time", ""),
                })
                target = f"plugin://script.antivenom/?{query}"
                is_dir = False
            else:
                target = route_plugin.url_for_path(item["link"])
                is_dir = item["is_dir"]
            display_list.append((target, item["list_item"], is_dir))
        addDirectoryItems(route_plugin.handle, display_list, len(display_list))
        addSortMethod(route_plugin.handle, SORT_METHOD_NONE)
        addSortMethod(route_plugin.handle, SORT_METHOD_LABEL)
        setContent(int(sys.argv[1]), 'videos')
        endOfDirectory(route_plugin.handle)
        return True
