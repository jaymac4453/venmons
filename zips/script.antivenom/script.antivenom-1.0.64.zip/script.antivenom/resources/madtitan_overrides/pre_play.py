from ..plugin import Plugin
import xbmc
import xbmcaddon
import xbmcgui
import json
import re
import urllib.request

from .password import Password

try:
    from resources.lib.util.common import *
except ImportError:
    from .resources.lib.util.common import *


addon_id = xbmcaddon.Addon().getAddonInfo('id')
default_icon = xbmcaddon.Addon(addon_id).getAddonInfo('icon')
default_fanart = xbmcaddon.Addon(addon_id).getAddonInfo('fanart')

# Hosts that hang Kodi or have no working extractor in this Jetextractors build.
KNOWN_BAD_HOSTS = (
    'mmastreams.me',
    'mytv.fun',
    'daddylive.dad',
    'daddylive.sx',
    'daddylivehd',
    'dlhd.dad',
)

# Direct playlists from this host time out. Try them only after a working channel link.
LAST_RESORT_HOSTS = (
    'firebase-api.com',
    'android-database5',
)

# Already-resolved HLS CDNs that play without Jetextractors.
DIRECT_HLS_HOSTS = (
    'salamus',
    'webudit',
    'onlinewebtv',
    'ddy1.',
    'ntuplay',
    'premiumtv',
)

MENU_ROUTES = (
    '/cache_dialog/',
    '/search_dialog/',
    '/search_json/',
    '/search_music/',
)


def _remove_display_name(link):
    value = str(link or '').strip()
    if value.endswith(')') and '(' in value:
        return value.rsplit('(', 1)[0].strip()
    return value


def _dlhd_id(link):
    match = re.search(r'watch\.php\?id=(\d+)', str(link or ''), re.I)
    return match.group(1) if match else ''


def _channel_for_link(link, channels):
    wanted = _dlhd_id(link)
    if not wanted:
        return None
    for channel in channels or []:
        if _dlhd_id(channel.get('channel_id') or '') == wanted:
            return channel
    return None


def _plain_title(item):
    text = f"{item.get('title') or ''} {item.get('group') or ''}"
    text = re.sub(r'\[/?(?:COLOR|B|I)[^\]]*\]', '', text, flags=re.I)
    return text.lower()


def _is_wrestling_item(item):
    title = _plain_title(item or {})
    return any(word in title for word in (
        'wwe', 'smackdown', 'nxt', 'aew', 'dynamite', 'rampage', 'collision',
        'roh', 'impact', 'njpw', 'wrestling',
    ))


def _wrestling_channel_ok(title, channel_name):
    name = (channel_name or '').lower()
    if not name:
        return False
    if 'nxt' in title:
        hints = ('cw', 'nxt')
    elif 'smackdown' in title:
        hints = ('fox', 'fs1', 'smack')
    elif 'raw' in title:
        hints = ('usa network', 'raw')
    elif any(word in title for word in ('dynamite', 'rampage', 'collision', 'aew')):
        hints = ('tbs', 'tnt', 'aew')
    elif 'roh' in title:
        hints = ('roh', 'honor', 'tnt')
    elif 'impact' in title or 'tna' in title:
        hints = ('impact', 'tna', 'axs')
    elif 'njpw' in title:
        hints = ('njpw', 'new japan')
    else:
        hints = ('wwe', 'aew', 'tnt', 'tbs')
    return any(hint in name for hint in hints)


def _is_nfl_item(item):
    text = (_plain_title(item or {}) + ' ' + str((item or {}).get('league') or '')).lower()
    return 'nfl' in text or 'sunday ticket' in text


CREW_BACKUP = (
    (('smackdown', 'monday night raw', ' nxt', 'aew', 'dynamite', 'rampage', 'collision', 'wrestling', 'wwe', ' roh', 'impact', 'njpw'), 'wwe'),
    (('nfl', 'sunday ticket'), 'nfl'),
    (('mlb', 'baseball'), 'mlb'),
    (('nba', 'basketball'), 'nba'),
    (('nhl', 'hockey'), 'nhl'),
    (('ncaaf', 'ncaa', 'college football'), 'ncaa'),
    (('ncaab', 'college basketball'), 'ncaab'),
    (('ufc', 'mma'), 'ufc'),
    (('boxing',), 'boxing'),
    (('nascar',), 'nascar'),
    (('formula', 'f1', 'motogp', 'motorsport'), 'f1'),
    (('epl', 'premier league', 'soccer', 'fifa', 'mls'), 'fifa'),
)


def _crew_backup_action(item):
    text = ' ' + _plain_title(item or {}) + ' ' + str((item or {}).get('league') or '').lower()
    for words, action in CREW_BACKUP:
        if any(word in text for word in words):
            return action
    return 'bluehat'


def _sport_rank(link, item):
    """Exclusive feed first. Scraper links are only the backup."""
    lower = (link or '').lower()
    if not lower or any(route in lower for route in MENU_ROUTES):
        return 90
    # Numbered DaddyLive slots are live TV, not the event.
    # /slate/ playlists download, then every video segment fails.
    if any(host in lower for host in ('daddylive.dad', 'daddylive.sx', 'daddylivehd', 'dlhd.dad', 'mytv.fun')) or '/slate/' in lower:
        return 100
    if any(host in lower for host in ('warnermediacdn.com', 'akamaized.net', 'njpwworld', 'ntuplay', 'ddy1.', 'premiumtv', 'salamus', 'webudit', 'onlinewebtv')):
        return 1
    if ('.m3u8' in lower or '.mpd' in lower or lower.startswith('is_hls://')) and not any(host in lower for host in LAST_RESORT_HOSTS):
        return 2
    if lower.startswith(('jetproxy://', 'ffmpegdirect://', 'direct://')):
        return 3
    channel = _channel_for_link(link, (item or {}).get('channels') or [])
    if channel:
        name = channel.get('channel_name') or ''
        if _is_wrestling_item(item) and _wrestling_channel_ok(_plain_title(item), name):
            return 8
        if _is_nfl_item(item):
            return _nfl_channel_rank(name)
    if 'sportjetextractors/' in lower or 'mmastreams' in lower or 'strikeout' in lower:
        return 40
    if any(host in lower for host in LAST_RESORT_HOSTS):
        return 75
    if any(host in lower for host in KNOWN_BAD_HOSTS):
        return 100
    if lower.startswith('plugin://'):
        return 45
    if lower.startswith(('http://', 'https://')):
        return 6
    return 80


def _nfl_channel_rank(name):
    """Named NFL feeds before generic Sunday Ticket and non-NFL networks."""
    label = (name or '').lower()
    # Sunday Ticket id 1 was a soccer feed mislabeled as the NFL game.
    if 'sunday ticket' in label:
        return 58
    if 'nfl' in label and 'mix' not in label:
        return 12
    if 'main event' in label:
        return 18
    if label.startswith('tsn'):
        return 22
    if any(word in label for word in ('bein', 'arena sport', 'sportv', 'cosmote', 'sport 5', 'rtl')):
        return 78
    if 'mix' in label:
        return 65
    return 70


def _source_rank(link):
    """Lower ranks play first. Direct HLS beats Jetextractor pages."""
    lower = link.lower()
    if not link or any(host in lower for host in KNOWN_BAD_HOSTS):
        return 100
    if any(host in lower for host in LAST_RESORT_HOSTS):
        return 75
    if any(route in lower for route in MENU_ROUTES):
        return 90
    if 'sportjetextractors/' in lower:
        return 70
    if any(host in lower for host in DIRECT_HLS_HOSTS) and ('.m3u8' in lower or lower.startswith('is_hls://')):
        return 0
    if lower.startswith('is_hls://') or '.m3u8' in lower or '.mpd' in lower:
        return 1
    if lower.startswith(('jetproxy://', 'ffmpegdirect://', 'direct://')):
        return 2
    if lower.startswith('plugin://'):
        return 5
    if lower.startswith(('http://', 'https://')):
        return 7
    return 80


def _event_rank(link, item):
    return _sport_rank(link, item)


def _http_url(link):
    value = str(link or '')
    if value.lower().startswith('is_hls://'):
        value = value[9:]
    return value.split('|', 1)[0]


def _looks_alive(link, timeout=2.5):
    """Fail fast on dead HTTP manifests so playback never sits on a 15s curl timeout."""
    probe = link
    if probe.lower().startswith('is_hls://'):
        probe = probe[9:]
    if not probe.lower().startswith(('http://', 'https://')):
        return True
    url = probe.split('|', 1)[0]
    headers = {'User-Agent': 'Mozilla/5.0'}
    if '|' in probe:
        for part in probe.split('|', 1)[1].split('&'):
            if '=' not in part:
                continue
            key, value = part.split('=', 1)
            if key.lower() in ('user-agent', 'referer'):
                headers[key] = value
    try:
        req = urllib.request.Request(url, headers=headers, method='GET')
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = getattr(resp, 'status', 200) or 200
            if status >= 400:
                return False
            return bool(resp.read(64))
    except Exception:
        return False


class pre_player(Plugin):
    name = "process lists of links"
    priority = 200

    def pre_play(self, item):
        item = json.loads(item)
        links = item.get("link", "")
        play_link = ""

        if isinstance(links, list):
            candidates = []
            for index, raw_link in enumerate(links):
                cleaned = _remove_display_name(raw_link)
                candidates.append((_event_rank(cleaned, item), index, cleaned))

            usable = [candidate for candidate in candidates if candidate[0] < 80]
            usable.sort(key=lambda candidate: (candidate[0], candidate[1]))
            for rank, index, candidate in usable:
                probe = candidate
                if probe.lower().startswith('is_hls://'):
                    probe = probe[9:]
                if probe.lower().startswith(('http://', 'https://')):
                    if not _looks_alive(probe):
                        xbmc.log(
                            f"[AntiVenom Sports] Skipping dead source {index + 1}/{len(links)}: "
                            f"{_http_url(candidate)[:90]}",
                            xbmc.LOGINFO,
                        )
                        continue
                play_link = candidate
                channel = _channel_for_link(candidate, item.get('channels') or [])
                channel_name = (channel or {}).get('channel_name') or ''
                xbmc.log(
                    f"[AntiVenom Sports] Auto-selected source {index + 1}/{len(links)} "
                    f"(rank={rank}) {channel_name} for {item.get('title', 'event')}",
                    xbmc.LOGINFO,
                )
                break
        else:
            play_link = str(links or "")
            if play_link and _event_rank(play_link, item) >= 80:
                play_link = ""

        if not play_link:
            backup = _crew_backup_action(item)
            xbmcgui.Dialog().notification(
                'AntiVenom',
                'Exclusive feed missed. Opening scraper backup.',
                xbmcgui.NOTIFICATION_INFO,
                3000,
            )
            xbmc.executebuiltin(
                f'ActivateWindow(Videos,plugin://plugin.video.thecrew/?action={backup},return)'
            )
            # Return empty link JSON so Mad Titan does not fall back to DaddyLive/Jetextractors.
            item['link'] = ''
            return json.dumps(item)

        if play_link.startswith("password//"):
            if not Password().password_check():
                return
            play_link = play_link.replace("password//", "", 1)

        if play_link.lower().startswith("is_hls://"):
            play_link = play_link[len("is_hls://"):]

        item["link"] = play_link
        return json.dumps(item)
