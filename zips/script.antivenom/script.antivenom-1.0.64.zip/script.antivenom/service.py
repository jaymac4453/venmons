# -*- coding: utf-8 -*-
"""
AntiVenom Background Service
Ensures AntiVenom skin is always active and Real-Debrid authorization is permanently remembered.
Includes automatic multi-location vault redundancy and seamless OAuth token refresh.
"""
import xbmc
import xbmcgui
import xbmcvfs
import os
import time
import shutil
import json
import urllib.request
import urllib.parse
import urllib.error
import xml.etree.ElementTree as ET

RD_KEYS = [
    'RealDebridResolver_token',
    'RealDebridResolver_refresh',
    'RealDebridResolver_client_id',
    'RealDebridResolver_client_secret',
    'RealDebridResolver_enabled',
    'RealDebridResolver_login',
    'RealDebridResolver_torrents',
    'RealDebridResolver_priority',
    'RealDebridResolver_cached_only'
]

def _import_default():
    import sys as _sys
    addon_path = xbmcvfs.translatePath('special://home/addons/script.antivenom/')
    if addon_path not in _sys.path:
        _sys.path.insert(0, addon_path)
    import default as av_default
    return av_default


def ensure_skin_active():
    """Repair the installed skin from the bundled copy (no deletes), then switch to it via JSON-RPC only."""
    try:
        av = _import_default()
        skin_dest = av.SKIN_DEST
        if os.path.isdir(av.SKIN_SRC):
            if not os.path.isdir(skin_dest):
                try:
                    shutil.copytree(av.SKIN_SRC, skin_dest)
                    xbmc.log('[AntiVenom] Service deployed skin.antivenom to addons folder', xbmc.LOGINFO)
                except OSError as e:
                    xbmc.log(f'[AntiVenom] Service copytree failed ({e}); trying in-place sync', xbmc.LOGWARNING)
                    if os.path.exists(skin_dest):
                        av.sync_installed_skin()
            elif av.critical_skin_missing():
                repaired = av.sync_installed_skin()
                if repaired:
                    xbmc.log(f'[AntiVenom] Service repaired {repaired} missing skin file(s)', xbmc.LOGINFO)
            # else: dest exists and critical files are present — skip the full-tree walk

        current_skin = xbmc.getSkinDir()
        xbmc.log(f'[AntiVenom] Service: active skin is {current_skin}', xbmc.LOGINFO)
        if current_skin != 'skin.antivenom':
            xbmc.log('[AntiVenom] Service: switching to AntiVenom skin...', xbmc.LOGINFO)
            av.activate_skin()
    except Exception as e:
        xbmc.log(f'[AntiVenom] Service skin activation error: {e}', xbmc.LOGWARNING)


def ensure_device_tuning():
    """Deploy cache settings if missing and cap The Crew on weak sticks. Safe to run every boot."""
    try:
        av = _import_default()
        adv = xbmcvfs.translatePath('special://masterprofile/advancedsettings.xml')
        if not os.path.isfile(adv):
            av.configure_advancedsettings()
            xbmc.log('[AntiVenom] Deployed advancedsettings.xml (was missing); applies after restart', xbmc.LOGINFO)
        from resources.lib import deviceprofile
        xbmc.log(f'[AntiVenom] Device: {deviceprofile.describe()}', xbmc.LOGINFO)
        deviceprofile.sync_crew_profile(debrid_linked=has_debrid_credentials())
    except Exception as e:
        xbmc.log(f'[AntiVenom] Device tuning error: {e}', xbmc.LOGWARNING)

def get_vault_paths():
    """Return all primary, secondary, and external device vault paths."""
    paths = [
        xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/rd_vault.json'),
        xbmcvfs.translatePath('special://masterprofile/rd_vault.json'),
        xbmcvfs.translatePath('special://home/rd_vault.json')
    ]
    # FireStick & Android persistent storage paths (survives Kodi cache clear/reinstall)
    for p in [
        '/sdcard/AntiVenom_rd_vault.json',
        '/storage/emulated/0/AntiVenom_rd_vault.json',
        '/sdcard/Android/data/org.xbmc.kodi/files/rd_vault.json'
    ]:
        try:
            parent = os.path.dirname(p)
            if os.path.exists(parent):
                paths.append(p)
        except Exception:
            pass
    return paths

def read_vault_credentials():
    """Read saved credentials from any available vault file."""
    for vp in get_vault_paths():
        try:
            if os.path.isfile(vp):
                with open(vp, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                if data.get('RealDebridResolver_token') or data.get('RealDebridResolver_refresh'):
                    return data
        except Exception:
            pass
    return None

def write_vault_credentials(creds):
    """Write credentials to all accessible vault locations for permanent persistence."""
    for vp in get_vault_paths():
        try:
            os.makedirs(os.path.dirname(vp), exist_ok=True)
            with open(vp, 'w', encoding='utf-8') as f:
                json.dump(creds, f, indent=4)
        except Exception:
            pass

def check_and_refresh_token(creds):
    """
    Checks token validity. If expired (401), automatically uses OAuth refresh_token
    to acquire a brand new token without prompting the user.
    """
    token = creds.get('RealDebridResolver_token')
    refresh = creds.get('RealDebridResolver_refresh')
    client_id = creds.get('RealDebridResolver_client_id', '763AE7OFYINMA')
    client_secret = creds.get('RealDebridResolver_client_secret', 'fbd4ae9583b0bca261644ef66534ebaa8ca481b7')

    if not token and not refresh:
        return creds, False

    need_refresh = False
    if token:
        try:
            req = urllib.request.Request(
                'https://api.real-debrid.com/rest/1.0/user',
                headers={'Authorization': f'Bearer {token}', 'User-Agent': 'AntiVenom/4.0'}
            )
            with urllib.request.urlopen(req, timeout=4) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode('utf-8'))
                    username = data.get('username', 'Active User')
                    xbmc.executebuiltin(f'Skin.SetString(RealDebridUser,{username})')
                    return creds, False
        except urllib.error.HTTPError as e:
            if e.code == 401:
                need_refresh = True
            else:
                return creds, False
        except Exception:
            return creds, False
    else:
        need_refresh = True

    if need_refresh and refresh:
        try:
            post_data = urllib.parse.urlencode({
                'client_id': client_id,
                'client_secret': client_secret,
                'code': refresh,
                'grant_type': 'http://oauth.net/grant_type/device/1.0'
            }).encode('utf-8')
            req = urllib.request.Request(
                'https://api.real-debrid.com/oauth/v2/token',
                data=post_data,
                headers={'User-Agent': 'AntiVenom/4.0'}
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                new_token = res.get('access_token')
                new_refresh = res.get('refresh_token') or refresh
                if new_token:
                    creds['RealDebridResolver_token'] = new_token
                    creds['RealDebridResolver_refresh'] = new_refresh
                    creds['RealDebridResolver_client_id'] = client_id
                    creds['RealDebridResolver_client_secret'] = client_secret
                    creds['RealDebridResolver_enabled'] = 'true'
                    creds['RealDebridResolver_login'] = 'true'
                    creds['RealDebridResolver_torrents'] = 'true'
                    creds['RealDebridResolver_cached_only'] = 'false'
                    creds['RealDebridResolver_priority'] = '50'
                    xbmc.log('[AntiVenom] Service: Successfully auto-refreshed Real-Debrid OAuth token!', xbmc.LOGINFO)
                    return creds, True
        except Exception as e:
            xbmc.log(f'[AntiVenom] Service: OAuth token refresh error: {e}', xbmc.LOGWARNING)

    return creds, False

def apply_to_resolveurl(creds):
    """Write credentials to ResolveURL settings.xml, ensuring it exists and is enabled."""
    try:
        resolveurl_settings = xbmcvfs.translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml')
        os.makedirs(os.path.dirname(resolveurl_settings), exist_ok=True)

        if os.path.isfile(resolveurl_settings):
            tree = ET.parse(resolveurl_settings)
            root = tree.getroot()
        else:
            root = ET.Element('settings')
            tree = ET.ElementTree(root)

        existing = {s.attrib.get('id'): s for s in root.findall('setting')}
        changed = False

        for k, v in creds.items():
            if k in existing:
                if existing[k].text != str(v) or 'default' in existing[k].attrib:
                    existing[k].text = str(v)
                    if 'default' in existing[k].attrib:
                        del existing[k].attrib['default']
                    changed = True
            else:
                el = ET.SubElement(root, 'setting', {'id': k})
                el.text = str(v)
                changed = True

        if changed or not os.path.isfile(resolveurl_settings):
            tree.write(resolveurl_settings, encoding='utf-8', xml_declaration=False)
            xbmc.log('[AntiVenom] Service: Synchronized Real-Debrid settings to ResolveURL.', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[AntiVenom] Service apply_to_resolveurl error: {e}', xbmc.LOGWARNING)

def sync_rd():
    """Master Real-Debrid synchronization and persistent guardian."""
    try:
        resolveurl_settings = xbmcvfs.translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml')
        active_creds = None

        # 1. Read existing from ResolveURL if present
        if os.path.isfile(resolveurl_settings):
            try:
                tree = ET.parse(resolveurl_settings)
                root = tree.getroot()
                found = {}
                for s in root.findall('setting'):
                    sid = s.attrib.get('id')
                    if sid in RD_KEYS and s.text:
                        found[sid] = s.text.strip()
                if found.get('RealDebridResolver_token') and 'default' not in root.find(".//setting[@id='RealDebridResolver_token']").attrib:
                    active_creds = found
            except Exception:
                pass

        # 2. If ResolveURL lacked credentials, read from permanent multi-vault
        if not active_creds or not active_creds.get('RealDebridResolver_token'):
            active_creds = read_vault_credentials()

        if active_creds:
            # 3. Check and auto-refresh token if needed
            active_creds, refreshed = check_and_refresh_token(active_creds)

            # 4. Save into permanent multi-location vault
            write_vault_credentials(active_creds)

            # 5. Ensure ResolveURL is synced with current valid token
            apply_to_resolveurl(active_creds)

            # 6. Set skin status variables
            xbmc.executebuiltin('Skin.SetBool(RealDebridLinked)')
            xbmc.executebuiltin('Skin.SetBool(AntiVenom_RD_Active)')
            xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Active)')
            xbmc.executebuiltin('Skin.SetString(AntiVenom_RD_Label, "● REAL-DEBRID ACTIVE")')
            xbmc.executebuiltin('Skin.SetString(AntiVenom_RD_Color, "FF00F5A0")')
            return

        # No credentials anywhere
        xbmc.executebuiltin('Skin.Reset(RealDebridLinked)')
        xbmc.executebuiltin('Skin.Reset(AntiVenom_RD_Active)')
        xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Unlinked)')
        xbmc.executebuiltin('Skin.SetString(AntiVenom_RD_Label, "○ CONNECT DEBRID")')
        xbmc.executebuiltin('Skin.SetString(AntiVenom_RD_Color, "FFA0AAB8")')
    except Exception as e:
        xbmc.log(f'[AntiVenom] Service RD sync error: {e}', xbmc.LOGWARNING)

def configure_crew_settings():
    """Re-apply Fast or Full Crew profile every boot (never re-enable all scrapers here)."""
    try:
        from resources.lib import deviceprofile
        deviceprofile.sync_crew_profile(debrid_linked=has_debrid_credentials())
    except Exception as e:
        xbmc.log(f'[AntiVenom] configure_crew_settings error: {e}', xbmc.LOGWARNING)

def has_debrid_credentials():
    """
    Returns True if Real-Debrid credentials are confirmed active via:
    1. Skin setting RealDebridLinked (populated by sync_rd() right before this check)
    2. Multi-vault storage files
    3. ResolveURL settings XML
    """
    try:
        if xbmc.getCondVisibility('Skin.HasSetting(RealDebridLinked)'):
            return True

        vault = read_vault_credentials()
        if vault and (vault.get('RealDebridResolver_token') or vault.get('RealDebridResolver_refresh')):
            return True

        resolveurl_settings = xbmcvfs.translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml')
        if os.path.isfile(resolveurl_settings):
            tree = ET.parse(resolveurl_settings)
            root = tree.getroot()
            elem = root.find(".//setting[@id='RealDebridResolver_token']")
            if elem is not None and elem.text and 'default' not in elem.attrib and elem.text.strip():
                return True
    except Exception as e:
        xbmc.log(f'[AntiVenom] has_debrid_credentials check error: {e}', xbmc.LOGWARNING)
    return False

def check_first_run_wizard():
    """
    One-Time Debrid Setup Wizard:
    - If Debrid is ALREADY configured: silently create .setup_complete and NEVER show wizard.
    - If Debrid is NOT configured: prompt the one-time wizard on first run only.
    """
    try:
        done_flag = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/.setup_complete')

        # Gate 1: If Debrid is already set up, silently mark setup complete and suppress wizard
        if has_debrid_credentials():
            if not os.path.isfile(done_flag):
                os.makedirs(os.path.dirname(done_flag), exist_ok=True)
                with open(done_flag, 'w', encoding='utf-8') as f:
                    f.write(str(time.time()))
                xbmc.log('[AntiVenom] Debrid already active on device; one-time setup marked complete silently.', xbmc.LOGINFO)
            return

        # Gate 2: Debrid is NOT set and user has not completed or dismissed setup wizard
        if not os.path.isfile(done_flag):
            xbmc.sleep(2500)
            if xbmcgui.getCurrentWindowId() == 10000:
                xbmc.log('[AntiVenom] Debrid unlinked on first run; launching one-time Setup Wizard...', xbmc.LOGINFO)
                xbmc.executebuiltin('RunScript(script.antivenom,action=setup_wizard,first_run=true)')
    except Exception as e:
        xbmc.log(f'[AntiVenom] First run check error: {e}', xbmc.LOGWARNING)

# ─────────────────────────────────────────────
#  Step 3: Playback Monitoring & Dynamic Resume Engine
# ─────────────────────────────────────────────
RESUME_FILE = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/resume_state.json')
CONTINUE_FILE = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/continue_watching.json')

def read_continue_watching():
    try:
        if os.path.isfile(CONTINUE_FILE):
            with open(CONTINUE_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
    except Exception as e:
        xbmc.log(f'[AntiVenom ContinueWatching] Read error: {e}', xbmc.LOGWARNING)
    return []

def save_continue_watching(items):
    try:
        os.makedirs(os.path.dirname(CONTINUE_FILE), exist_ok=True)
        with open(CONTINUE_FILE, 'w', encoding='utf-8') as f:
            json.dump(items, f, indent=2)
    except Exception as e:
        xbmc.log(f'[AntiVenom ContinueWatching] Save error: {e}', xbmc.LOGWARNING)

def update_continue_watching(item):
    """Adds or updates an in-progress item at the front of continue_watching list."""
    items = read_continue_watching()
    title = (item.get('title') or '').strip().lower()
    file_path = (item.get('file') or '').strip().lower()

    # Deduplicate: remove existing entry matching title or file
    filtered = []
    for it in items:
        it_title = (it.get('title') or '').strip().lower()
        it_file = (it.get('file') or '').strip().lower()
        if title and it_title == title:
            continue
        if file_path and it_file and it_file == file_path:
            continue
        filtered.append(it)

    filtered.insert(0, item)
    filtered = filtered[:15]  # Keep up to 15 in-progress titles
    save_continue_watching(filtered)
    apply_continue_watching_to_skin(filtered)
    try:
        xbmc.executebuiltin('Container.Refresh(4900)')
    except Exception:
        pass

def remove_from_continue_watching(title=None, file_path=None):
    """Removes an item from continue_watching when completed, ended, or finished."""
    items = read_continue_watching()
    orig_len = len(items)
    t_clean = (title or '').strip().lower()
    f_clean = (file_path or '').strip().lower()

    filtered = []
    for it in items:
        it_title = (it.get('title') or '').strip().lower()
        it_file = (it.get('file') or '').strip().lower()
        matched = False
        if t_clean and it_title and (t_clean in it_title or it_title in t_clean):
            matched = True
        if f_clean and it_file and f_clean == it_file:
            matched = True
        if not matched:
            filtered.append(it)

    if len(filtered) < orig_len or not filtered:
        save_continue_watching(filtered)
        apply_continue_watching_to_skin(filtered)
        try:
            xbmc.executebuiltin('Container.Refresh(4900)')
        except Exception:
            pass

def apply_continue_watching_to_skin(items=None):
    if items is None:
        items = read_continue_watching()
    count = len(items)
    if count > 0:
        xbmc.executebuiltin('Skin.SetBool(AntiVenom_ContinueWatching_Active)')
        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_ContinueWatching_Count,"{count}")')
    else:
        xbmc.executebuiltin('Skin.Reset(AntiVenom_ContinueWatching_Active)')
        xbmc.executebuiltin('Skin.Reset(AntiVenom_ContinueWatching_Count)')

def save_resume_state(state):
    try:
        os.makedirs(os.path.dirname(RESUME_FILE), exist_ok=True)
        with open(RESUME_FILE, 'w', encoding='utf-8') as f:
            json.dump(state, f, indent=2)
    except Exception as e:
        xbmc.log(f'[AntiVenom Resume] Save error: {e}', xbmc.LOGWARNING)

def read_resume_state():
    try:
        if os.path.isfile(RESUME_FILE):
            with open(RESUME_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        xbmc.log(f'[AntiVenom Resume] Read error: {e}', xbmc.LOGWARNING)
    return None

def clear_resume_state():
    try:
        if os.path.isfile(RESUME_FILE):
            os.remove(RESUME_FILE)
    except Exception:
        pass
    clear_resume_to_skin()

def clear_resume_to_skin():
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Active)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Title)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Sub)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Thumb)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Time)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Seconds)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_BarWidth)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Percent)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_File)')

def apply_resume_to_skin(state=None):
    if not state:
        state = read_resume_state()
    if state and state.get('active'):
        xbmc.executebuiltin('Skin.SetBool(AntiVenom_Resume_Active)')
        title = state.get('title', 'Last Watched').replace('"', '')
        sub = state.get('sub_label', 'Resume Playback').replace('"', '')
        thumb = state.get('thumb', '')
        time_str = state.get('time_str', '0:00')
        secs = str(state.get('seconds', 0))
        width = str(state.get('bar_width', 136))
        pct = str(state.get('percent', 50))
        file_path = state.get('file', '')

        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Title,"{title}")')
        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Sub,"{sub}")')
        if thumb:
            xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Thumb,"{thumb}")')
        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Time,"{time_str}")')
        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Seconds,"{secs}")')
        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_BarWidth,"{width}")')
        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Percent,"{pct}")')
        if file_path:
            xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_File,"{file_path}")')
    else:
        clear_resume_to_skin()

class AntiVenomPlayer(xbmc.Player):
    def __init__(self):
        super(AntiVenomPlayer, self).__init__()
        self.last_title = ""
        self.last_file = ""
        self.last_thumb = ""
        self.last_type = "movie"
        self.last_season = ""
        self.last_episode = ""
        self.last_show_title = ""
        self.active_stream = ""
        self.prev_stream = ""
        self.binge_prompted = False

    def onAVStarted(self):
        try:
            # Retry up to 3 times with 800ms gap — FireStick/slow devices clear
            # VideoPlayer.* labels briefly after playback starts (race condition)
            for attempt in range(3):
                title = xbmc.getInfoLabel('VideoPlayer.Title') or xbmc.getInfoLabel('Player.Title')
                if title or attempt == 2:
                    break
                xbmc.sleep(800)

            self.last_title = title
            self.last_file = self.getPlayingFile()
            self.last_thumb = (
                xbmc.getInfoLabel('Player.Art(poster)') or 
                xbmc.getInfoLabel('Player.Art(thumb)') or 
                xbmc.getInfoLabel('VideoPlayer.Cover') or
                xbmc.getInfoLabel('ListItem.Thumb')
            )
            self.last_season = xbmc.getInfoLabel('VideoPlayer.Season')
            self.last_episode = xbmc.getInfoLabel('VideoPlayer.Episode')
            self.last_show_title = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
            self.last_fanart = xbmc.getInfoLabel('Player.Art(fanart)') or xbmc.getInfoLabel('ListItem.Art(fanart)')
            self.last_plot = xbmc.getInfoLabel('VideoPlayer.Plot') or xbmc.getInfoLabel('ListItem.Plot')
            self.last_year = xbmc.getInfoLabel('VideoPlayer.Year') or xbmc.getInfoLabel('ListItem.Year')
            self.binge_prompted = False

            if self.last_season and self.last_episode:
                self.last_type = "episode"
            else:
                self.last_type = "movie"

            # Channel Zapper stream history tracking
            if self.last_file and self.last_file != self.active_stream:
                self.prev_stream = self.active_stream
                self.active_stream = self.last_file
                win = xbmcgui.Window(10000)
                if self.prev_stream:
                    win.setProperty('AntiVenom.Zapper.PrevStream', self.prev_stream)
                win.setProperty('AntiVenom.Zapper.CurrStream', self.active_stream)

            xbmc.log(f'[AntiVenom Resume] Started playback: {self.last_title} ({self.last_type})', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'[AntiVenom Resume] onAVStarted error: {e}', xbmc.LOGWARNING)

    def onPlayBackPaused(self):
        self.record_progress()

    def onPlayBackStopped(self):
        self.record_progress()

    def onPlayBackEnded(self):
        self.mark_completed()

    def record_progress(self):
        try:
            curr_sec = int(self.getTime())
            total_sec = int(self.getTotalTime())
            if total_sec <= 0:
                return

            pct = (curr_sec / float(total_sec)) * 100.0

            # Smart Binge Trigger at >= 88% runtime for TV Show episodes
            if self.last_type == "episode" and pct >= 88.0 and not self.binge_prompted:
                self.binge_prompted = True
                try:
                    next_ep_num = int(self.last_episode) + 1 if (self.last_episode and self.last_episode.isdigit()) else 2
                    win = xbmcgui.Window(10000)
                    show = self.last_show_title or self.last_title
                    win.setProperty('AntiVenom.Binge.ShowTitle', show)
                    win.setProperty('AntiVenom.Binge.CurrentEp', f"S{self.last_season} E{self.last_episode}")
                    win.setProperty('AntiVenom.Binge.NextEp', f"S{self.last_season} E{next_ep_num}")
                    win.setProperty('AntiVenom.Binge.Thumb', self.last_thumb or '')
                    win.setProperty('AntiVenom.Binge.Active', 'true')
                    xbmc.executebuiltin('ActivateWindow(1111)')
                    xbmc.log(f'[AntiVenom Binge] Triggered next episode dialog for {show} S{self.last_season}E{next_ep_num}', xbmc.LOGINFO)
                except Exception as be:
                    xbmc.log(f'[AntiVenom Binge] trigger error: {be}', xbmc.LOGWARNING)

            # If watched >= 0.5% and not yet finished (avoids saving on accidental
            # one-second plays and already-completed titles)
            if pct >= 0.5 and pct < 92.0:
                hrs = curr_sec // 3600
                mins = (curr_sec % 3600) // 60
                secs = curr_sec % 60
                if hrs > 0:
                    time_str = f"{hrs}:{mins:02d}:{secs:02d}"
                else:
                    time_str = f"{mins}:{secs:02d}"

                bar_width = max(10, min(272, int((pct / 100.0) * 272)))
                sub_label = f"Resume at {time_str} • {int(pct)}%"
                if self.last_season and self.last_episode:
                    sub_label = f"S{self.last_season} E{self.last_episode} • {time_str}"

                thumb = self.last_thumb
                if not thumb:
                    thumb = "special://home/addons/skin.antivenom/media/antivenom/posters/dune2.jpg"

                import hashlib
                state = {
                    "id": hashlib.md5((self.last_title or self.last_file or "item").encode()).hexdigest()[:12],
                    "active": True,
                    "title": self.last_title or "Last Watched Media",
                    "file": self.last_file,
                    "thumb": thumb,
                    "fanart": self.last_fanart or thumb,
                    "plot": self.last_plot or "",
                    "year": self.last_year or "",
                    "time_str": time_str,
                    "seconds": curr_sec,
                    "total_seconds": total_sec,
                    "percent": int(pct),
                    "bar_width": bar_width,
                    "sub_label": sub_label,
                    "type": self.last_type,
                    "season": self.last_season,
                    "episode": self.last_episode,
                    "updated_at": int(time.time())
                }
                save_resume_state(state)
                apply_resume_to_skin(state)
                update_continue_watching(state)
                xbmc.log(f'[AntiVenom Resume] Saved resume point for {self.last_title} at {time_str} ({int(pct)}%)', xbmc.LOGINFO)
            elif pct >= 92.0:
                self.mark_completed()
        except Exception as e:
            xbmc.log(f'[AntiVenom Resume] record_progress error: {e}', xbmc.LOGWARNING)

    def mark_completed(self):
        try:
            clear_resume_state()
            remove_from_continue_watching(title=self.last_title, file_path=self.last_file)
            xbmc.log(f'[AntiVenom Resume] Playback completed/ended for {self.last_title}. Item removed from Continue Watching.', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'[AntiVenom Resume] mark_completed error: {e}', xbmc.LOGWARNING)

if __name__ == '__main__':
    xbmc.log('[AntiVenom] Background service started', xbmc.LOGINFO)

    log_watcher = None
    try:
        from resources.lib import crashreport
        crashreport.ensure_logging_enabled()
        crashreport.check_previous_session()
        log_watcher = crashreport.LogWatcher()
    except Exception as cr_err:
        crashreport = None
        xbmc.log(f'[AntiVenom] Reporter init error: {cr_err}', xbmc.LOGWARNING)

    ensure_skin_active()
    sync_rd()
    configure_crew_settings()
    ensure_device_tuning()
    apply_resume_to_skin()
    apply_continue_watching_to_skin()
    check_first_run_wizard()

    # Silent background integrity scan. Skip if already done this session.
    # Do not InstallAddon-loop or ReloadSkin on every boot (1GB Fire Sticks).
    try:
        already = xbmc.getInfoLabel('Skin.String(AntiVenomSysCheckDone)')
        if already:
            xbmc.log('[AntiVenom] System check already completed this session — skipping', xbmc.LOGINFO)
        else:
            import sys as _sys
            _addon_path = xbmcvfs.translatePath('special://home/addons/script.antivenom/')
            if _addon_path not in _sys.path:
                _sys.path.insert(0, _addon_path)
            from default import run_system_check
            run_system_check(silent=True, repair_addons=False)
    except Exception as _sc_err:
        xbmc.log(f'[AntiVenom] Background system check error: {_sc_err}', xbmc.LOGWARNING)

    # Initialize GameDay Hub scores on startup and keep writing real scoreboards.
    try:
        from resources.lib.gameday import refresh_all_scores
        refresh_all_scores(force=True)
        xbmc.executebuiltin('AlarmClock(AntiVenomGameDay,RunScript(script.antivenom,action=refresh_gameday),02:00,silent,loop)')
    except Exception as ge:
        xbmc.log(f'[AntiVenom Service] GameDay startup error: {ge}', xbmc.LOGWARNING)

    # Focus prefetch: a Home movie poster held ~1.5s gets its Torrentio cached list
    # fetched in the background (list only; nothing is added to the RD account).
    prefetcher = None
    try:
        from resources.lib import debridengine, deviceprofile as _devprofile
        _movie_meta = dict(_import_default().MOVIE_METADATA)

        def _prefetch_lookup(label):
            meta = _movie_meta.get((label or '').strip().lower())
            if meta and meta.get('imdb'):
                return (meta['imdb'], None, None)
            return None

        prefetcher = debridengine.Prefetcher(_prefetch_lookup)
    except Exception as pf_err:
        xbmc.log(f'[AntiVenom] Prefetch init error: {pf_err}', xbmc.LOGWARNING)

    player = AntiVenomPlayer()
    monitor = xbmc.Monitor()
    gameday_ticks = 0
    sync_ticks = 0
    ambient_focus_item = ""
    ambient_focus_time = 0
    ambient_playing = False
    report_ticks = 0
    last_window_id = None
    cache_warm_ticks = 0

    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break

        sync_ticks += 1
        gameday_ticks += 1
        report_ticks += 1

        window_id = dialog_id = 0
        try:
            window_id = xbmcgui.getCurrentWindowId()
            dialog_id = xbmcgui.getCurrentWindowDialogId()
            if (window_id, dialog_id) != last_window_id:
                last_window_id = (window_id, dialog_id)
                xbmc.log(f'[AntiVenom] Window {window_id} dialog {dialog_id} '
                         f'({xbmc.getInfoLabel("System.CurrentWindow")})', xbmc.LOGINFO)
        except Exception:
            pass

        if prefetcher is not None:
            try:
                if (window_id == 10000 and dialog_id == 9999 and not player.isPlaying()
                        and xbmc.getCondVisibility('Skin.HasSetting(RealDebridLinked)')
                        and _devprofile.is_fast_mode_enabled()):
                    prefetcher.tick(xbmc.getInfoLabel('ListItem.Label'))
                else:
                    prefetcher.reset()
            except Exception as pf_err:
                xbmc.log(f'[AntiVenom] Prefetch disabled for this session: {pf_err}', xbmc.LOGWARNING)
                prefetcher = None

        cache_warm_ticks += 1
        if cache_warm_ticks >= 45:
            cache_warm_ticks = 0
            try:
                if xbmcgui.getCurrentWindowId() == 10000:
                    from resources.lib import crewcache
                    crewcache.warm_idle()
            except Exception as ce:
                xbmc.log(f'[AntiVenom] Crew list cache idle warmup error: {ce}', xbmc.LOGWARNING)

        if log_watcher and report_ticks >= 120:
            report_ticks = 0
            try:
                log_watcher.poll()
            except Exception as lw_err:
                xbmc.log(f'[AntiVenom] Log watcher error: {lw_err}', xbmc.LOGWARNING)

        # Every 60 seconds when idle (was 10s — RD HTTP from the service hitchs a 1GB stick).
        # Still record playback every 10s while a video is playing.
        if player.isPlayingVideo() and sync_ticks >= 10:
            sync_ticks = 0
            if not ambient_playing:
                player.record_progress()
            elif player.last_file and not player.last_file.startswith('plugin://'):
                ambient_playing = False
                player.record_progress()
        elif sync_ticks >= 60:
            sync_ticks = 0
            sync_rd()

        # Sports scores. Faster on the Sports tab so Sunday football does not sit at 0 LIVE.
        on_sports = False
        try:
            on_sports = xbmc.getCondVisibility('String.IsEqual(Skin.String(ActiveTab),sports)')
        except Exception:
            on_sports = False
        if gameday_ticks >= (45 if on_sports else 180):
            gameday_ticks = 0
            try:
                import importlib
                from resources.lib import gameday
                importlib.reload(gameday)
                gameday.refresh_all_scores()
            except Exception as ge:
                xbmc.log(f'[AntiVenom Service] GameDay periodic refresh error: {ge}', xbmc.LOGWARNING)

        # Ambient Cinema trailer idle watcher on Home screen (Window 10000).
        # Opt-in: OFF by default because background video decode makes browsing sluggish on Firesticks.
        try:
            if xbmc.getCondVisibility('Skin.HasSetting(AmbientTrailers)') and xbmcgui.getCurrentWindowId() == 10000:
                if not player.isPlayingVideo():
                    curr_item = (
                        xbmc.getInfoLabel('Container(5000).ListItem.Title') or
                        xbmc.getInfoLabel('Container(5000).ListItem.Label') or
                        xbmc.getInfoLabel('Container(6000).ListItem.Title') or
                        xbmc.getInfoLabel('Container(6000).ListItem.Label')
                    )
                    trailer_url = (
                        xbmc.getInfoLabel('Container(5000).ListItem.Trailer') or
                        xbmc.getInfoLabel('Container(6000).ListItem.Trailer')
                    )
                    if curr_item:
                        if curr_item == ambient_focus_item:
                            ambient_focus_time += 1
                            if ambient_focus_time >= 3 and not ambient_playing and trailer_url:
                                ambient_playing = True
                                win = xbmcgui.Window(10000)
                                win.setProperty('AntiVenom.AmbientTrailer.Active', 'true')
                                player.play(trailer_url)
                                xbmc.log(f'[AntiVenom Cinema] Started ambient trailer for {curr_item}', xbmc.LOGINFO)
                        else:
                            ambient_focus_item = curr_item
                            ambient_focus_time = 0
                            if ambient_playing:
                                ambient_playing = False
                                win = xbmcgui.Window(10000)
                                win.clearProperty('AntiVenom.AmbientTrailer.Active')
                                player.stop()
                elif ambient_playing:
                    # Trailer is playing; check if user has navigated away to a different card
                    curr_item = (
                        xbmc.getInfoLabel('Container(5000).ListItem.Title') or
                        xbmc.getInfoLabel('Container(5000).ListItem.Label') or
                        xbmc.getInfoLabel('Container(6000).ListItem.Title') or
                        xbmc.getInfoLabel('Container(6000).ListItem.Label')
                    )
                    if curr_item and curr_item != ambient_focus_item:
                        ambient_playing = False
                        win = xbmcgui.Window(10000)
                        win.clearProperty('AntiVenom.AmbientTrailer.Active')
                        player.stop()
            elif ambient_playing:
                # Left Home screen; halt ambient trailer immediately
                ambient_playing = False
                win = xbmcgui.Window(10000)
                win.clearProperty('AntiVenom.AmbientTrailer.Active')
                player.stop()
        except Exception as ce:
            pass

    if crashreport:
        crashreport.mark_clean_exit()
